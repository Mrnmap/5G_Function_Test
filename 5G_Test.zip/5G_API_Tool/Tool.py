from secrets import choice
from colorama import Fore
import inquirer
import NRF
import AUSF
import BSF
import NSSF
import UDM
import AMF
import PCF
import SMF
import UDR


def cont():
    questions = [
        inquirer.List('Choice',
                      message="Do you want continue ?",
                      choices=['YES', 'NO'],)]
    answers = inquirer.prompt(questions)
    if answers['Choice'] == 'NO':
        return False

    return True


def fun():

    questions = [
        inquirer.List('Function',
                      message="Select the Function",
                      choices=['AUSF', 'NRF', 'NSSF', 'AMF', 'SMF', 'UDM', 'UDR', 'PCF', 'BSF'],), ]
    answers = inquirer.prompt(questions)

    print(answers)

    if answers != None:

        ################################################## AUSF #########################################################################################

        if answers["Function"] == 'AUSF':

            def ausf():
                questions = [
                    inquirer.List('AUSF',
                                  message="Select the AUSF",
                                  choices=['UE_Authentication', 'SOR_Protection', 'UPU_Protection'],), ]
                answers = inquirer.prompt(questions)

                def UE_Authentication():

                    questions = [
                        inquirer.List('UE_Authentication',
                                      message="Select the UE_Authentication",
                                      choices=['Default'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        ausf()

                    elif answers["UE_Authentication"] == 'Default':
                        Default1()

                def Default1():
                    questions = [
                        inquirer.List('Default',
                                      message="Select the Default",
                                      choices=['Authenticate_UE', 'AKA_Confirmation', 'EAP_Session_Information'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Authentication()

                    elif answers["Default"] == 'Authenticate_UE':
                        AUSF.UE_Authentication.Default.Authenticate_UE()

                    elif answers["Default"] == 'AKA_Confirmation':
                        AUSF.UE_Authentication.Default.AKA_Confirmation()

                    elif answers["Default"] == 'EAP_Session_Information':
                        AUSF.UE_Authentication.Default.EAP_Session_Information()

                def SOR_Protection():
                    questions = [
                        inquirer.List('SOR_Protection',
                                      message="Select the 5G_SOR_Protection",
                                      choices=['Default'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        ausf()

                    elif answers["SOR_Protection"] == 'Default':
                        Default2()

                def Default2():
                    questions = [
                        inquirer.List('Default',
                                      message="Select the Default",
                                      choices=['Generate_SoR_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        SOR_Protection()

                    elif answers["Default"] == 'Generate_SoR_Data':
                        AUSF.SOR_Protection.Default.Generate_SOR_Data()

                def UPU_Protection():
                    questions = [
                        inquirer.List('UPU_Protection',
                                      message="Select the UPU_Protection",
                                      choices=['Default'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        ausf()

                    elif answers["UPU_Protection"] == 'Default':
                        Default3()

                def Default3():
                    questions = [
                        inquirer.List('Default',
                                      message="Select the Default",
                                      choices=['Protect'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UPU_Protection()

                    elif answers["Default"] == 'Protect':
                        AUSF.UPU_Protection.Default.Protect()

                if answers == None:
                    fun()

                elif answers["AUSF"] == 'UE_Authentication':
                    UE_Authentication()

                elif answers["AUSF"] == 'SOR_Protection':
                    SOR_Protection()

                elif answers["AUSF"] == 'UPU_Protection':
                    UPU_Protection()

            ausf()
################################################ AMF #########################################################################################

        elif answers["Function"] == 'AMF':

            def amf():
                questions = [
                    inquirer.List('AMF',
                                  message="Select the AMF",
                                  choices=['Communication', 'Event_Exposure', 'Location', 'MT'],), ]
                answers = inquirer.prompt(questions)

                def Communication():
                    questions = [
                        inquirer.List('Communication',
                                      message="Select the Communication",
                                      choices=['Individual_ueContext_Document', 'n1N2Message_collection_Document', 'N1N2_Subscriptions_Collection_for_Individual_UE_Contexts_Document', 'N1N2_Individual_Subscription_Document', 'Non_UE_N2Messages_collection_Document', 'Non_UE_N2Messages_Subscriptions_collection_Document', 'Non_UE_N2_Message_Notification_Individual_SubscriptionDocument', 'subscriptions_collection_Document', 'individual_subscription_Document'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        amf()

                    elif answers["Communication"] == 'Individual_ueContext_Document':
                        Individual_ueContext_Document()

                    elif answers["Communication"] == 'n1N2Message_collection_Document':
                        n1N2Message_collection_Document()

                    elif answers["Communication"] == 'N1N2_Subscriptions_Collection_for_Individual_UE_Contexts_Document':
                        N1N2_Subscriptions_Collection_for_Individual_UE_Contexts_Document()

                    elif answers["Communication"] == 'N1N2_Individual_Subscription_Document':
                        N1N2_Individual_Subscription_Document()

                    elif answers["Communication"] == 'Non_UE_N2Messages_collection_Document':
                        Non_UE_N2Messages_collection_Document()

                    elif answers["Communication"] == 'Non_UE_N2Messages_Subscriptions_collection_Document':
                        Non_UE_N2Messages_Subscriptions_collection_Document()

                    elif answers["Communication"] == 'Non_UE_N2_Message_Notification_Individual_SubscriptionDocument':
                        Non_UE_N2_Message_Notification_Individual_SubscriptionDocument()

                    elif answers["Communication"] == 'subscriptions_collection_Document':
                        subscriptions_collection_Document()

                    elif answers["Communication"] == 'individual_subscription_Document':
                        individual_subscription_Document()

                def Individual_ueContext_Document():
                    questions = [
                        inquirer.List('Individual_ueContext_Document',
                                      message="Select the Individual_ueContext_Document",
                                      choices=['Release_UE_Context', 'EBI_Assignment', 'UE_Context_Transfer', 'Registration_Status_Update'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Communication()

                    elif answers["Individual_ueContext_Document"] == 'Release_UE_Context':
                        AMF.Communication.Individual_ueContext_Document.Release_UE_Context()

                    elif answers["Individual_ueContext_Document"] == 'EBI_Assignment':
                        AMF.Communication.Individual_ueContext_Document.EBI_Assignment()

                    elif answers["Individual_ueContext_Document"] == 'UE_Context_Transfer':
                        AMF.Communication.Individual_ueContext_Document.UE_Context_Transfer()

                    elif answers["Individual_ueContext_Document"] == 'Registration_Status_Update':
                        AMF.Communication.Individual_ueContext_Document.Registration_Status_Update()

                def n1N2Message_collection_Document():
                    questions = [
                        inquirer.List('n1N2Message_collection_Document',
                                      message="Select the n1N2Message_collection_Document",
                                      choices=['N1N2_Message_Transfer'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Communication()

                    elif answers["n1N2Message_collection_Document"] == 'N1N2_Message_Transfer':
                        AMF.Communication.n1N2Message_collection_Document.N1N2_Message_Transfer()

                def N1N2_Subscriptions_Collection_for_Individual_UE_Contexts_Document():
                    questions = [
                        inquirer.List('N1N2_Subscriptions_Collection_for_Individual_UE_Contexts_Document',
                                      message="Select the N1N2_Subscriptions_Collection_for_Individual_UE_Contexts_Document",
                                      choices=['N1N2_Message_Subscribe'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Communication()

                    elif answers["N1N2_Subscriptions_Collection_for_Individual_UE_Contexts_Document"] == 'N1N2_Message_Subscribe':
                        AMF.Communication.N1N2_Subscriptions_Collection_for_Individual_UE_Contexts_Document.N1N2_Message_Subscribe()

                def N1N2_Individual_Subscription_Document():
                    questions = [
                        inquirer.List('N1N2_Individual_Subscription_Document',
                                      message="Select the N1N2_Individual_Subscription_Document",
                                      choices=['N1N2_Message_UnSubscribe'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Communication()

                    elif answers["N1N2_Individual_Subscription_Document"] == 'N1N2_Message_UnSubscribe':
                        AMF.Communication.N1N2_Individual_Subscription_Document.N1N2_Message_UnSubscribe()

                def Non_UE_N2Messages_collection_Document():
                    questions = [
                        inquirer.List('Non_UE_N2Messages_collection_Document',
                                      message="Select the Non_UE_N2Messages_collection_Document",
                                      choices=['Non_UE_N2_Message_Transfer'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Communication()

                    elif answers["Non_UE_N2Messages_collection_Document"] == 'Non_UE_N2_Message_Transfer':
                        AMF.Communication.Non_UE_N2Messages_collection_Document.Non_UE_N2_Message_Transfer()

                def Non_UE_N2Messages_Subscriptions_collection_Document():
                    questions = [
                        inquirer.List('Non_UE_N2Messages_Subscriptions_collection_Document',
                                      message="Select the Non_UE_N2Messages_Subscriptions_collection_Document",
                                      choices=['Non_UE_N2_Information_Subscribe'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Communication()

                    elif answers["Non_UE_N2Messages_Subscriptions_collection_Document"] == 'Non_UE_N2_Information_Subscribe':
                        AMF.Communication.Non_UE_N2Messages_Subscriptions_collection_Document.Non_UE_N2_Information_Subscribe()

                def Non_UE_N2_Message_Notification_Individual_SubscriptionDocument():
                    questions = [
                        inquirer.List('Non_UE_N2_Message_Notification_Individual_SubscriptionDocument',
                                      message="Select the Non_UE_N2_Message_Notification_Individual_SubscriptionDocument",
                                      choices=['Non_UE_N2_Information_Unsubscribe'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Communication()

                    elif answers["Non_UE_N2_Message_Notification_Individual_SubscriptionDocument"] == 'Non_UE_N2_Information_Unsubscribe':
                        AMF.Communication.Non_UE_N2_Message_Notification_Individual_SubscriptionDocument.Non_UE_N2_Information_Unsubscribe()

                def subscriptions_collection_Document():
                    questions = [
                        inquirer.List('subscriptions_collection_Document',
                                      message="Select the subscriptions_collection_Document",
                                      choices=['AMF_Status_Change_Subscribe'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Communication()

                    elif answers["subscriptions_collection_Document"] == 'AMF_Status_Change_Subscribe':
                        AMF.Communication.subscriptions_collection_Document.AMF_Status_Change_Subscribe()

                def individual_subscription_Document():
                    questions = [
                        inquirer.List('individual_subscription_Document',
                                      message="Select the individual_subscription_Document",
                                      choices=['AMF_Status_Change_Unsubscribe', 'Modify_an_AMF_Status_Change_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Communication()

                    elif answers["individual_subscription_Document"] == 'AMF_Status_Change_Unsubscribe':
                        AMF.Communication.individual_subscription_Document.AMF_Status_Change_Unsubscribe()

                    elif answers["individual_subscription_Document"] == 'Modify_an_AMF_Status_Change_Subscription':
                        AMF.Communication.individual_subscription_Document.Modify_an_AMF_Status_Change_Subscription()

                def Event_Exposure():
                    questions = [
                        inquirer.List('Event_Exposure',
                                      message="Select the Event_Exposure",
                                      choices=['Subscriptions_collection_Document', 'Individual_subscription_Document'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        amf()

                    elif answers["Event_Exposure"] == 'Subscriptions_collection_Document':
                        Subscriptions_collection_Document()

                    elif answers["Event_Exposure"] == 'Individual_subscription_Document':
                        Individual_subscription_Document()

                def Subscriptions_collection_Document():
                    questions = [
                        inquirer.List('Subscriptions_collection_Document',
                                      message="Select the Subscriptions_collection_Document",
                                      choices=['Create_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Event_Exposure()

                    elif answers["Subscriptions_collection_Document"] == 'Create_Subscription':
                        AMF.Event_Exposure.Subscriptions_collection_Document.Create_Subscription()

                def Individual_subscription_Document():
                    questions = [
                        inquirer.List('Individual_subscription_Document',
                                      message="Select the Individual_subscription_Document",
                                      choices=['Modify_Subscription', 'Delete_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Event_Exposure()

                    elif answers["Individual_subscription_Document"] == 'Modify_Subscription':
                        AMF.Event_Exposure.Individual_subscription_Document.Modify_Subscription()

                    elif answers["Individual_subscription_Document"] == 'Delete_Subscription':
                        AMF.Event_Exposure.Individual_subscription_Document.Delete_Subscription()

                def Location():
                    questions = [
                        inquirer.List('Location',
                                      message="Select the Location",
                                      choices=['Individual_UE_context_Document'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        amf()

                    elif answers["Location"] == 'Individual_UE_context_Document':
                        Individual_UE_context_Document()

                def Individual_UE_context_Document():
                    questions = [
                        inquirer.List('Individual_UE_context_Document',
                                      message="Select the Individual_UE_context_Document",
                                      choices=['Provide_Positioning_Info', 'Provide_Location_Info'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Location()

                    elif answers["Individual_UE_context_Document"] == 'Provide_Positioning_Info':
                        AMF.Location.Individual_UE_context_Document.Provide_Positioning_Info()

                    elif answers["Individual_UE_context_Document"] == 'Provide_Location_Info':
                        AMF.Location.Individual_UE_context_Document.Provide_Loaction_Info()

                def MT():
                    questions = [
                        inquirer.List('MT',
                                      message="Select the MT",
                                      choices=['ueContext_Document', 'ueReachInd_Document'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        amf()

                    elif answers["MT"] == 'ueContext_Document':
                        ueContext_Document()

                    elif answers["MT"] == 'ueReachInd_Document':
                        ueReachInd_Document()

                def ueContext_Document():
                    questions = [
                        inquirer.List('ueContext_Document',
                                      message="Select the ueContext_Document",
                                      choices=['Provide_Domain_Selection_Info'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        MT()

                    elif answers["ueContext_Document"] == 'Provide_Domain_Selection_Info':
                        AMF.MT.ueContext_Document.Provide_Domain_Selection_Info()

                def ueReachInd_Document():
                    questions = [
                        inquirer.List('ueReachInd_Document',
                                      message="Select the ueReachInd_Document",
                                      choices=['Update_UE_Reachable_Indication'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        MT()

                    elif answers["ueReachInd_Document"] == 'Update_UE_Reachable_Indication':
                        AMF.MT.ueReachInd_Document.Update_UE_Reachable_Indication()

                if answers == None:
                    fun()

                elif answers["AMF"] == 'Communication':
                    Communication()

                elif answers["AMF"] == 'Event_Exposure':
                    Event_Exposure()

                elif answers["AMF"] == 'Location':
                    Location()

                elif answers["AMF"] == 'MT':
                    MT()

            amf()

################################################ NRF #########################################################################################

        elif answers["Function"] == 'NRF':

            def nrf():
                questions = [
                    inquirer.List('NRF',
                                  message="Select the NRF",
                                  choices=['NF_Management', 'NF_Discovery'],), ]
                answers = inquirer.prompt(questions)

                def NF_Management():
                    questions = [
                        inquirer.List('NF_Management',
                                      message="Select the NF_Management",
                                      choices=['NF_Instances_Store', 'NF_Instances_ID_Document', 'Subscriptions_Collection', 'Subscriptions_Document'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        nrf()

                    elif answers["NF_Management"] == 'NF_Instances_Store':
                        NF_Instances_Store()

                    elif answers["NF_Management"] == 'NF_Instances_ID_Document':
                        NF_Instances_ID_Document()

                    elif answers["NF_Management"] == 'Subscriptions_Collection':
                        Subscriptions_Collection()

                    elif answers["NF_Management"] == 'Subscriptions_Document':
                        Subscriptions_Document()

                def NF_Instances_ID_Document():
                    questions = [
                        inquirer.List('NF_Instances_ID_Document',
                                      message="Select the NF_Instances_ID_Document",
                                      choices=['Retrieve_NF_Profile', 'NF_Register', 'NF_Update', 'NF_Deregister'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        NF_Management()

                    elif answers["NF_Instances_ID_Document"] == 'Retrieve_NF_Profile':
                        NRF.NF_Management.NF_Instance_ID_Document.Retrive_NF_Profile()

                    elif answers["NF_Instances_ID_Document"] == 'NF_Register':
                        NRF.NF_Management.NF_Instance_ID_Document.NF_Register()

                    elif answers["NF_Instances_ID_Document"] == 'NF_Update':
                        NRF.NF_Management.NF_Instance_ID_Document.NF_Update()

                    elif answers["NF_Instances_ID_Document"] == 'NF_Deregister':
                        NRF.NF_Management.NF_Instance_ID_Document.NF_Deregister()

                def Subscriptions_Collection():
                    questions = [
                        inquirer.List('Subscriptions_Collection',
                                      message="Select the Subscriptions_Collection",
                                      choices=['NF_Status_Subsccribe'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        NF_Management()

                    elif answers["Subscriptions_Collection"] == 'NF_Status_Subsccribe':
                        NRF.NF_Management.Subcriptions_Collection.NF_Status_Subscribe()

                def Subscriptions_Document():
                    questions = [
                        inquirer.List('Subscriptions_Document',
                                      message="Select the Subscriptions_Document",
                                      choices=['Update_Subscription', 'NF_Stats_Unsubscribe'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        NF_Management()

                    elif answers["Subscriptions_Document"] == 'Update_Subscription':
                        NRF.NF_Management.Subcription_ID_Document.Update_Subscription()

                    elif answers["Subscriptions_Document"] == 'NF_Stats_Unsubscribe':
                        NRF.NF_Management.Subcription_ID_Document.NF_Status_Unsubscribe()

                def NF_Instances_Store():
                    questions = [
                        inquirer.List('NF_Instances_Store',
                                      message="Select the NF_Instances_Store",
                                      choices=['Retrieve_NF_List'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        NF_Management()

                    elif answers["NF_Instances_Store"] == 'Retrieve_NF_List':
                        NRF.NF_Management.NF_Instances_Store.Retrive_NF_List()

                    # elif answers["NF_Instances_Store"] == 'Query_Options':
                    #     NRF.NF_Management.NF_Instances_Store.Query_Options()

                def Access_Token_OAuth2():
                    questions = [
                        inquirer.List('Access_Token_OAuth2',
                                      message="Select the Access_Token_OAuth2",
                                      choices=['Access_Token_Request'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        nrf()

                    elif answers["Access_Token_OAuth2"] == 'Access_Token_Request':
                        NRF.Access_Token_OAuth2.Access_Token_Request()
                        print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)

                def NF_Discovery():
                    questions = [
                        inquirer.List('NF_Discovery',
                                      message="Select the NF_Discovery",
                                      choices=['NF_Instances_Store'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        nrf()

                    elif answers["NF_Discovery"] == 'NF_Instances_Store':
                        NF_Instances_Discovery_Store()

                def NF_Instances_Discovery_Store():
                    questions = [
                        inquirer.List('NF_Instances_Store',
                                      message="Select the NF_Instances_Store",
                                      choices=['NF_Discover'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        NF_Discovery()

                    elif answers["NF_Instances_Store"] == 'NF_Discover':
                        NRF.NF_Discovery.NF_Instances_Store.NF_Descover()

                if answers == None:
                    fun()

                elif answers["NRF"] == 'NF_Management':
                    NF_Management()

                elif answers["NRF"] == 'NF_Discovery':
                    NF_Discovery()

                # elif answers["NRF"] == 'Access_Token_OAuth2':
                #     Access_Token_OAuth2()

            nrf()

################################################ NSSF #########################################################################################

        elif answers["Function"] == 'NSSF':

            def nssf():
                questions = [
                    inquirer.List('NSSF',
                                  message="Select the NSSF",
                                  choices=['NSSAI_Availability', 'NS_Selection'],), ]
                answers = inquirer.prompt(questions)

                def NSSAI_Availability():
                    questions = [
                        inquirer.List('NSSAI_Availability',
                                      message="Select the NSSAI_Availability",
                                      choices=['NF_Instance_ID_Document', 'Subscriptions_Collection', 'Subscription_ID_Document', 'NSSAI_Availability_Store'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        nssf()

                    elif answers["NSSAI_Availability"] == 'NF_Instance_ID_Document':
                        NF_Instance_ID_Document()

                    elif answers["NSSAI_Availability"] == 'Subscriptions_Collection':
                        Subscriptions_Collection()

                    elif answers["NSSAI_Availability"] == 'Subscription_ID_Document':
                        Subscription_ID_Document()

                    elif answers["NSSAI_Availability"] == 'NSSAI_Availability_Store':
                        NSSAI_Availability_Store()

                def NF_Instance_ID_Document():
                    questions = [
                        inquirer.List('NF_Instance_ID_Document',
                                      message="Select the NF_Instance_ID_Document",
                                      choices=['Update_Network_Slice_Selection_Assistance_Information', 'Update_NSSAI_Availability', 'Delete_NSSAI_Availability'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        NSSAI_Availability()

                    elif answers["NF_Instance_ID_Document"] == 'Update_Network_Slice_Selection_Assistance_Information':
                        NSSF.NSSAI_Availability.NF_Instance_ID_Document.Update_Network_Slice_Selection_Assistance_Information()

                    elif answers["NF_Instance_ID_Document"] == 'Update_NSSAI_Availability':
                        NSSF.NSSAI_Availability.NF_Instance_ID_Document.Update_NSSAI_Availability()

                    elif answers["NF_Instance_ID_Document"] == 'Delete_NSSAI_Availability':
                        NSSF.NSSAI_Availability.NF_Instance_ID_Document.Delete_NSSAI_Availability()

                def Subscriptions_Collection():
                    questions = [
                        inquirer.List('Subscriptions_Collection',
                                      message="Select the Subscriptions_Collection",
                                      choices=['Create_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        NSSAI_Availability()

                    elif answers["Subscriptions_Collection"] == 'Create_Subscription':
                        NSSF.NSSAI_Availability.Subscriptions_Collection.Create_Subscription()

                def Subscription_ID_Document():
                    questions = [
                        inquirer.List('Subscription_ID_Document',
                                      message="Select the Subscription_ID_Document",
                                      choices=['Delete_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        NSSAI_Availability()

                    elif answers["Subscription_ID_Document"] == 'Delete_Subscription':
                        NSSF.NSSAI_Availability.Subscription_ID_Document.Delete_Subscription()

                def NSSAI_Availability_Store():
                    questions = [
                        inquirer.List('NSSAI_Availability_Store',
                                      message="Select the NSSAI_Availability_Store",
                                      choices=['Discover_Communication_Options'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        NSSAI_Availability()

                    elif answers["NSSAI_Availability_Store"] == 'Discover_Communication_Options':
                        NSSF.NSSAI_Availability.NSSAI_Availability_Store.Discover_Communication_Options()

                def NS_Selection():
                    questions = [
                        inquirer.List('NS_Selection',
                                      message="Select the NS_Selection",
                                      choices=['Network_Slice_Information_Document'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        nssf()

                    elif answers["NS_Selection"] == 'Network_Slice_Information_Document':
                        Network_Slice_Information_Document()

                def Network_Slice_Information_Document():
                    questions = [
                        inquirer.List('Network_Slice_Information_Document',
                                      message="Select the Network_Slice_Information_Document",
                                      choices=['Retrieve_Network_Slice_Information'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        NS_Selection()

                    elif answers["Network_Slice_Information_Document"] == 'Retrieve_Network_Slice_Information':
                        NSSF.NS_Selection.Network_Slice_Information_Document.Retrieve_Network_Slice_Information()

                if answers == None:
                    fun()

                elif answers["NSSF"] == 'NSSAI_Availability':
                    NSSAI_Availability()

                elif answers["NSSF"] == 'NS_Selection':
                    NS_Selection()

            nssf()

################################################ SMF #########################################################################################

        elif answers["Function"] == 'SMF':

            def smf():
                questions = [
                    inquirer.List('SMF',
                                  message="Select the SMF",
                                  choices=['PDU_Session', 'Event_Exposure'],), ]
                answers = inquirer.prompt(questions)

                def PDU_Session():
                    questions = [
                        inquirer.List('PDU_Session',
                                      message="Select the PDU_Session",
                                      choices=['SM_contexts_collection', 'Individual_SM_context', 'PDU_sessions_collection', 'Individual_PDU_session_H_SMF'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        smf()

                    elif answers["PDU_Session"] == 'SM_contexts_collection':
                        SM_contexts_collection()

                    elif answers["PDU_Session"] == 'Individual_SM_context':
                        Individual_SM_context()

                    elif answers["PDU_Session"] == 'PDU_sessions_collection':
                        PDU_sessions_collection()

                    elif answers["PDU_Session"] == 'Individual_PDU_session_H_SMF':
                        Individual_PDU_session_H_SMF()

                def SM_contexts_collection():
                    questions = [
                        inquirer.List('SM_contexts_collection',
                                      message="Select the SM_contexts_collection",
                                      choices=['Create_SM_Context'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        PDU_Session()

                    elif answers["SM_contexts_collection"] == 'Create_SM_Context':
                        SMF.PDU_Session.SM_contexts_collection.Create_SM_Context()

                def Individual_SM_context():
                    questions = [
                        inquirer.List('Individual_SM_context',
                                      message="Select the Individual_SM_context",
                                      choices=['Retrieve_SM_Context', 'Update_SM_Context', 'Release_SM_Context'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        PDU_Session()

                    elif answers["Individual_SM_context"] == 'Update_SM_Context':
                        SMF.PDU_Session.Individual_SM_context.Update_SM_Context()

                    elif answers["Individual_SM_context"] == 'Retrieve_SM_Context':
                        SMF.PDU_Session.Individual_SM_context.Retrieve_SM_Context()

                    elif answers["Individual_SM_context"] == 'Release_SM_Context':
                        SMF.PDU_Session.Individual_SM_context.Release_SM_Context()

                def PDU_sessions_collection():
                    questions = [
                        inquirer.List('PDU_sessions_collection',
                                      message="Select the PDU_sessions_collection",
                                      choices=['Create_PDU_Session'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        PDU_Session()

                    elif answers["PDU_sessions_collection"] == 'Create_PDU_Session':
                        SMF.PDU_Session.PDU_sessions_collection.Create_PDU_Session()

                def Individual_PDU_session_H_SMF():
                    questions = [
                        inquirer.List('Individual_PDU_session_H_SMF',
                                      message="Select the Individual_PDU_session_H_SMF",
                                      choices=['Update_PDU_Session', 'Retrieve_PDU_Session_Context'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        PDU_Session()

                    elif answers["Individual_PDU_session_H_SMF"] == 'Retrieve_PDU_Session_Context':
                        SMF.PDU_Session.Individual_PDU_session_H_SMF.Retrieve_PDU_Session_Context()

                    elif answers["Individual_PDU_session_H_SMF"] == 'Update_PDU_Session':
                        SMF.PDU_Session.Individual_PDU_session_H_SMF.Update_PDU_Session()

                def Event_Exposure():
                    questions = [
                        inquirer.List('Event_Exposure',
                                      message="Select the Event_Exposure",
                                      choices=['Subscriptions_Collection', 'IndividualSubscription_Document'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        smf()

                    elif answers["Event_Exposure"] == 'Subscriptions_Collection':
                        Subscriptions_Collection()

                    elif answers["Event_Exposure"] == 'IndividualSubscription_Document':
                        IndividualSubscription_Document()

                def Subscriptions_Collection():
                    questions = [
                        inquirer.List('Subscriptions_Collection',
                                      message="Select the Subscriptions_Collection",
                                      choices=['Create_Subsciption'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Event_Exposure()

                    elif answers["Subscriptions_Collection"] == 'Create_Subsciption':
                        SMF.Event_Exposure.Subscriptions_Collection.Create_Subsciption()

                def IndividualSubscription_Document():
                    questions = [
                        inquirer.List('IndividualSubscription_Document',
                                      message="Select the IndividualSubscription_Document",
                                      choices=['Retrieve_Subscription', 'Replace_Subscription', 'Unsubscribe_from_Event_Notifications'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Event_Exposure()

                    elif answers["IndividualSubscription_Document"] == 'Replace_Subscription':
                        SMF.Event_Exposure.IndividualSubscription_Document.Replace_Subscription()

                    elif answers["IndividualSubscription_Document"] == 'Retrieve_Subscription':
                        SMF.Event_Exposure.IndividualSubscription_Document.Retrieve_Subscription()

                    elif answers["IndividualSubscription_Document"] == 'Unsubscribe_from_Event_Notifications':
                        SMF.Event_Exposure.IndividualSubscription_Document.Unsubscribe_from_Event_Notifications()

                if answers == None:
                    fun()

                elif answers["SMF"] == 'PDU_Session':
                    PDU_Session()

                elif answers["SMF"] == 'Event_Exposure':
                    Event_Exposure()

            smf()

################################################ UDM #########################################################################################

        elif answers["Function"] == 'UDM':

            def udm():
                questions = [
                    inquirer.List('UDM',
                                  message="Select the UDM",
                                  choices=['Subscriber_Data_Management', 'UE_Context_Management', 'UE_Authentication', 'Event_Exposure', 'Parameter_Provisioning'],), ]
                answers = inquirer.prompt(questions)

                def Subscriber_Data_Management():
                    questions = [
                        inquirer.List('Subscriber_Data_Management',
                                      message="Select the Subscriber_Data_Management",
                                      choices=['Retrieval_of_multiple_data_sets', 'Slice_Selection_Subscription_Data_Retrieval', 'Access_and_Mobility_Subscription_Data_Retrieval', 'SMF_Selection_Subscription_Data_Retrieval', 'UE_Context_In_SMF_Data_Retrieval', 'UE_Context_In_SMSF_Data_Retrieval', 'Trace_Configuration_Data_Retrieval', 'Session_Management_Subscription_Data_Retrieval', 'SMS_Subscription_Data_Retrieval', 'SMS_Management_Subscription_Data_Retrieval', 'Subscription_Creation', 'Subscription_Deletion', 'Subscription_Modification', 'GPSI_to_SUPI_Translation', 'Providing_acknowledgement_of_Steering_of_Roaming', 'Providing_acknowledgement_of_UE_Parameters_Update', 'Providing_acknowledgement_of_S_NSSAIs_Update', 'Retrieval_of_shared_data', 'Subscription_Creation_for_shared_data', 'Subscription_Deletion_for_shared_data', 'Group_Identifiers'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        udm()

                    elif answers["Subscriber_Data_Management"] == 'Retrieval_of_multiple_data_sets':
                        Retrieval_of_multiple_data_sets()

                    elif answers["Subscriber_Data_Management"] == 'Slice_Selection_Subscription_Data_Retrieval':
                        Slice_Selection_Subscription_Data_Retrieval()

                    elif answers["Subscriber_Data_Management"] == 'Access_and_Mobility_Subscription_Data_Retrieval':
                        Access_and_Mobility_Subscription_Data_Retrieval()

                    elif answers["Subscriber_Data_Management"] == 'SMF_Selection_Subscription_Data_Retrieval':
                        SMF_Selection_Subscription_Data_Retrieval()

                    elif answers["Subscriber_Data_Management"] == 'UE_Context_In_SMF_Data_Retrieval':
                        UE_Context_In_SMF_Data_Retrieval()

                    elif answers["Subscriber_Data_Management"] == 'UE_Context_In_SMSF_Data_Retrieval':
                        UE_Context_In_SMSF_Data_Retrieval()

                    elif answers["Subscriber_Data_Management"] == 'Session_Management_Subscription_Data_Retrieval':
                        Session_Management_Subscription_Data_Retrieval()

                    elif answers["Subscriber_Data_Management"] == 'SMS_Subscription_Data_Retrieval':
                        SMS_Subscription_Data_Retrieval()

                    elif answers["Subscriber_Data_Management"] == 'SMS_Management_Subscription_Data_Retrieval':
                        SMS_Management_Subscription_Data_Retrieval()

                    elif answers["Subscriber_Data_Management"] == 'Subscription_Creation':
                        Subscription_Creation()

                    elif answers["Subscriber_Data_Management"] == 'Subscription_Deletion':
                        Subscription_Deletion()

                    elif answers["Subscriber_Data_Management"] == 'Subscription_Modification':
                        Subscription_Modification()

                    elif answers["Subscriber_Data_Management"] == 'GPSI_to_SUPI_Translation':
                        GPSI_to_SUPI_Translation()

                    elif answers["Subscriber_Data_Management"] == 'Providing_acknowledgement_of_Steering_of_Roaming':
                        Providing_acknowledgement_of_Steering_of_Roaming()

                    elif answers["Subscriber_Data_Management"] == 'Providing_acknowledgement_of_UE_Parameters_Update':
                        Providing_acknowledgement_of_UE_Parameters_Update()

                    elif answers["Subscriber_Data_Management"] == 'Providing_acknowledgement_of_S_NSSAIs_Update':
                        Providing_acknowledgement_of_S_NSSAIs_Update()

                    elif answers["Subscriber_Data_Management"] == 'Retrieval_of_shared_data':
                        Retrieval_of_shared_data()

                    elif answers["Subscriber_Data_Management"] == 'Subscription_Creation_for_shared_data':
                        Subscription_Creation_for_shared_data()

                    elif answers["Subscriber_Data_Management"] == 'Subscription_Deletion_for_shared_data':
                        Subscription_Deletion_for_shared_data()

                    elif answers["Subscriber_Data_Management"] == 'Group_Identifiers':
                        Group_Identifiers()

                    elif answers["Subscriber_Data_Management"] == 'Trace_Configuration_Data_Retrieval':
                        Trace_Configuration_Data_Retrieval()

                def Retrieval_of_multiple_data_sets():
                    questions = [
                        inquirer.List('Retrieval_of_multiple_data_sets',
                                      message="Select the Retrieval_of_multiple_data_sets",
                                      choices=['Retrieve_Subscription_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["Retrieval_of_multiple_data_sets"] == 'Retrieve_Subscription_Data':
                        UDM.Subscriber_Data_Management.Retrieval_of_multiple_data_sets.Retrieve_Subscription_Data()

                def Slice_Selection_Subscription_Data_Retrieval():
                    questions = [
                        inquirer.List('Slice_Selection_Subscription_Data_Retrieval',
                                      message="Select the Slice_Selection_Subscription_Data_Retrieval",
                                      choices=['Retrieve_NSSAI'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["Slice_Selection_Subscription_Data_Retrieval"] == 'Retrieve_NSSAI':
                        UDM.Subscriber_Data_Management.Slice_Selection_Subscription_Data_Retrieval.Retrieve_NSSAI()

                def Access_and_Mobility_Subscription_Data_Retrieval():
                    questions = [
                        inquirer.List('Access_and_Mobility_Subscription_Data_Retrieval',
                                      message="Select the Access_and_Mobility_Subscription_Data_Retrieval",
                                      choices=['Retrieve_AM_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["Access_and_Mobility_Subscription_Data_Retrieval"] == 'Retrieve_AM_Data':
                        UDM.Subscriber_Data_Management.Access_and_Mobility_Subscription_Data_Retrieval.Retrieve_AM_Data()

                def SMF_Selection_Subscription_Data_Retrieval():
                    questions = [
                        inquirer.List('SMF_Selection_Subscription_Data_Retrieval',
                                      message="Select the SMF_Selection_Subscription_Data_Retrieval",
                                      choices=['Retrieve_SMF_Selection_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["SMF_Selection_Subscription_Data_Retrieval"] == 'Retrieve_SMF_Selection_Data':
                        UDM.Subscriber_Data_Management.SMF_Selection_Subscription_Data_Retrieval.Retrieve_SMF_Selection_Data()

                def UE_Context_In_SMF_Data_Retrieval():
                    questions = [
                        inquirer.List('UE_Context_In_SMF_Data_Retrieval',
                                      message="Select the UE_Context_In_SMF_Data_Retrieval",
                                      choices=['Retrieve_UE_Context_in_SMF_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["UE_Context_In_SMF_Data_Retrieval"] == 'Retrieve_UE_Context_in_SMF_Data':
                        UDM.Subscriber_Data_Management.UE_Context_In_SMF_Data_Retrieval.Retrieve_UE_Context_in_SMF_Data()

                def UE_Context_In_SMSF_Data_Retrieval():
                    questions = [
                        inquirer.List('UE_Context_In_SMSF_Data_Retrieval',
                                      message="Select the UE_Context_In_SMSF_Data_Retrieval",
                                      choices=['Retrieve_UE_Context_in_SMSF_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["UE_Context_In_SMSF_Data_Retrieval"] == 'Retrieve_UE_Context_in_SMSF_Data':
                        UDM.Subscriber_Data_Management.UE_Context_In_SMSF_Data_Retrieval.Retrieve_UE_Context_in_SMSF_Data()

                def Trace_Configuration_Data_Retrieval():
                    questions = [
                        inquirer.List('Trace_Configuration_Data_Retrieval',
                                      message="Select the Trace_Configuration_Data_Retrieval",
                                      choices=['Retrieve_Trace_Configuration_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["Trace_Configuration_Data_Retrieval"] == 'Retrieve_Trace_Configuration_Data':
                        UDM.Subscriber_Data_Management.Trace_Configuration_Data_Retrieval.Retrieve_Trace_Configuration_Data()

                def Session_Management_Subscription_Data_Retrieval():
                    questions = [
                        inquirer.List('Session_Management_Subscription_Data_Retrieval',
                                      message="Select the Session_Management_Subscription_Data_Retrieval",
                                      choices=['Retrieve_Session_Management_Subscription_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["Session_Management_Subscription_Data_Retrieval"] == 'Retrieve_Session_Management_Subscription_Data':
                        UDM.Subscriber_Data_Management.Session_Management_Subscription_Data_Retrieval.Retrieve_Session_Management_Subscription_Data()

                def SMS_Subscription_Data_Retrieval():
                    questions = [
                        inquirer.List('SMS_Subscription_Data_Retrieval',
                                      message="Select the SMS_Subscription_Data_Retrieval",
                                      choices=['Retrieve_SMS_Subscription_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["SMS_Subscription_Data_Retrieval"] == 'Retrieve_SMS_Subscription_Data':
                        UDM.Subscriber_Data_Management.SMS_Subscription_Data_Retrieval.Retrieve_SMS_Subscription_Data()

                def SMS_Management_Subscription_Data_Retrieval():
                    questions = [
                        inquirer.List('SMS_Management_Subscription_Data_Retrieval',
                                      message="Select the SMS_Management_Subscription_Data_Retrieval",
                                      choices=['Retrieve_SMS_Management_Subscription_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["SMS_Management_Subscription_Data_Retrieval"] == 'Retrieve_SMS_Management_Subscription_Data':
                        UDM.Subscriber_Data_Management.SMS_Management_Subscription_Data_Retrieval.Retrieve_SMS_Management_Subscription_Data()

                def Subscription_Creation():
                    questions = [
                        inquirer.List('Subscription_Creation',
                                      message="Select the Subscription_Creation",
                                      choices=['Subscribe_to_Notifications'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["Subscription_Creation"] == 'Subscribe_to_Notifications':
                        UDM.Subscriber_Data_Management.Subscription_Creation.Subscribe_to_Notifications()

                def Subscription_Deletion():
                    questions = [
                        inquirer.List('Subscription_Deletion',
                                      message="Select the Subscription_Deletion",
                                      choices=['Unsubscribe'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["Subscription_Deletion"] == 'Unsubscribe':
                        UDM.Subscriber_Data_Management.Subscription_Deletion.Unsubscribe()

                def Subscription_Modification():
                    questions = [
                        inquirer.List('Subscription_Modification',
                                      message="Select the Subscription_Modification",
                                      choices=['Modify_Subscription', 'Modify_Shared_Subscription_Data_Notification_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["Subscription_Modification"] == 'Modify_Subscription':
                        UDM.Subscriber_Data_Management.Subscription_Modification.Modify_Subscription()

                    elif answers["Subscription_Modification"] == 'Modify_Shared_Subscription_Data_Notification_Subscription':
                        UDM.Subscriber_Data_Management.Subscription_Modification.Modify_Shared_Subscription_Data_Notification_Subscription()

                def GPSI_to_SUPI_Translation():
                    questions = [
                        inquirer.List('GPSI_to_SUPI_Translation',
                                      message="Select the GPSI_to_SUPI_Translation",
                                      choices=['Retieve_SUPI'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["GPSI_to_SUPI_Translation"] == 'Retieve_SUPI':
                        UDM.Subscriber_Data_Management.GPSI_to_SUPI_Translation.Retieve_SUPI()

                def Providing_acknowledgement_of_Steering_of_Roaming():
                    questions = [
                        inquirer.List('Providing_acknowledgement_of_Steering_of_Roaming',
                                      message="Select the Providing_acknowledgement_of_Steering_of_Roaming",
                                      choices=['Provide_SoR_Ack'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["Providing_acknowledgement_of_Steering_of_Roaming"] == 'Provide_SoR_Ack':
                        UDM.Subscriber_Data_Management.Providing_acknowledgement_of_Steering_of_Roaming.Provide_SoR_Ack()

                def Providing_acknowledgement_of_UE_Parameters_Update():
                    questions = [
                        inquirer.List('Providing_acknowledgement_of_UE_Parameters_Update',
                                      message="Select the Providing_acknowledgement_of_UE_Parameters_Update",
                                      choices=['UE_Parameter_Update_Ack'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["Providing_acknowledgement_of_UE_Parameters_Update"] == 'UE_Parameter_Update_Ack':
                        UDM.Subscriber_Data_Management.Providing_acknowledgement_of_UE_Parameters_Update.UE_Parameter_Update_Ack()

                def Providing_acknowledgement_of_S_NSSAIs_Update():
                    questions = [
                        inquirer.List('Providing_acknowledgement_of_S_NSSAIs_Update',
                                      message="Select the Providing_acknowledgement_of_S_NSSAIs_Update",
                                      choices=['Network_Slicing_Subscription_Change_Ack'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["Providing_acknowledgement_of_S_NSSAIs_Update"] == 'Network_Slicing_Subscription_Change_Ack':
                        UDM.Subscriber_Data_Management.Providing_acknowledgement_of_S_NSSAIs_Update.Network_Slicing_Subscription_Change_Ack()

                def Retrieval_of_shared_data():
                    questions = [
                        inquirer.List('Retrieval_of_shared_data',
                                      message="Select the Retrieval_of_shared_data",
                                      choices=['Retrieve_Shared_Subscription_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["Retrieval_of_shared_data"] == 'Retrieve_Shared_Subscription_Data':
                        UDM.Subscriber_Data_Management.Retrieval_of_shared_data.Retrieve_Shared_Subscription_Data()

                def Subscription_Creation_for_shared_data():
                    questions = [
                        inquirer.List('Subscription_Creation_for_shared_data',
                                      message="Select the Subscription_Creation_for_shared_data",
                                      choices=['Subscribe_to_Shared_Subscription_Notifications'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["Subscription_Creation_for_shared_data"] == 'Subscribe_to_Shared_Subscription_Notifications':
                        UDM.Subscriber_Data_Management.Subscription_Creation_for_shared_data.Subscribe_to_Shared_Subscription_Notifications()

                def Subscription_Deletion_for_shared_data():
                    questions = [
                        inquirer.List('Subscription_Deletion_for_shared_data',
                                      message="Select the Subscription_Deletion_for_shared_data",
                                      choices=['Unsubscribe_from_Shared_Subscription_Data_Notifications'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["Subscription_Deletion_for_shared_data"] == 'Unsubscribe_from_Shared_Subscription_Data_Notifications':
                        UDM.Subscriber_Data_Management.Subscription_Deletion_for_shared_data.Unsubscribe_from_Shared_Subscription_Data_Notifications()

                def Group_Identifiers():
                    questions = [
                        inquirer.List('Group_Identifiers',
                                      message="Select the Group_Identifiers",
                                      choices=['Retrieve_Group_Identifier'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscriber_Data_Management()

                    elif answers["Group_Identifiers"] == 'Retrieve_Group_Identifier':
                        UDM.Subscriber_Data_Management.Group_Identifiers.Retrieve_Group_Identifier()

                def UE_Context_Management():
                    questions = [
                        inquirer.List('UE_Context_Management',
                                      message="Select the UE_Context_Management",
                                      choices=['AMF_registration_for_3GPP_access', 'Parameter_update_in_the_AMF_registration_for_3GPP_access', 'AMF_3Gpp_access_Registration_Info_Retrieval', 'AMF_registration_for_non_3GPP_access', 'Parameter_update_in_the_AMF_registration_for_non_3GPP_access', 'AMF_non_3GPP_access_Registration_Info_Retrieval', 'SMF_Registration', 'SMF_Deregistration', 'SMSF_registration_for_3GPP_access', 'SMSF_Deregistration_for_3GPP_Access', 'SMSF_3GPP_access_Registration_Info_Retrieval', 'SMSF_registration_for_non_3GPP_access', 'SMSF_Deregistration_for_non_3GPP_access', 'SMSF_non_3GPP_access_Registration_Info_Retrieval'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        udm()

                    elif answers["UE_Context_Management"] == 'AMF_registration_for_3GPP_access':
                        AMF_registration_for_3GPP_access()

                    elif answers["UE_Context_Management"] == 'Parameter_update_in_the_AMF_registration_for_3GPP_access':
                        Parameter_update_in_the_AMF_registration_for_3GPP_access()

                    elif answers["UE_Context_Management"] == 'AMF_3Gpp_access_Registration_Info_Retrieval':
                        AMF_3Gpp_access_Registration_Info_Retrieval()

                    elif answers["UE_Context_Management"] == 'AMF_registration_for_non_3GPP_access':
                        AMF_registration_for_non_3GPP_access()

                    elif answers["UE_Context_Management"] == 'Parameter_update_in_the_AMF_registration_for_non_3GPP_access':
                        Parameter_update_in_the_AMF_registration_for_non_3GPP_access()

                    elif answers["UE_Context_Management"] == 'AMF_non_3GPP_access_Registration_Info_Retrieval':
                        AMF_non_3GPP_access_Registration_Info_Retrieval()

                    elif answers["UE_Context_Management"] == 'SMF_Registration':
                        SMF_Registration()

                    elif answers["UE_Context_Management"] == 'SMF_Deregistration':
                        SMF_Deregistration()

                    elif answers["UE_Context_Management"] == 'SMSF_registration_for_3GPP_access':
                        SMSF_registration_for_3GPP_access()

                    elif answers["UE_Context_Management"] == 'SMSF_Deregistration_for_3GPP_Access':
                        SMSF_Deregistration_for_3GPP_Access()

                    elif answers["UE_Context_Management"] == 'SMSF_3GPP_access_Registration_Info_Retrieval':
                        SMSF_3GPP_access_Registration_Info_Retrieval()

                    elif answers["UE_Context_Management"] == 'SMSF_registration_for_non_3GPP_access':
                        SMSF_registration_for_non_3GPP_access()

                    elif answers["UE_Context_Management"] == 'SMSF_Deregistration_for_non_3GPP_access':
                        SMSF_Deregistration_for_non_3GPP_access()

                    elif answers["UE_Context_Management"] == 'SMSF_non_3GPP_access_Registration_Info_Retrieval':
                        SMSF_non_3GPP_access_Registration_Info_Retrieval()

                def AMF_registration_for_3GPP_access():
                    questions = [
                        inquirer.List('AMF_registration_for_3GPP_access',
                                      message="Select the AMF_registration_for_3GPP_access",
                                      choices=['Register_AMF_for_3GPP_Access'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Context_Management()

                    elif answers["AMF_registration_for_3GPP_access"] == 'Register_AMF_for_3GPP_Access':
                        UDM.UE_Context_Management.AMF_registration_for_3GPP_access.Register_AMF_for_3GPP_Access()

                def Parameter_update_in_the_AMF_registration_for_3GPP_access():
                    questions = [
                        inquirer.List('Parameter_update_in_the_AMF_registration_for_3GPP_access',
                                      message="Select the Parameter_update_in_the_AMF_registration_for_3GPP_access",
                                      choices=['Update_UE_Parameter_3GPP_Access'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Context_Management()

                    elif answers["Parameter_update_in_the_AMF_registration_for_3GPP_access"] == 'Update_UE_Parameter_3GPP_Access':
                        UDM.UE_Context_Management.Parameter_update_in_the_AMF_registration_for_3GPP_access.Update_UE_Parameter_3GPP_Access()

                def AMF_3Gpp_access_Registration_Info_Retrieval():
                    questions = [
                        inquirer.List('AMF_3Gpp_access_Registration_Info_Retrieval',
                                      message="Select the AMF_3Gpp_access_Registration_Info_Retrieval",
                                      choices=['Retrieve_UE_Context_3GPP_Access'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Context_Management()

                    elif answers["AMF_3Gpp_access_Registration_Info_Retrieval"] == 'Retrieve_UE_Context_3GPP_Access':
                        UDM.UE_Context_Management.AMF_3Gpp_access_Registration_Info_Retrieval.Retrieve_UE_Context_3GPP_Access()

                def AMF_registration_for_non_3GPP_access():
                    questions = [
                        inquirer.List('AMF_registration_for_non_3GPP_access',
                                      message="Select the AMF_registration_for_non_3GPP_access",
                                      choices=['Register_AMF_for_Non_3GPP_Access'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Context_Management()

                    elif answers["AMF_registration_for_non_3GPP_access"] == 'Register_AMF_for_Non_3GPP_Access':
                        UDM.UE_Context_Management.AMF_registration_for_non_3GPP_access.Register_AMF_for_Non_3GPP_Access()

                def Parameter_update_in_the_AMF_registration_for_non_3GPP_access():
                    questions = [
                        inquirer.List('Parameter_update_in_the_AMF_registration_for_non_3GPP_access',
                                      message="Select the Parameter_update_in_the_AMF_registration_for_non_3GPP_access",
                                      choices=['Update_Registration_Non_3GPP_Access'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Context_Management()

                    elif answers["Parameter_update_in_the_AMF_registration_for_non_3GPP_access"] == 'Update_Registration_Non_3GPP_Access':
                        UDM.UE_Context_Management.Parameter_update_in_the_AMF_registration_for_non_3GPP_access.Update_Registration_Non_3GPP_Access()

                def AMF_non_3GPP_access_Registration_Info_Retrieval():
                    questions = [
                        inquirer.List('AMF_non_3GPP_access_Registration_Info_Retrieval',
                                      message="Select the AMF_non_3GPP_access_Registration_Info_Retrieval",
                                      choices=['Retrieve_UE_Context_Non_3GPP_Access'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Context_Management()

                    elif answers["AMF_non_3GPP_access_Registration_Info_Retrieval"] == 'Retrieve_UE_Context_Non_3GPP_Access':
                        UDM.UE_Context_Management.AMF_non_3GPP_access_Registration_Info_Retrieval.Retrieve_UE_Context_Non_3GPP_Access()

                def SMF_Registration():
                    questions = [
                        inquirer.List('SMF_Registration',
                                      message="Select the SMF_Registration",
                                      choices=['Register_SMF'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Context_Management()

                    elif answers["SMF_Registration"] == 'Register_SMF':
                        UDM.UE_Context_Management.SMF_Registration.Register_SMF()

                def SMF_Deregistration():
                    questions = [
                        inquirer.List('SMF_Deregistration',
                                      message="Select the SMF_Deregistration",
                                      choices=['Deregister_SMF'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Context_Management()

                    elif answers["SMF_Deregistration"] == 'Deregister_SMF':
                        UDM.UE_Context_Management.SMF_Deregistration.Deregister_SMF()

                def SMSF_registration_for_3GPP_access():
                    questions = [
                        inquirer.List('SMSF_registration_for_3GPP_access',
                                      message="Select the SMSF_registration_for_3GPP_access",
                                      choices=['Register_SMSF_for_3GPP_Access'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Context_Management()

                    elif answers["SMSF_registration_for_3GPP_access"] == 'Register_SMSF_for_3GPP_Access':
                        UDM.UE_Context_Management.SMSF_registration_for_3GPP_access.Register_SMSF_for_3GPP_Access()

                def SMSF_Deregistration_for_3GPP_Access():
                    questions = [
                        inquirer.List('SMSF_Deregistration_for_3GPP_Access',
                                      message="Select the SMSF_Deregistration_for_3GPP_Access",
                                      choices=['Deregiser_SMSF_3GPP_Access'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Context_Management()

                    elif answers["SMSF_Deregistration_for_3GPP_Access"] == 'Deregiser_SMSF_3GPP_Access':
                        UDM.UE_Context_Management.SMSF_Deregistration_for_3GPP_Access.Deregiser_SMSF_3GPP_Access()

                def SMSF_3GPP_access_Registration_Info_Retrieval():
                    questions = [
                        inquirer.List('SMSF_3GPP_access_Registration_Info_Retrieval',
                                      message="Select the SMSF_3GPP_access_Registration_Info_Retrieval",
                                      choices=['Retrieve_SMSF_Registration_3GPP_Access'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Context_Management()

                    elif answers["SMSF_3GPP_access_Registration_Info_Retrieval"] == 'Retrieve_SMSF_Registration_3GPP_Access':
                        UDM.UE_Context_Management.SMSF_3GPP_access_Registration_Info_Retrieval.Retrieve_SMSF_Registration_3GPP_Access()

                def SMSF_registration_for_non_3GPP_access():
                    questions = [
                        inquirer.List('SMSF_registration_for_non_3GPP_access',
                                      message="Select the SMSF_registration_for_non_3GPP_access",
                                      choices=['Register_SMSF_for_Non_3GPP_Access'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Context_Management()

                    elif answers["SMSF_registration_for_non_3GPP_access"] == 'Register_SMSF_for_Non_3GPP_Access':
                        UDM.UE_Context_Management.SMSF_registration_for_non_3GPP_access.Register_SMSF_for_Non_3GPP_Access()

                def SMSF_Deregistration_for_non_3GPP_access():
                    questions = [
                        inquirer.List('SMSF_Deregistration_for_non_3GPP_access',
                                      message="Select the SMSF_Deregistration_for_non_3GPP_access",
                                      choices=['Deregiser_SMSF_Non_3GPP_Access'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Context_Management()

                    elif answers["SMSF_Deregistration_for_non_3GPP_access"] == 'Deregiser_SMSF_Non_3GPP_Access':
                        UDM.UE_Context_Management.SMSF_Deregistration_for_non_3GPP_access.Deregiser_SMSF_Non_3GPP_Access()

                def SMSF_non_3GPP_access_Registration_Info_Retrieval():
                    questions = [
                        inquirer.List('SMSF_non_3GPP_access_Registration_Info_Retrieval',
                                      message="Select the SMSF_non_3GPP_access_Registration_Info_Retrieval",
                                      choices=['Retrieve_SMSF_Registration_Non_3GPP_Access'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Context_Management()

                    elif answers["SMSF_non_3GPP_access_Registration_Info_Retrieval"] == 'Retrieve_SMSF_Registration_Non_3GPP_Access':
                        UDM.UE_Context_Management.SMSF_non_3GPP_access_Registration_Info_Retrieval.Retrieve_SMSF_Registration_Non_3GPP_Access()

                def UE_Authentication():
                    questions = [
                        inquirer.List('UE_Authentication',
                                      message="Select the UE_Authentication",
                                      choices=['Generate_Auth_Data', 'Confirm_Auth'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        udm()

                    elif answers["UE_Authentication"] == 'Generate_Auth_Data':
                        Generate_Auth_Data()

                    elif answers["UE_Authentication"] == 'Confirm_Auth':
                        Confirm_Auth()

                def Generate_Auth_Data():
                    questions = [
                        inquirer.List('Generate_Auth_Data',
                                      message="Select the Generate_Auth_Data",
                                      choices=['Generate_Authentication_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Authentication()

                    elif answers["Generate_Auth_Data"] == 'Generate_Authentication_Data':
                        UDM.UE_Authentication.Generate_Auth_Data.Generate_Authentication_Data()

                def Confirm_Auth():
                    questions = [
                        inquirer.List('Confirm_Auth',
                                      message="Select the Confirm_Auth",
                                      choices=['Confirm_Authentication'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Authentication()

                    elif answers["Confirm_Auth"] == 'Confirm_Authentication':
                        UDM.UE_Authentication.Confirm_Auth.Confirm_Authentication()

                def Event_Exposure():
                    questions = [
                        inquirer.List('Event_Exposure',
                                      message="Select the Event_Exposure",
                                      choices=['Create_EE_Subscription', 'Delete_EE_Subscription', 'Update_EE_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        udm()

                    elif answers["Event_Exposure"] == 'Create_EE_Subscription':
                        Create_EE_Subscription()

                    elif answers["Event_Exposure"] == 'Delete_EE_Subscription':
                        Delete_EE_Subscription()

                    elif answers["Event_Exposure"] == 'Update_EE_Subscription':
                        Update_EE_Subscription()

                def Create_EE_Subscription():
                    questions = [
                        inquirer.List('Create_EE_Subscription',
                                      message="Select the Create_EE_Subscription",
                                      choices=['Create_Event_Exposure_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Event_Exposure()

                    elif answers["Create_EE_Subscription"] == 'Create_Event_Exposure_Subscription':
                        UDM.Event_Exposure.Create_EE_Subscription.Create_Event_Exposure_Subscription()

                def Delete_EE_Subscription():
                    questions = [
                        inquirer.List('Delete_EE_Subscription',
                                      message="Select the Delete_EE_Subscription",
                                      choices=['Delete_Event_Exposure_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Event_Exposure()

                    elif answers["Delete_EE_Subscription"] == 'Delete_Event_Exposure_Subscription':
                        UDM.Event_Exposure.Delete_EE_Subscription.Delete_Event_Exposure_Subscription()

                def Update_EE_Subscription():
                    questions = [
                        inquirer.List('Update_EE_Subscription',
                                      message="Select the Update_EE_Subscription",
                                      choices=['Update_Event_Exposure_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Event_Exposure()

                    elif answers["Update_EE_Subscription"] == 'Update_Event_Exposure_Subscription':
                        UDM.Event_Exposure.Update_EE_Subscription.Update_Event_Exposure_Subscription()

                def Parameter_Provisioning():
                    questions = [
                        inquirer.List('Parameter_Provisioning',
                                      message="Select the Parameter_Provisioning",
                                      choices=['Subscription_Data_Update'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        udm()

                    elif answers["Parameter_Provisioning"] == 'Subscription_Data_Update':
                        Subscription_Data_Update()

                def Subscription_Data_Update():
                    questions = [
                        inquirer.List('Subscription_Data_Update',
                                      message="Select the Subscription_Data_Update",
                                      choices=['Update_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Parameter_Provisioning()

                    elif answers["Subscription_Data_Update"] == 'Update_Subscription':
                        UDM.Parameter_Provisioning.Subscription_Data_Update.Update_Subscription()

                if answers == None:
                    fun()

                elif answers["UDM"] == 'Subscriber_Data_Management':
                    Subscriber_Data_Management()

                elif answers["UDM"] == 'UE_Context_Management':
                    UE_Context_Management()

                elif answers["UDM"] == 'UE_Authentication':
                    UE_Authentication()

                elif answers["UDM"] == 'Event_Exposure':
                    Event_Exposure()

                elif answers["UDM"] == 'Parameter_Provisioning':
                    Parameter_Provisioning()

            udm()

################################################ UDR #########################################################################################

        elif answers["Function"] == 'UDR':

            def udr():
                questions = [
                    inquirer.List('UDR',
                                  message="Select the UDR",
                                  choices=['Subscription_Data', 'Policy_Data', 'Exposure_Data', 'Application_Data'],), ]
                answers = inquirer.prompt(questions)

                def Subscription_Data():
                    questions = [
                        inquirer.List('Subscription_Data',
                                      message="Select the Subscription_Data",
                                      choices=['Authentication_Data_Document', 'Authentication_Subscription_Document', 'Authentication_Status_Document', 'AuthEvent_Document', 'Authentication_SoR_Document', 'Authentication_UPU_Document', 'Provisioned_Data_Document', 'Provisioned_Data_Document', 'Access_And_Mobility_Subscription_Data_Document', 'SMF_Selection_Subscription_Data_Document', 'Session_Management_Subscription_Data', 'AMF_3GPP_Access_Registration_Document', 'AMF_Non_3GPP_Access_Registration_Document', 'SMF_Registrations_Collection', 'SMF_Registration_Document', 'Operator_Specific_Data_Container_Document', 'SMSF_3GPP_Registration_Document', 'SMSF_Non_3GPP_Registration_Document', 'SMS_Management_Subscription_Data_Document', 'SMS_Subscription_Data_Document', 'Parameter_Provision_Document', 'ProvisionedParameterData_Document', 'Event_Exposure_Subscriptions_Collection', 'Event_Exposure_Subscription_Document', 'AMF_Subscription_Info_Document', 'Event_AMF_Subscription_Info_Document', 'AmfSubscriptionInfo_Document', 'Query_AMF_Subscription_Info_Document', 'Event_Exposure_Group_Subscriptions_Collection', 'Event_Exposure_Data_Document', 'SDM_Subscriptions_Collection', 'SDM_Subscription_Document', 'Retrieval_of_shared_data', 'Subs_To_Nofify_Collection', 'Subs_To_Notify_Collection', 'Subs_To_Notify_Document', 'Trace_Data_Document', 'Query_Identity_Data_by_SUPI_or_GPSI_Document', 'Query_ODB_Data_by_SUPI_or_GPSI_Document', 'Context_Data_Document', 'Group_Identifiers'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        udr()

                    elif answers["Subscription_Data"] == 'Authentication_Data_Document':
                        Authentication_Data_Document()

                    elif answers["Subscription_Data"] == 'Authentication_Subscription_Document':
                        Authentication_Subscription_Document()

                    elif answers["Subscription_Data"] == 'Authentication_Status_Document':
                        Authentication_Status_Document()

                    elif answers["Subscription_Data"] == 'AuthEvent_Document':
                        AuthEvent_Document()

                    elif answers["Subscription_Data"] == 'Authentication_SoR_Document':
                        Authentication_SoR_Document()

                    elif answers["Subscription_Data"] == 'Authentication_UPU_Document':
                        Authentication_UPU_Document()

                    elif answers["Subscription_Data"] == 'Provisioned_Data_Document':
                        Provisioned_Data_Document()

                    elif answers["Subscription_Data"] == 'Access_And_Mobility_Subscription_Data_Document':
                        Access_And_Mobility_Subscription_Data_Document()

                    elif answers["Subscription_Data"] == 'SMF_Selection_Subscription_Data_Document':
                        SMF_Selection_Subscription_Data_Document()

                    elif answers["Subscription_Data"] == 'Session_Management_Subscription_Data':
                        Session_Management_Subscription_Data()

                    elif answers["Subscription_Data"] == 'AMF_3GPP_Access_Registration_Document':
                        AMF_3GPP_Access_Registration_Document()

                    elif answers["Subscription_Data"] == 'AMF_Non_3GPP_Access_Registration_Document':
                        AMF_Non_3GPP_Access_Registration_Document()

                    elif answers["Subscription_Data"] == 'SMF_Registrations_Collection':
                        SMF_Registrations_Collection()

                    elif answers["Subscription_Data"] == 'SMF_Registration_Document':
                        SMF_Registration_Document()

                    elif answers["Subscription_Data"] == 'Operator_Specific_Data_Container_Document':
                        Operator_Specific_Data_Container_Document()

                    elif answers["Subscription_Data"] == 'SMSF_3GPP_Registration_Document':
                        SMSF_3GPP_Registration_Document()

                    elif answers["Subscription_Data"] == 'SMSF_Non_3GPP_Registration_Document':
                        SMSF_Non_3GPP_Registration_Document()

                    elif answers["Subscription_Data"] == 'SMS_Management_Subscription_Data_Document':
                        SMS_Management_Subscription_Data_Document()

                    elif answers["Subscription_Data"] == 'SMS_Subscription_Data_Document':
                        SMS_Subscription_Data_Document()

                    elif answers["Subscription_Data"] == 'Parameter_Provision_Document':
                        Parameter_Provision_Document()

                    elif answers["Subscription_Data"] == 'ProvisionedParameterData_Document':
                        ProvisionedParameterData_Document()

                    elif answers["Subscription_Data"] == 'Event_Exposure_Subscriptions_Collection':
                        Event_Exposure_Subscriptions_Collection()

                    elif answers["Subscription_Data"] == 'Event_Exposure_Subscription_Document':
                        Event_Exposure_Subscription_Document()

                    elif answers["Subscription_Data"] == 'AMF_Subscription_Info_Document':
                        AMF_Subscription_Info_Document()

                    elif answers["Subscription_Data"] == 'Event_AMF_Subscription_Info_Document':
                        Event_AMF_Subscription_Info_Document()

                    elif answers["Subscription_Data"] == 'AmfSubscriptionInfo_Document':
                        AmfSubscriptionInfo_Document()

                    elif answers["Subscription_Data"] == 'Query_AMF_Subscription_Info_Document':
                        Query_AMF_Subscription_Info_Document()

                    elif answers["Subscription_Data"] == 'Event_Exposure_Group_Subscriptions_Collection':
                        Event_Exposure_Group_Subscriptions_Collection()

                    elif answers["Subscription_Data"] == 'Event_Exposure_Data_Document':
                        Event_Exposure_Data_Document()

                    elif answers["Subscription_Data"] == 'SDM_Subscriptions_Collection':
                        SDM_Subscriptions_Collection()

                    elif answers["Subscription_Data"] == 'SDM_Subscription_Document':
                        SDM_Subscription_Document()

                    elif answers["Subscription_Data"] == 'Retrieval_of_shared_data':
                        Retrieval_of_shared_data()

                    elif answers["Subscription_Data"] == 'Subs_To_Nofify_Collection':
                        Subs_To_Nofify_Collection()

                    elif answers["Subscription_Data"] == 'Subs_To_Notify_Collection':
                        Subs_To_Notify_Collection()

                    elif answers["Subscription_Data"] == 'Subs_To_Notify_Document':
                        Subs_To_Notify_Document()

                    elif answers["Subscription_Data"] == 'Trace_Data_Document':
                        Trace_Data_Document()

                    elif answers["Subscription_Data"] == 'Query_Identity_Data_by_SUPI_or_GPSI_Document':
                        Query_Identity_Data_by_SUPI_or_GPSI_Document()

                    elif answers["Subscription_Data"] == 'Query_ODB_Data_by_SUPI_or_GPSI_Document':
                        Query_ODB_Data_by_SUPI_or_GPSI_Document()

                    elif answers["Subscription_Data"] == 'Context_Data_Document':
                        Context_Data_Document()

                    elif answers["Subscription_Data"] == 'Group_Identifiers':
                        Group_Identifiers()

                def Authentication_Data_Document():
                    questions = [
                        inquirer.List('Authentication_Data_Document',
                                      message="Select the Authentication_Data_Document",
                                      choices=['Query_Authentication_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Authentication_Data_Document"] == 'Query_Authentication_Data':
                        UDR.Subscription_Data.Authentication_Data_Document.Query_Authentication_Data()

                def Authentication_Subscription_Document():
                    questions = [
                        inquirer.List('Authentication_Subscription_Document',
                                      message="Select the Authentication_Subscription_Document",
                                      choices=['Modify_Authentication_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Authentication_Subscription_Document"] == 'Modify_Authentication_Data':
                        UDR.Subscription_Data.Authentication_Subscription_Document.Modify_Authentication_Data()

                def Authentication_Status_Document():
                    questions = [
                        inquirer.List('Authentication_Status_Document',
                                      message="Select the Authentication_Status_Document",
                                      choices=['Create_Authentication_Status'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Authentication_Status_Document"] == 'Create_Authentication_Status':
                        UDR.Subscription_Data.Authentication_Status_Document.Create_Authentication_Status()

                def AuthEvent_Document():
                    questions = [
                        inquirer.List('AuthEvent_Document',
                                      message="Select the AuthEvent_Document",
                                      choices=['Query_Authentication_Status'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["AuthEvent_Document"] == 'Query_Authentication_Status':
                        UDR.Subscription_Data.AuthEvent_Document.Query_Authentication_Status()

                def Authentication_SoR_Document():
                    questions = [
                        inquirer.List('Authentication_SoR_Document',
                                      message="Select the Authentication_SoR_Document",
                                      choices=['Store_Authentication_SoR', 'Query_Authentication_SoR'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Authentication_SoR_Document"] == 'Store_Authentication_SoR':
                        UDR.Subscription_Data.Authentication_SoR_Document.Store_Authentication_SoR()

                    elif answers["Authentication_SoR_Document"] == 'Query_Authentication_SoR':
                        UDR.Subscription_Data.Authentication_SoR_Document.Query_Authentication_SoR()

                def Authentication_UPU_Document():
                    questions = [
                        inquirer.List('Authentication_UPU_Document',
                                      message="Select the Authentication_UPU_Document",
                                      choices=['Store_UE_Parameter_Update_Data', 'Query_UE_Parameter_Update_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Authentication_UPU_Document"] == 'Store_UE_Parameter_Update_Data':
                        UDR.Subscription_Data.Authentication_UPU_Document.Store_UE_Parameter_Update_Data()

                    elif answers["Authentication_UPU_Document"] == 'Query_UE_Parameter_Update_Data':
                        UDR.Subscription_Data.Authentication_UPU_Document.Query_UE_Parameter_Update_Data()

                # def Provisioned_Data_Document():
                #     questions = [
                #         inquirer.List('Provisioned_Data_Document',
                #                       message="Select the Provisioned_Data_Document",
                #                       choices=['Retrieve_Trace_Configuration_Data'],), ]
                #     answers = inquirer.prompt(questions)

                #     if answers == None:
                #         Subscription_Data()

                #     elif answers["Provisioned_Data_Document"] == 'Retrieve_Trace_Configuration_Data':
                #         UDR.Subscription_Data.Provisioned_Data_Document.Retrieve_Trace_Configuration_Data()

                def Provisioned_Data_Document():
                    questions = [
                        inquirer.List('Provisioned_Data_Document',
                                      message="Select the Provisioned_Data_Document",
                                      choices=['Query_Provisioned_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Provisioned_Data_Document"] == 'Query_Provisioned_Data':
                        UDR.Subscription_Data.Provisioned_Data_Document.Query_Provisioned_Data()

                def Access_And_Mobility_Subscription_Data_Document():
                    questions = [
                        inquirer.List('Access_And_Mobility_Subscription_Data_Document',
                                      message="Select the Access_And_Mobility_Subscription_Data_Document",
                                      choices=['Query_AM_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Access_And_Mobility_Subscription_Data_Document"] == 'Query_AM_Data':
                        UDR.Subscription_Data.Access_And_Mobility_Subscription_Data_Document.Query_AM_Data()

                def SMF_Selection_Subscription_Data_Document():
                    questions = [
                        inquirer.List('SMF_Selection_Subscription_Data_Document',
                                      message="Select the SMF_Selection_Subscription_Data_Document",
                                      choices=['Query_Selection_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["SMF_Selection_Subscription_Data_Document"] == 'Query_Selection_Data':
                        UDR.Subscription_Data.SMF_Selection_Subscription_Data_Document.Query_Selection_Data()

                def Session_Management_Subscription_Data():
                    questions = [
                        inquirer.List('Session_Management_Subscription_Data',
                                      message="Select the Session_Management_Subscription_Data",
                                      choices=['Query_SM_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Session_Management_Subscription_Data"] == 'Query_SM_Data':
                        UDR.Subscription_Data.Session_Management_Subscription_Data.Query_SM_Data()

                def AMF_3GPP_Access_Registration_Document():
                    questions = [
                        inquirer.List('AMF_3GPP_Access_Registration_Document',
                                      message="Select the AMF_3GPP_Access_Registration_Document",
                                      choices=['Query_AMF_Context_3GPP_Access', 'Create_AMF_Context_3GPP_Access', 'Modify_AMF_Context_3GPP_Access'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["AMF_3GPP_Access_Registration_Document"] == 'Query_AMF_Context_3GPP_Access':
                        UDR.Subscription_Data.AMF_3GPP_Access_Registration_Document.Query_AMF_Context_3GPP_Access()

                    elif answers["AMF_3GPP_Access_Registration_Document"] == 'Create_AMF_Context_3GPP_Access':
                        UDR.Subscription_Data.AMF_3GPP_Access_Registration_Document.Create_AMF_Context_3GPP_Access()

                    elif answers["AMF_3GPP_Access_Registration_Document"] == 'Modify_AMF_Context_3GPP_Access':
                        UDR.Subscription_Data.AMF_3GPP_Access_Registration_Document.Modify_AMF_Context_3GPP_Access()

                def AMF_Non_3GPP_Access_Registration_Document():
                    questions = [
                        inquirer.List('AMF_Non_3GPP_Access_Registration_Document',
                                      message="Select the AMF_Non_3GPP_Access_Registration_Document",
                                      choices=['Retrieve_AMF_Context_Non_3GPP_Access', 'Store_AMF_Context_Non_3GPP_Access', 'Modify_AMF_Context_Non_3GPP_Access'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["AMF_Non_3GPP_Access_Registration_Document"] == 'Retrieve_AMF_Context_Non_3GPP_Access':
                        UDR.Subscription_Data.AMF_Non_3GPP_Access_Registration_Document.Retrieve_AMF_Context_Non_3GPP_Access()

                    elif answers["AMF_Non_3GPP_Access_Registration_Document"] == 'Store_AMF_Context_Non_3GPP_Access':
                        UDR.Subscription_Data.AMF_Non_3GPP_Access_Registration_Document.Store_AMF_Context_Non_3GPP_Access()

                    elif answers["AMF_Non_3GPP_Access_Registration_Document"] == 'Modify_AMF_Context_Non_3GPP_Access':
                        UDR.Subscription_Data.AMF_Non_3GPP_Access_Registration_Document.Modify_AMF_Context_Non_3GPP_Access()

                def SMF_Registrations_Collection():
                    questions = [
                        inquirer.List('SMF_Registrations_Collection',
                                      message="Select the SMF_Registrations_Collection",
                                      choices=['Query_SMF_Registrations'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["SMF_Registrations_Collection"] == 'Query_SMF_Registrations':
                        UDR.Subscription_Data.SMF_Registrations_Collection.Query_SMF_Registrations()

                def SMF_Registration_Document():
                    questions = [
                        inquirer.List('SMF_Registration_Document',
                                      message="Select the SMF_Registration_Document",
                                      choices=['Query_SMF_Registration', 'Store_SMF_Registration', 'Delete_SMF_Registration'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["SMF_Registration_Document"] == 'Query_SMF_Registration':
                        UDR.Subscription_Data.SMF_Registration_Document.Query_SMF_Registration()

                    elif answers["SMF_Registration_Document"] == 'Store_SMF_Registration':
                        UDR.Subscription_Data.SMF_Registration_Document.Store_SMF_Registration()

                    elif answers["SMF_Registration_Document"] == 'Delete_SMF_Registration':
                        UDR.Subscription_Data.SMF_Registration_Document.Delete_SMF_Registration()

                def Operator_Specific_Data_Container_Document():
                    questions = [
                        inquirer.List('Operator_Specific_Data_Container_Document',
                                      message="Select the Operator_Specific_Data_Container_Document",
                                      choices=['Query_Operator_Specific_Data', 'Modify_Operator_Specific_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Operator_Specific_Data_Container_Document"] == 'Query_Operator_Specific_Data':
                        UDR.Subscription_Data.Operator_Specific_Data_Container_Document.Query_Operator_Specific_Data()

                    elif answers["Operator_Specific_Data_Container_Document"] == 'Modify_Operator_Specific_Data':
                        UDR.Subscription_Data.Operator_Specific_Data_Container_Document.Modify_Operator_Specific_Data()

                def SMSF_3GPP_Registration_Document():
                    questions = [
                        inquirer.List('SMSF_3GPP_Registration_Document',
                                      message="Select the SMSF_3GPP_Registration_Document",
                                      choices=['Store_SMSF_Registration_3GPP_Access', 'Delete_SMSF_Registration_3GPP_Access', 'Query_SMSF_Registration_3GPP_Access'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["SMSF_3GPP_Registration_Document"] == 'Store_SMSF_Registration_3GPP_Access':
                        UDR.Subscription_Data.SMSF_3GPP_Registration_Document.Store_SMSF_Registration_3GPP_Access()

                    elif answers["SMSF_3GPP_Registration_Document"] == 'Delete_SMSF_Registration_3GPP_Access':
                        UDR.Subscription_Data.SMSF_3GPP_Registration_Document.Delete_SMSF_Registration_3GPP_Access()

                    elif answers["SMSF_3GPP_Registration_Document"] == 'Query_SMSF_Registration_3GPP_Access':
                        UDR.Subscription_Data.SMSF_3GPP_Registration_Document.Query_SMSF_Registration_3GPP_Access()

                def SMSF_Non_3GPP_Registration_Document():
                    questions = [
                        inquirer.List('SMSF_Non_3GPP_Registration_Document',
                                      message="Select the SMSF_Non_3GPP_Registration_Document",
                                      choices=['Store_SMSF_Registration_Non_3GPP_Access', 'Delete_SMSF_Registration_Non_3GPP_Access', 'Query_SMSF_Registration_Non_3GPP_Access'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["SMSF_Non_3GPP_Registration_Document"] == 'Store_SMSF_Registration_Non_3GPP_Access':
                        UDR.Subscription_Data.SMSF_Non_3GPP_Registration_Document.Store_SMSF_Registration_Non_3GPP_Access()

                    elif answers["SMSF_Non_3GPP_Registration_Document"] == 'Delete_SMSF_Registration_Non_3GPP_Access':
                        UDR.Subscription_Data.SMSF_Non_3GPP_Registration_Document.Delete_SMSF_Registration_Non_3GPP_Access()

                    elif answers["SMSF_Non_3GPP_Registration_Document"] == 'Query_SMSF_Registration_Non_3GPP_Access':
                        UDR.Subscription_Data.SMSF_Non_3GPP_Registration_Document.Query_SMSF_Registration_Non_3GPP_Access()

                def SMS_Management_Subscription_Data_Document():
                    questions = [
                        inquirer.List('SMS_Management_Subscription_Data_Document',
                                      message="Select the SMS_Management_Subscription_Data_Document",
                                      choices=['Query_SMS_Management_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["SMS_Management_Subscription_Data_Document"] == 'Query_SMS_Management_Data':
                        UDR.Subscription_Data.SMS_Management_Subscription_Data_Document.Query_SMS_Management_Data()

                def SMS_Subscription_Data_Document():
                    questions = [
                        inquirer.List('SMS_Subscription_Data_Document',
                                      message="Select the SMS_Subscription_Data_Document",
                                      choices=['Query_SMS_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["SMS_Subscription_Data_Document"] == 'Query_SMS_Subscription':
                        UDR.Subscription_Data.SMS_Subscription_Data_Document.Query_SMS_Subscription()

                def Parameter_Provision_Document():
                    questions = [
                        inquirer.List('Parameter_Provision_Document',
                                      message="Select the Parameter_Provision_Document",
                                      choices=['Query_PP_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Parameter_Provision_Document"] == 'Query_PP_Data':
                        UDR.Subscription_Data.Parameter_Provision_Document.Query_PP_Data()

                def ProvisionedParameterData_Document():
                    questions = [
                        inquirer.List('ProvisionedParameterData_Document',
                                      message="Select the ProvisionedParameterData_Document",
                                      choices=['Modify_PP_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["ProvisionedParameterData_Document"] == 'Modify_PP_Data':
                        UDR.Subscription_Data.ProvisionedParameterData_Document.Modify_PP_Data()

                def Event_Exposure_Subscriptions_Collection():
                    questions = [
                        inquirer.List('Event_Exposure_Subscriptions_Collection',
                                      message="Select the Event_Exposure_Subscriptions_Collection",
                                      choices=['Query_EE_Subscription', 'Create_EE_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Event_Exposure_Subscriptions_Collection"] == 'Query_EE_Subscription':
                        UDR.Subscription_Data.Event_Exposure_Subscriptions_Collection.Query_EE_Subscription()

                    elif answers["Event_Exposure_Subscriptions_Collection"] == 'Create_EE_Subscription':
                        UDR.Subscription_Data.Event_Exposure_Subscriptions_Collection.Create_EE_Subscription()

                def Event_Exposure_Subscription_Document():
                    questions = [
                        inquirer.List('Event_Exposure_Subscription_Document',
                                      message="Select the Event_Exposure_Subscription_Document",
                                      choices=['Update_EE_Subscription(PUT)', 'Remove_EE_Subscription', 'Update_EE_Subscription(PATCH)', 'Update_EE_Group_Subscription(PUT)', 'Remove_EE_Group_Subscriptions', 'Update_EE_Group_Subscription(PATCH)'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Event_Exposure_Subscription_Document"] == 'Update_EE_Subscription(PUT)':
                        UDR.Subscription_Data.Event_Exposure_Subscription_Document.Update_EE_Subscription_Put()

                    elif answers["Event_Exposure_Subscription_Document"] == 'Remove_EE_Subscription':
                        UDR.Subscription_Data.Event_Exposure_Subscription_Document.Remove_EE_Subscription()

                    elif answers["Event_Exposure_Subscription_Document"] == 'Update_EE_Subscription(PATCH)':
                        UDR.Subscription_Data.Event_Exposure_Subscription_Document.Update_EE_Subscription_Patch()

                    elif answers["Event_Exposure_Subscription_Document"] == 'Update_EE_Group_Subscription(PUT)':
                        UDR.Subscription_Data.Event_Exposure_Subscription_Document.Update_EE_Group_Subscription_Put()

                    elif answers["Event_Exposure_Subscription_Document"] == 'Remove_EE_Group_Subscriptions':
                        UDR.Subscription_Data.Event_Exposure_Subscription_Document.Remove_EE_Group_Subscriptions()

                    elif answers["Event_Exposure_Subscription_Document"] == 'Update_EE_Group_Subscription(PATCH)':
                        UDR.Subscription_Data.Event_Exposure_Subscription_Document.Update_EE_Group_Subscription_Patch()

                def AMF_Subscription_Info_Document():
                    questions = [
                        inquirer.List('AMF_Subscription_Info_Document',
                                      message="Select the AMF_Subscription_Info_Document",
                                      choices=['Store_AMF_EE_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["AMF_Subscription_Info_Document"] == 'Store_AMF_EE_Subscription':
                        UDR.Subscription_Data.AMF_Subscription_Info_Document.Store_AMF_EE_Subscription()

                def Event_AMF_Subscription_Info_Document():
                    questions = [
                        inquirer.List('Event_AMF_Subscription_Info_Document',
                                      message="Select the Event_AMF_Subscription_Info_Document",
                                      choices=['Remove_AMF_EE_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Event_AMF_Subscription_Info_Document"] == 'Remove_AMF_EE_Subscription':
                        UDR.Subscription_Data.Event_AMF_Subscription_Info_Document.Remove_AMF_EE_Subscription()

                def AmfSubscriptionInfo_Document():
                    questions = [
                        inquirer.List('AmfSubscriptionInfo_Document',
                                      message="Select the AmfSubscriptionInfo_Document",
                                      choices=['Modify_AMF_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["AmfSubscriptionInfo_Document"] == 'Modify_AMF_Subscription':
                        UDR.Subscription_Data.AmfSubscriptionInfo_Document.Modify_AMF_Subscription()

                def Query_AMF_Subscription_Info_Document():
                    questions = [
                        inquirer.List('Query_AMF_Subscription_Info_Document',
                                      message="Select the Query_AMF_Subscription_Info_Document",
                                      choices=['Query_AMF_Subscription_Info'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Query_AMF_Subscription_Info_Document"] == 'Query_AMF_Subscription_Info':
                        UDR.Subscription_Data.Query_AMF_Subscription_Info_Document.Query_AMF_Subscription_Info()

                def Event_Exposure_Group_Subscriptions_Collection():
                    questions = [
                        inquirer.List('Event_Exposure_Group_Subscriptions_Collection',
                                      message="Select the Event_Exposure_Group_Subscriptions_Collection",
                                      choices=['Query_EE_Group_Subscriptions', 'Create_EE_Group_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Event_Exposure_Group_Subscriptions_Collection"] == 'Query_EE_Group_Subscriptions':
                        UDR.Subscription_Data.Event_Exposure_Group_Subscriptions_Collection.Query_EE_Group_Subscriptions()

                    elif answers["Event_Exposure_Group_Subscriptions_Collection"] == 'Create_EE_Group_Subscription':
                        UDR.Subscription_Data.Event_Exposure_Group_Subscriptions_Collection.Create_EE_Group_Subscription()

                def Event_Exposure_Data_Document():
                    questions = [
                        inquirer.List('Event_Exposure_Data_Document',
                                      message="Select the Event_Exposure_Data_Document",
                                      choices=['Query_EE_Profile'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Event_Exposure_Data_Document"] == 'Query_EE_Profile':
                        UDR.Subscription_Data.Event_Exposure_Data_Document.Query_EE_Profile()

                def SDM_Subscriptions_Collection():
                    questions = [
                        inquirer.List('SDM_Subscriptions_Collection',
                                      message="Select the SDM_Subscriptions_Collection",
                                      choices=['Query_SDM_Subscription', 'Create_SDM_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["SDM_Subscriptions_Collection"] == 'Query_SDM_Subscription':
                        UDR.Subscription_Data.SDM_Subscriptions_Collection.Query_SDM_Subscription()

                    elif answers["SDM_Subscriptions_Collection"] == 'Create_SDM_Subscription':
                        UDR.Subscription_Data.SDM_Subscriptions_Collection.Create_SDM_Subscription()

                def SDM_Subscription_Document():
                    questions = [
                        inquirer.List('SDM_Subscription_Document',
                                      message="Select the SDM_Subscription_Document",
                                      choices=['Update_SDM_Subscription', 'Remove_SDM_Subscription', 'Modify_SDM_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["SDM_Subscription_Document"] == 'Update_SDM_Subscription':
                        UDR.Subscription_Data.SDM_Subscription_Document.Update_SDM_Subscription()

                    elif answers["SDM_Subscription_Document"] == 'Remove_SDM_Subscription':
                        UDR.Subscription_Data.SDM_Subscription_Document.Remove_SDM_Subscription()

                    elif answers["SDM_Subscription_Document"] == 'Modify_SDM_Subscription':
                        UDR.Subscription_Data.SDM_Subscription_Document.Modify_SDM_Subscription()

                def Retrieval_of_shared_data():
                    questions = [
                        inquirer.List('Retrieval_of_shared_data',
                                      message="Select the Retrieval_of_shared_data",
                                      choices=['Query_Shared_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Retrieval_of_shared_data"] == 'Query_Shared_Data':
                        UDR.Subscription_Data.Retrieval_of_shared_data.Query_Shared_Data()

                def Subs_To_Nofify_Collection():
                    questions = [
                        inquirer.List('Subs_To_Nofify_Collection',
                                      message="Select the Subs_To_Nofify_Collection",
                                      choices=['Subscribe_for_Subscription_Data_Notifications', 'Query_Subscription_Data_Notification_Subscriptions'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Subs_To_Nofify_Collection"] == 'Subscribe_for_Subscription_Data_Notifications':
                        UDR.Subscription_Data.Subs_To_Nofify_Collection.Subscribe_for_Subscription_Data_Notifications()

                    elif answers["Subs_To_Nofify_Collection"] == 'Query_Subscription_Data_Notification_Subscriptions':
                        UDR.Subscription_Data.Subs_To_Nofify_Collection.Query_Subscription_Data_Notification_Subscriptions()

                def Subs_To_Notify_Collection():
                    questions = [
                        inquirer.List('Subs_To_Notify_Collection',
                                      message="Select the Subs_To_Notify_Collection",
                                      choices=['Delete_Subscription_Data_Notification_Subscriptions'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Subs_To_Notify_Collection"] == 'Delete_Subscription_Data_Notification_Subscriptions':
                        UDR.Subscription_Data.Subs_To_Notify_Collection.Delete_Subscription_Data_Notification_Subscriptions()

                def Subs_To_Notify_Document():
                    questions = [
                        inquirer.List('Subs_To_Notify_Document',
                                      message="Select the Subs_To_Notify_Document",
                                      choices=['Delete_a_Subscription_Data_Notification_Subscription', 'Modify_a_Subscription_Data_Notification_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Subs_To_Notify_Document"] == 'Delete_a_Subscription_Data_Notification_Subscription':
                        UDR.Subscription_Data.Subs_To_Notify_Document.Delete_a_Subscription_Data_Notification_Subscription()

                    elif answers["Subs_To_Notify_Document"] == 'Modify_a_Subscription_Data_Notification_Subscription':
                        UDR.Subscription_Data.Subs_To_Notify_Document.Modify_a_Subscription_Data_Notification_Subscription()

                def Trace_Data_Document():
                    questions = [
                        inquirer.List('Trace_Data_Document',
                                      message="Select the Trace_Data_Document",
                                      choices=['Query_Trace_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Trace_Data_Document"] == 'Query_Trace_Data':
                        UDR.Subscription_Data.Trace_Data_Document.Query_Trace_Data()

                def Query_Identity_Data_by_SUPI_or_GPSI_Document():
                    questions = [
                        inquirer.List('Query_Identity_Data_by_SUPI_or_GPSI_Document',
                                      message="Select the Query_Identity_Data_by_SUPI_or_GPSI_Document",
                                      choices=['Query_Identity_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Query_Identity_Data_by_SUPI_or_GPSI_Document"] == 'Query_Identity_Data':
                        UDR.Subscription_Data.Query_Identity_Data_by_SUPI_or_GPSI_Document.Query_Identity_Data()

                def Query_ODB_Data_by_SUPI_or_GPSI_Document():
                    questions = [
                        inquirer.List('Query_ODB_Data_by_SUPI_or_GPSI_Document',
                                      message="Select the Query_ODB_Data_by_SUPI_or_GPSI_Document",
                                      choices=['Query_ODB_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Query_ODB_Data_by_SUPI_or_GPSI_Document"] == 'Query_ODB_Data':
                        UDR.Subscription_Data.Query_ODB_Data_by_SUPI_or_GPSI_Document.Query_ODB_Data()

                def Context_Data_Document():
                    questions = [
                        inquirer.List('Context_Data_Document',
                                      message="Select the Context_Data_Document",
                                      choices=['Query_Context_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Context_Data_Document"] == 'Query_Context_Data':
                        UDR.Subscription_Data.Context_Data_Document.Query_Context_Data()

                def Group_Identifiers():
                    questions = [
                        inquirer.List('Group_Identifiers',
                                      message="Select the Group_Identifiers",
                                      choices=['Query_Group_Identifiers'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Subscription_Data()

                    elif answers["Group_Identifiers"] == 'Query_Group_Identifiers':
                        UDR.Subscription_Data.Group_Identifiers.Query_Group_Identifiers()

                def Policy_Data():
                    questions = [
                        inquirer.List('Policy_Data',
                                      message="Select the Policy_Data",
                                      choices=['Access_And_Mobility_Policy_Data_Document', 'UE_Policy_Set_Document', 'Session_Management_Policy_Data_Document', 'Usage_Monitoring_Information_Document', 'Sponsor_Connectivity_Data_Document', 'BDT_Data_Store', 'Policy_Data_Subscriptions_Collection', 'Individual_BDT_Data_Document', 'Individual_Policy_Data_Subscription_Document', 'Operator_Specific_Data_Document', 'PLMN_UE_Policy_Set_Document'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        udr()

                    elif answers["Policy_Data"] == 'Access_And_Mobility_Policy_Data_Document':
                        Access_And_Mobility_Policy_Data_Document()

                    elif answers["Policy_Data"] == 'UE_Policy_Set_Document':
                        UE_Policy_Set_Document()

                    elif answers["Policy_Data"] == 'Session_Management_Policy_Data_Document':
                        Session_Management_Policy_Data_Document()

                    elif answers["Policy_Data"] == 'Usage_Monitoring_Information_Document':
                        Usage_Monitoring_Information_Document()

                    elif answers["Policy_Data"] == 'Sponsor_Connectivity_Data_Document':
                        Sponsor_Connectivity_Data_Document()

                    elif answers["Policy_Data"] == 'BDT_Data_Store':
                        BDT_Data_Store()

                    elif answers["Policy_Data"] == 'Individual_BDT_Data_Document':
                        Individual_BDT_Data_Document()

                    elif answers["Policy_Data"] == 'Individual_Policy_Data_Subscription_Document':
                        Individual_Policy_Data_Subscription_Document()

                    elif answers["Policy_Data"] == 'Operator_Specific_Data_Document':
                        Operator_Specific_Data_Document()

                    elif answers["Policy_Data"] == 'PLMN_UE_Policy_Set_Document':
                        PLMN_UE_Policy_Set_Document()

                    elif answers["Policy_Data"] == 'Policy_Data_Subscriptions_Collection':
                        Policy_Data_Subscriptions_Collection()

                def Access_And_Mobility_Policy_Data_Document():
                    questions = [
                        inquirer.List('Access_And_Mobility_Policy_Data_Document',
                                      message="Select the Access_And_Mobility_Policy_Data_Document",
                                      choices=['Retrieve_Access_and_Mobility_Policy'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Policy_Data()

                    elif answers["Access_And_Mobility_Policy_Data_Document"] == 'Retrieve_Access_and_Mobility_Policy':
                        UDR.Policy_Data.Access_And_Mobility_Policy_Data_Document.Retrieve_Access_and_Mobility_Policy()

                def UE_Policy_Set_Document():
                    questions = [
                        inquirer.List('UE_Policy_Set_Document',
                                      message="Select the UE_Policy_Set_Document",
                                      choices=['Retrieve_UE_Policy_Set', 'Store_UE_Policy_Set_Data', 'Modify_UE_Policy_Set_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Policy_Data()

                    elif answers["UE_Policy_Set_Document"] == 'Retrieve_UE_Policy_Set':
                        UDR.Policy_Data.UE_Policy_Set_Document.Retrieve_UE_Policy_Set()

                    elif answers["UE_Policy_Set_Document"] == 'Store_UE_Policy_Set_Data':
                        UDR.Policy_Data.UE_Policy_Set_Document.Store_UE_Policy_Set_Data()

                    elif answers["UE_Policy_Set_Document"] == 'Modify_UE_Policy_Set_Data':
                        UDR.Policy_Data.UE_Policy_Set_Document.Modify_UE_Policy_Set_Data()

                def Session_Management_Policy_Data_Document():
                    questions = [
                        inquirer.List('Session_Management_Policy_Data_Document',
                                      message="Select the Session_Management_Policy_Data_Document",
                                      choices=['Retrieve_Session_Management_Policy_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Policy_Data()

                    elif answers["Session_Management_Policy_Data_Document"] == 'Retrieve_Session_Management_Policy_Data':
                        UDR.Policy_Data.Session_Management_Policy_Data_Document.Retrieve_Session_Management_Policy_Data()

                def Usage_Monitoring_Information_Document():
                    questions = [
                        inquirer.List('Usage_Monitoring_Information_Document',
                                      message="Select the Usage_Monitoring_Information_Document",
                                      choices=['Retrieve_Usage_Monitoring_Data', 'Store_Usage_Monitoring_Data', 'Delete_Usage_Monitoring_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Policy_Data()

                    elif answers["Usage_Monitoring_Information_Document"] == 'Retrieve_Usage_Monitoring_Data':
                        UDR.Policy_Data.Usage_Monitoring_Information_Document.Retrieve_Usage_Monitoring_Data()

                    elif answers["Usage_Monitoring_Information_Document"] == 'Store_Usage_Monitoring_Data':
                        UDR.Policy_Data.Usage_Monitoring_Information_Document.Store_Usage_Monitoring_Data()

                    elif answers["Usage_Monitoring_Information_Document"] == 'Delete_Usage_Monitoring_Data':
                        UDR.Policy_Data.Usage_Monitoring_Information_Document.Delete_Usage_Monitoring_Data()

                def Sponsor_Connectivity_Data_Document():
                    questions = [
                        inquirer.List('Sponsor_Connectivity_Data_Document',
                                      message="Select the Sponsor_Connectivity_Data_Document",
                                      choices=['Retrieve_Sponsored_Connectivity_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Policy_Data()

                    elif answers["Sponsor_Connectivity_Data_Document"] == 'Retrieve_Sponsored_Connectivity_Data':
                        UDR.Policy_Data.Sponsor_Connectivity_Data_Document.Retrieve_Sponsored_Connectivity_Data()

                def BDT_Data_Store():
                    questions = [
                        inquirer.List('BDT_Data_Store',
                                      message="Select the BDT_Data_Store",
                                      choices=['Retrieve_BDT_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Policy_Data()

                    elif answers["BDT_Data_Store"] == 'Retrieve_BDT_Data':
                        UDR.Policy_Data.BDT_Data_Store.Retrieve_BDT_Data()

                def Policy_Data_Subscriptions_Collection():
                    questions = [
                        inquirer.List('Policy_Data_Subscriptions_Collection',
                                      message="Select the Policy_Data_Subscriptions_Collection",
                                      choices=['Create_Policy_Data_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Policy_Data()

                    elif answers["Policy_Data_Subscriptions_Collection"] == 'Create_Policy_Data_Subscription':
                        UDR.Policy_Data.Policy_Data_Subscriptions_Collection.Create_Policy_Data_Subscription()

                def Individual_BDT_Data_Document():
                    questions = [
                        inquirer.List('Individual_BDT_Data_Document',
                                      message="Select the Individual_BDT_Data_Document",
                                      choices=['Retrieve_BDT_Policy', 'Create_BDT_Data_Resource', 'Delete_BDT_Data_Resource'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Policy_Data()

                    elif answers["Individual_BDT_Data_Document"] == 'Retrieve_BDT_Policy':
                        UDR.Policy_Data.Individual_BDT_Data_Document.Retrieve_BDT_Policy()

                    elif answers["Individual_BDT_Data_Document"] == 'Create_BDT_Data_Resource':
                        UDR.Policy_Data.Individual_BDT_Data_Document.Create_BDT_Data_Resource()

                    elif answers["Individual_BDT_Data_Document"] == 'Delete_BDT_Data_Resource':
                        UDR.Policy_Data.Individual_BDT_Data_Document.Delete_BDT_Data_Resource()

                def Individual_Policy_Data_Subscription_Document():
                    questions = [
                        inquirer.List('Individual_Policy_Data_Subscription_Document',
                                      message="Select the Individual_Policy_Data_Subscription_Document",
                                      choices=['Replace_Policy_Data_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Policy_Data()

                    elif answers["Individual_Policy_Data_Subscription_Document"] == 'Replace_Policy_Data_Subscription':
                        UDR.Policy_Data.Individual_Policy_Data_Subscription_Document.Replace_Policy_Data_Subscription()

                def Operator_Specific_Data_Document():
                    questions = [
                        inquirer.List('Operator_Specific_Data_Document',
                                      message="Select the Operator_Specific_Data_Document",
                                      choices=['Retrieve_Operator_Specific_Data', 'Modify_Operator_Specific_Policy_Data', 'Store_Operator_Specific_Policy_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Policy_Data()

                    elif answers["Operator_Specific_Data_Document"] == 'Retrieve_Operator_Specific_Data':
                        UDR.Policy_Data.Operator_Specific_Data_Document.Retrieve_Operator_Specific_Data()

                    elif answers["Operator_Specific_Data_Document"] == 'Modify_Operator_Specific_Policy_Data':
                        UDR.Policy_Data.Operator_Specific_Data_Document.Modify_Operator_Specific_Policy_Data()

                    elif answers["Operator_Specific_Data_Document"] == 'Store_Operator_Specific_Policy_Data':
                        UDR.Policy_Data.Operator_Specific_Data_Document.Store_Operator_Specific_Policy_Data()

                def PLMN_UE_Policy_Set_Document():
                    questions = [
                        inquirer.List('PLMN_UE_Policy_Set_Document',
                                      message="Select the PLMN_UE_Policy_Set_Document",
                                      choices=['Retrieve_UE_Policy_Set'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Policy_Data()

                    elif answers["PLMN_UE_Policy_Set_Document"] == 'Retrieve_UE_Policy_Set':
                        UDR.Policy_Data.PLMN_UE_Policy_Set_Document.Retrieve_UE_Policy_Set()

                def Exposure_Data():
                    questions = [
                        inquirer.List('Exposure_Data',
                                      message="Select the Exposure_Data",
                                      choices=['Access_And_Mobility_Data', 'PDU_Session_Management_Data', 'Exposure_Data_Subscriptions_Collection', 'Individual_Exposure_Data_Subscription_Document'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        udr()

                    elif answers["Exposure_Data"] == 'Access_And_Mobility_Data':
                        Access_And_Mobility_Data()

                    elif answers["Exposure_Data"] == 'PDU_Session_Management_Data':
                        PDU_Session_Management_Data()

                    elif answers["Exposure_Data"] == 'Exposure_Data_Subscriptions_Collection':
                        Exposure_Data_Subscriptions_Collection()

                    elif answers["Exposure_Data"] == 'Individual_Exposure_Data_Subscription_Document':
                        Individual_Exposure_Data_Subscription_Document()

                def Access_And_Mobility_Data():
                    questions = [
                        inquirer.List('Access_And_Mobility_Data',
                                      message="Select the Access_And_Mobility_Data",
                                      choices=['Store_Access_And_Mobility_Data', 'Retrieve_Access_And_Mobility_Data', 'Delete_Access_And_Mobility_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Exposure_Data()

                    elif answers["Access_And_Mobility_Data"] == 'Store_Access_And_Mobility_Data':
                        UDR.Exposure_Data.Access_And_Mobility_Data.Store_Access_And_Mobility_Data()

                    elif answers["Access_And_Mobility_Data"] == 'Retrieve_Access_And_Mobility_Data':
                        UDR.Exposure_Data.Access_And_Mobility_Data.Retrieve_Access_And_Mobility_Data()

                    elif answers["Access_And_Mobility_Data"] == 'Delete_Access_And_Mobility_Data':
                        UDR.Exposure_Data.Access_And_Mobility_Data.Delete_Access_And_Mobility_Data()

                def PDU_Session_Management_Data():
                    questions = [
                        inquirer.List('PDU_Session_Management_Data',
                                      message="Select the PDU_Session_Management_Data",
                                      choices=['Store_Session_Management_Data', 'Retrieve_Session_Management_Data', 'Delete_Session_Management_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Exposure_Data()

                    elif answers["PDU_Session_Management_Data"] == 'Store_Session_Management_Data':
                        UDR.Exposure_Data.PDU_Session_Management_Data.Store_Session_Management_Data()

                    elif answers["PDU_Session_Management_Data"] == 'Retrieve_Session_Management_Data':
                        UDR.Exposure_Data.PDU_Session_Management_Data.Retrieve_Session_Management_Data()

                    elif answers["PDU_Session_Management_Data"] == 'Delete_Session_Management_Data':
                        UDR.Exposure_Data.PDU_Session_Management_Data.Delete_Session_Management_Data()

                def Exposure_Data_Subscriptions_Collection():
                    questions = [
                        inquirer.List('Exposure_Data_Subscriptions_Collection',
                                      message="Select the Exposure_Data_Subscriptions_Collection",
                                      choices=['Create_Exposure_Data_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Exposure_Data()

                    elif answers["Exposure_Data_Subscriptions_Collection"] == 'Create_Exposure_Data_Subscription':
                        UDR.Exposure_Data.Exposure_Data_Subscriptions_Collection.Create_Exposure_Data_Subscription()

                def Individual_Exposure_Data_Subscription_Document():
                    questions = [
                        inquirer.List('Individual_Exposure_Data_Subscription_Document',
                                      message="Select the Individual_Exposure_Data_Subscription_Document",
                                      choices=['Modify_Exposure_Data_Subscription', 'Delete_Exposure_Data_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Exposure_Data()

                    elif answers["Individual_Exposure_Data_Subscription_Document"] == 'Modify_Exposure_Data_Subscription':
                        UDR.Exposure_Data.Individual_Exposure_Data_Subscription_Document.Modify_Exposure_Data_Subscription()

                    elif answers["Individual_Exposure_Data_Subscription_Document"] == 'Delete_Exposure_Data_Subscription':
                        UDR.Exposure_Data.Individual_Exposure_Data_Subscription_Document.Delete_Exposure_Data_Subscription()

                def Application_Data():
                    questions = [
                        inquirer.List('Application_Data',
                                      message="Select the Application_Data",
                                      choices=['PFD_Data_Store', 'Individual_PFD_Data_Document', 'Influence_Data_Store', 'Individual_Influence_Data_Document', 'Influence_Data_Subscriptions_Collection', 'Individual_Influence_Data_Subscription_Document'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        udr()

                    elif answers["Application_Data"] == 'PFD_Data_Store':
                        PFD_Data_Store()

                    elif answers["Application_Data"] == 'Individual_PFD_Data_Document':
                        Individual_PFD_Data_Document()

                    elif answers["Application_Data"] == 'Influence_Data_Store':
                        Influence_Data_Store()

                    elif answers["Application_Data"] == 'Individual_Influence_Data_Document':
                        Individual_Influence_Data_Document()

                    elif answers["Application_Data"] == 'Influence_Data_Subscriptions_Collection':
                        Influence_Data_Subscriptions_Collection()

                    elif answers["Application_Data"] == 'Individual_Influence_Data_Subscription_Document':
                        Individual_Influence_Data_Subscription_Document()

                def PFD_Data_Store():
                    questions = [
                        inquirer.List('PFD_Data_Store',
                                      message="Select the PFD_Data_Store",
                                      choices=['Retrieve_ALL_PFDs'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Application_Data()

                    elif answers["PFD_Data_Store"] == 'Retrieve_ALL_PFDs':
                        UDR.Application_Data.PFD_Data_Store.Retrieve_ALL_PFDs()

                def Individual_PFD_Data_Document():
                    questions = [
                        inquirer.List('Individual_PFD_Data_Document',
                                      message="Select the Individual_PFD_Data_Document",
                                      choices=['Retrieve_a_PFD', 'Delete_PFD_Data', 'Store_PFD_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Application_Data()

                    elif answers["Individual_PFD_Data_Document"] == 'Retrieve_a_PFD':
                        UDR.Application_Data.Individual_PFD_Data_Document.Retrieve_a_PFD()

                    elif answers["Individual_PFD_Data_Document"] == 'Delete_PFD_Data':
                        UDR.Application_Data.Individual_PFD_Data_Document.Delete_PFD_Data()

                    elif answers["Individual_PFD_Data_Document"] == 'Store_PFD_Data':
                        UDR.Application_Data.Individual_PFD_Data_Document.Store_PFD_Data()

                def Influence_Data_Store():
                    questions = [
                        inquirer.List('Influence_Data_Store',
                                      message="Select the Influence_Data_Store",
                                      choices=['Retreive_Influence_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Application_Data()

                    elif answers["Influence_Data_Store"] == 'Retreive_Influence_Data':
                        UDR.Application_Data.Influence_Data_Store.Retreive_Influence_Data()

                def Individual_Influence_Data_Document():
                    questions = [
                        inquirer.List('Individual_Influence_Data_Document',
                                      message="Select the Individual_Influence_Data_Document",
                                      choices=['Store_Influence_Data', 'Modify_Influence_Data', 'Delete_Influence_Data'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Application_Data()

                    elif answers["Individual_Influence_Data_Document"] == 'Store_Influence_Data':
                        UDR.Application_Data.Individual_Influence_Data_Document.Store_Influence_Data()

                    elif answers["Individual_Influence_Data_Document"] == 'Modify_Influence_Data':
                        UDR.Application_Data.Individual_Influence_Data_Document.Modify_Influence_Data()

                    elif answers["Individual_Influence_Data_Document"] == 'Delete_Influence_Data':
                        UDR.Application_Data.Individual_Influence_Data_Document.Delete_Influence_Data()

                def Influence_Data_Subscriptions_Collection():
                    questions = [
                        inquirer.List('Influence_Data_Subscriptions_Collection',
                                      message="Select the Influence_Data_Subscriptions_Collection",
                                      choices=['Create_Influence_Data_Subscription', 'Retrieve_Influence_Data_Subscriptions'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Application_Data()

                    elif answers["Influence_Data_Subscriptions_Collection"] == 'Create_Influence_Data_Subscription':
                        UDR.Application_Data.Influence_Data_Subscriptions_Collection.Create_Influence_Data_Subscription()

                    elif answers["Influence_Data_Subscriptions_Collection"] == 'Retrieve_Influence_Data_Subscriptions':
                        UDR.Application_Data.Influence_Data_Subscriptions_Collection.Retrieve_Influence_Data_Subscriptions()

                def Individual_Influence_Data_Subscription_Document():
                    questions = [
                        inquirer.List('Individual_Influence_Data_Subscription_Document',
                                      message="Select the Individual_Influence_Data_Subscription_Document",
                                      choices=['Retrieve_Influence_Data_Subscription', 'Modify_Influence_Data_Subscription', 'Delete_Influence_Data_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Application_Data()

                    elif answers["Individual_Influence_Data_Subscription_Document"] == 'Retrieve_Influence_Data_Subscription':
                        UDR.Application_Data.Individual_Influence_Data_Subscription_Document.Retrieve_Influence_Data_Subscription()

                    elif answers["Individual_Influence_Data_Subscription_Document"] == 'Modify_Influence_Data_Subscription':
                        UDR.Application_Data.Individual_Influence_Data_Subscription_Document.Modify_Influence_Data_Subscription()

                    elif answers["Individual_Influence_Data_Subscription_Document"] == 'Delete_Influence_Data_Subscription':
                        UDR.Application_Data.Individual_Influence_Data_Subscription_Document.Delete_Influence_Data_Subscription()

                if answers == None:
                    fun()

                elif answers["UDR"] == 'Subscription_Data':
                    Subscription_Data()

                elif answers["UDR"] == 'Policy_Data':
                    Policy_Data()

                elif answers["UDR"] == 'Exposure_Data':
                    Exposure_Data()

                elif answers["UDR"] == 'Application_Data':
                    Application_Data()

            udr()

################################################ PCF #########################################################################################

        elif answers["Function"] == 'PCF':

            def pcf():
                questions = [
                    inquirer.List('PCF',
                                  message="Select the PCF",
                                  choices=['Policy_Authorization', 'Access_and_Mobility_Policy_Control', 'Session_Management_Policy_Control', 'Background_Data_Transfer_Policy_Control', 'Policy_Control_Event_Exposure', 'UE_Policy_Control'],), ]
                answers = inquirer.prompt(questions)

                def Policy_Authorization():
                    questions = [
                        inquirer.List('Policy_Authorization',
                                      message="Select the Policy_Authorization",
                                      choices=['Application_Sessions_Collection', 'Individual_Application_Session_Context_Document', 'Events_Subscription_Document'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        pcf()

                    elif answers["Policy_Authorization"] == 'Application_Sessions_Collection':
                        Application_Sessions_Collection()

                    elif answers["Policy_Authorization"] == 'Individual_Application_Session_Context_Document':
                        Individual_Application_Session_Context_Document()

                    elif answers["Policy_Authorization"] == 'Events_Subscription_Document':
                        Events_Subscription_Document()

                def Application_Sessions_Collection():
                    questions = [
                        inquirer.List('Application_Sessions_Collection',
                                      message="Select the Application_Sessions_Collection",
                                      choices=['Create_Application_Session_Context'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Policy_Authorization()

                    elif answers["Application_Sessions_Collection"] == 'Create_Application_Session_Context':
                        PCF.Policy_Authorization.Application_Sessions_Collection.Create_Application_Session_Context()

                def Individual_Application_Session_Context_Document():
                    questions = [
                        inquirer.List('Individual_Application_Session_Context_Document',
                                      message="Select the Individual_Application_Session_Context_Document",
                                      choices=['Retrieve_Application_Session_Context', 'Update_Application_Session_Context', 'Delete_Application_Session_Context'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Policy_Authorization()

                    elif answers["Individual_Application_Session_Context_Document"] == 'Retrieve_Application_Session_Context':
                        PCF.Policy_Authorization.Individual_Application_Session_Context_Document.Retrieve_Application_Session_Context()
    
                    elif answers["Individual_Application_Session_Context_Document"] == 'Update_Application_Session_Context':
                        PCF.Policy_Authorization.Individual_Application_Session_Context_Document.Update_Application_Session_Context()

                    elif answers["Individual_Application_Session_Context_Document"] == 'Delete_Application_Session_Context':
                        PCF.Policy_Authorization.Individual_Application_Session_Context_Document.Delete_Application_Session_Context()

                def Events_Subscription_Document():
                    questions = [
                        inquirer.List('Events_Subscription_Document',
                                      message="Select the Events_Subscription_Document",
                                      choices=['Update_Event_Subscription', 'Delete_Event_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Policy_Authorization()

                    elif answers["Events_Subscription_Document"] == 'Update_Event_Subscription':
                        PCF.Policy_Authorization.Events_Subscription_Document.Update_Event_Subscription()

                    elif answers["Events_Subscription_Document"] == 'Delete_Event_Subscription':
                        PCF.Policy_Authorization.Events_Subscription_Document.Delete_Event_Subscription()

                def Access_and_Mobility_Policy_Control():
                    questions = [
                        inquirer.List('Access_and_Mobility_Policy_Control',
                                      message="Select the Access_and_Mobility_Policy_Control",
                                      choices=['Default'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        pcf()

                    elif answers["Access_and_Mobility_Policy_Control"] == 'Default':
                        Default()

                def Default():
                    questions = [
                        inquirer.List('Default',
                                      message="Select the Default",
                                      choices=['Create_Policy_Association', 'Retrieve_Policy_Association', 'Update_Policy_Association', 'Delete_Policy_Association'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Access_and_Mobility_Policy_Control()

                    elif answers["Default"] == 'Create_Policy_Association':
                        PCF.Access_and_Mobility_Policy_Control.Default.Create_Policy_Association()

                    elif answers["Default"] == 'Retrieve_Policy_Association':
                        PCF.Access_and_Mobility_Policy_Control.Default.Retrieve_Policy_Association()

                    elif answers["Default"] == 'Update_Policy_Association':
                        PCF.Access_and_Mobility_Policy_Control.Default.Update_Policy_Association()

                    elif answers["Default"] == 'Delete_Policy_Association':
                        PCF.Access_and_Mobility_Policy_Control.Default.Delete_Policy_Association()

                def Session_Management_Policy_Control():
                    questions = [
                        inquirer.List('Session_Management_Policy_Control',
                                      message="Select the Session_Management_Policy_Control",
                                      choices=['Default'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        pcf()

                    elif answers["Session_Management_Policy_Control"] == 'Default':
                        Default2()

                def Default2():
                    questions = [
                        inquirer.List('Default',
                                      message="Select the Default",
                                      choices=['Create_SM_Policy', 'Update_SM_Policy', 'Retrieve_SM_Policy', 'Delete_SM_Policy'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Access_and_Mobility_Policy_Control()

                    elif answers["Default"] == 'Create_SM_Policy':
                        PCF.Session_Management_Policy_Control.Default2.Create_SM_Policy()

                    elif answers["Default"] == 'Update_SM_Policy':
                        PCF.Session_Management_Policy_Control.Default2.Update_SM_Policy()

                    elif answers["Default"] == 'Retrieve_SM_Policy':
                        PCF.Session_Management_Policy_Control.Default2.Retrieve_SM_Policy()

                    elif answers["Default"] == 'Delete_SM_Policy':
                        PCF.Session_Management_Policy_Control.Default2.Delete_SM_Policy()

                def Background_Data_Transfer_Policy_Control():
                    questions = [
                        inquirer.List('Background_Data_Transfer_Policy_Control',
                                      message="Select the Background_Data_Transfer_Policy_Control",
                                      choices=['BDT_policies_Collection', 'Individual_BDT_policy_Document'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        pcf()

                    elif answers["Background_Data_Transfer_Policy_Control"] == 'BDT_policies_Collection':
                        BDT_policies_Collection()

                    elif answers["Background_Data_Transfer_Policy_Control"] == 'Individual_BDT_policy_Document':
                        Individual_BDT_policy_Document()

                def BDT_policies_Collection():
                    questions = [
                        inquirer.List('BDT_policies_Collection',
                                      message="Select the BDT_policies_Collection",
                                      choices=['Create_BDT_Policy'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Background_Data_Transfer_Policy_Control()

                    elif answers["BDT_policies_Collection"] == 'Create_BDT_Policy':
                        PCF.Background_Data_Transfer_Policy_Control.BDT_policies_Collection.Create_BDT_Policy()

                def Individual_BDT_policy_Document():
                    questions = [
                        inquirer.List('Individual_BDT_policy_Document',
                                      message="Select the Individual_BDT_policy_Document",
                                      choices=['Retrieve_BDT_Policy', 'Update_BDT_Policy'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Background_Data_Transfer_Policy_Control()

                    elif answers["Individual_BDT_policy_Document"] == 'Retrieve_BDT_Policy':
                        PCF.Background_Data_Transfer_Policy_Control.Individual_BDT_policy_Document.Retrieve_BDT_Policy()

                    elif answers["Individual_BDT_policy_Document"] == 'Update_BDT_Policy':
                        PCF.Background_Data_Transfer_Policy_Control.Individual_BDT_policy_Document.Update_BDT_Policy()

                def Policy_Control_Event_Exposure():
                    questions = [
                        inquirer.List('Policy_Control_Event_Exposure',
                                      message="Select the Policy_Control_Event_Exposure",
                                      choices=['Policy_Control_Events_Subscription_Collection', 'Individual_Policy_Control_Events_Subscription_Document'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        pcf()

                    elif answers["Policy_Control_Event_Exposure"] == 'Policy_Control_Events_Subscription_Collection':
                        Policy_Control_Events_Subscription_Collection()

                    elif answers["Policy_Control_Event_Exposure"] == 'Individual_Policy_Control_Events_Subscription_Document':
                        Individual_Policy_Control_Events_Subscription_Document()

                def Policy_Control_Events_Subscription_Collection():
                    questions = [
                        inquirer.List('Policy_Control_Events_Subscription_Collection',
                                      message="Select the Policy_Control_Events_Subscription_Collection",
                                      choices=['Create_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Policy_Control_Event_Exposure()

                    elif answers["Policy_Control_Events_Subscription_Collection"] == 'Create_Subscription':
                        PCF.Policy_Control_Event_Exposure.Policy_Control_Events_Subscription_Collection.Create_Subscription()

                def Individual_Policy_Control_Events_Subscription_Document():
                    questions = [
                        inquirer.List('Individual_Policy_Control_Events_Subscription_Document',
                                      message="Select the Individual_Policy_Control_Events_Subscription_Document",
                                      choices=['Retrieve_Subscription', 'Modify_Subscription', 'Delete_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Policy_Control_Event_Exposure()

                    elif answers["Individual_Policy_Control_Events_Subscription_Document"] == 'Retrieve_Subscription':
                        PCF.Policy_Control_Event_Exposure.Individual_Policy_Control_Events_Subscription_Document.Retrieve_Subscription()

                    elif answers["Individual_Policy_Control_Events_Subscription_Document"] == 'Modify_Subscription':
                        PCF.Policy_Control_Event_Exposure.Individual_Policy_Control_Events_Subscription_Document.Modify_Subscription()

                    elif answers["Individual_Policy_Control_Events_Subscription_Document"] == 'Delete_Subscription':
                        PCF.Policy_Control_Event_Exposure.Individual_Policy_Control_Events_Subscription_Document.Delete_Subscription()

                def UE_Policy_Control():
                    questions = [
                        inquirer.List('UE_Policy_Control',
                                      message="Select the UE_Policy_Control",
                                      choices=['UE_Policy_Associations_Collection','Individual_UE_Policy_Association_Document'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        pcf()

                    elif answers["UE_Policy_Control"] == 'UE_Policy_Associations_Collection':
                        UE_Policy_Associations_Collection()

                    elif answers["UE_Policy_Control"] == 'Individual_UE_Policy_Association_Document':
                        Individual_UE_Policy_Association_Document()

                def UE_Policy_Associations_Collection():
                    questions = [
                        inquirer.List('UE_Policy_Associations_Collection',
                                      message="Select the UE_Policy_Associations_Collection",
                                      choices=['Create_Subscription'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Policy_Control()

                    elif answers["UE_Policy_Associations_Collection"] == 'Create_Subscription':
                        PCF.UE_Policy_Control.UE_Policy_Associations_Collection.Create_Subscription()

                def Individual_UE_Policy_Association_Document():
                    questions = [
                        inquirer.List('Individual_UE_Policy_Association_Document',
                                      message="Select the Individual_UE_Policy_Association_Document",
                                      choices=['Read_Association','Delete_Association','Update_Association'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        UE_Policy_Control()

                    elif answers["Individual_UE_Policy_Association_Document"] == 'Read_Association':
                        PCF.UE_Policy_Control.Individual_UE_Policy_Association_Document.Read_Association()

                    elif answers["Individual_UE_Policy_Association_Document"] == 'Delete_Association':
                        PCF.UE_Policy_Control.Individual_UE_Policy_Association_Document.Delete_Association()

                    elif answers["Individual_UE_Policy_Association_Document"] == 'Update_Association':
                        PCF.UE_Policy_Control.Individual_UE_Policy_Association_Document.Update_Association()

                if answers == None:
                    fun()

                if answers["PCF"] == 'Policy_Authorization':
                    Policy_Authorization()

                if answers["PCF"] == 'Access_and_Mobility_Policy_Control':
                    Access_and_Mobility_Policy_Control()

                if answers["PCF"] == 'Session_Management_Policy_Control':
                    Session_Management_Policy_Control()

                if answers["PCF"] == 'Background_Data_Transfer_Policy_Control':
                    Background_Data_Transfer_Policy_Control()

                if answers["PCF"] == 'Policy_Control_Event_Exposure':
                    Policy_Control_Event_Exposure()

                if answers["PCF"] == 'UE_Policy_Control':
                    UE_Policy_Control()

            pcf()

################################################ BSF #########################################################################################

        elif answers["Function"] == 'BSF':

            def bsf():
                questions = [
                    inquirer.List('BSF',
                                  message="Select the BSF",
                                  choices=['Management'],), ]
                answers = inquirer.prompt(questions)

                def Management():
                    questions = [
                        inquirer.List('Management',
                                      message="Select the Management",
                                      choices=['Default'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        bsf()

                    elif answers["Management"] == 'Default':
                        Default()

                def Default():
                    questions = [
                        inquirer.List('Default',
                                      message="Select the Default",
                                      choices=['Register', 'Retrieve_Session_Binding', 'Deregister'],), ]
                    answers = inquirer.prompt(questions)

                    if answers == None:
                        Management()

                    elif answers["Default"] == 'Register':
                        BSF.Management.Default.Register()

                    elif answers["Default"] == 'Retrieve_Session_Binding':
                        BSF.Management.Default.Retrieve_Session_Binding()

                    elif answers["Default"] == 'Deregister':
                        BSF.Management.Default.Deregister()

                if answers == None:
                    fun()

                elif answers["BSF"] == 'Management':
                    Management()

            bsf()


while True:
    fun()

    if not cont():
        break
