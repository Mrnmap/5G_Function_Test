import pycurl
import json
from io import StringIO
from colorama import Fore
import ipaddress
import re


id_regex = re.compile(
    r'([A-Za-z0-9])+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+')
nf_regex = re. compile(r'[A-Za-z]+')
supiOrsuci_regex = re. compile(
    r'imsi-[0-9]{5,15}|nai-.+|gli-.+|gci-.+|suci-(0-[0-9]{3}-[0-9]{2,3}|[1-7]-.+)-[0-9]{1,4}-(0-0-.+|[a-fA-F1-9]-([1-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])-[a-fA-F0-9]+)|.+')
servingNetworkName_regex = re. compile(
    r'5G:mnc[0-9]{3}[.]mcc[0-9]{3}[.]3gppnetwork[.]org(:[A-F0-9]{11})?')
mcc_regex = re.compile(r'[0-9]{3}')
mnc_regex = re.compile(r'[0-9]{2,3}')
supi_regex = re.compile(r'[0-9]{15,16}')


class NF_Management():

    class NF_Instances_Store():

        def Retrive_NF_List():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.10)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(
                            input("Enter Port "+Fore.LIGHTBLACK_EX + "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nnrf-nfm/v1/nf-instances')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED+"\nRetrieves the NF Instances that are currently registered in the NRF andthat satisfy a number of filter criteria, such as those NF Instances offering a certain service name, or those NF Instances of a given NF type(e.g., AMF). This request may only be directed at an NRF in the same PLMN. Direction: NF Service Consumer -->  NRF")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

        def Query_Options():
            pass

    class NF_Instance_ID_Document():

        def Retrive_NF_Profile():
            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.10)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(
                            input("Enter Port "+Fore.LIGHTBLACK_EX + "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    nf_instance_id = input("Enter NF Instance Id "+Fore.LIGHTBLACK_EX +
                                           "(Ex -  0e02d826-db22-41ec-87dd-bf9efe567155)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, nf_instance_id):
                        break

                    else:
                        print("Enter a Valid ID")
                        print('')
                        continue

                curl.setopt(curl.URL, 'http://'+str(ip)+':'+str(port) +
                            '/nnrf-nfm/v1//nf-instances/'+str(nf_instance_id))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED+"\nRetrieves the NF Instances that are currently registered in the NRF andthat satisfy a number of filter criteria, such as those NF Instances offering a certain service name, or those NF Instances of a given NF type(e.g., AMF). This request may only be directed at an NRF in the same PLMN. Direction: NF Service Consumer -->  NRF")

                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

        def NF_Register():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.10)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(
                            input("Enter Port "+Fore.LIGHTBLACK_EX + "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    nf_instance_id = input("Enter NF Instance Id "+Fore.LIGHTBLACK_EX +
                                           "(Ex -  b9f2f940-c628-41ec-aa78-9163487d7302)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, nf_instance_id):
                        break

                    else:
                        print("Enter a Valid ID")
                        print('')
                        continue

                while True:
                    nfType = input(
                        "Enter NF Type "+Fore.LIGHTBLACK_EX + "(Ex -  AUSF)"+Fore.RESET+"- ")
                    if re.fullmatch(nf_regex, nfType):
                        break

                    else:
                        print("Enter a Valid NF Type")
                        print('')
                        continue

                while True:
                    allowedNfTypes = input(
                        "Enter Allowed NF Type "+Fore.LIGHTBLACK_EX + "(Ex -  AMF)"+Fore.RESET+"- ")
                    if re.fullmatch(nf_regex, allowedNfTypes):
                        break

                    else:
                        print("Enter a Valid NF Type")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':'+str(port) +
                            '/nnrf-nfm/v1/nf-instances/'+str(nf_instance_id))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {"nfInstanceId":    "ffd09784-b0d8-41ec-aa1c-2578b3121d9e",
                                "nfType":    nfType.upper(),
                                "nfStatus":    "REGISTERED",
                                "ipv4Addresses":    [str(ip)],
                                "allowedNfTypes":    [allowedNfTypes.upper()],
                                "priority":    0,
                                "capacity":    100,
                                "load":    0,
                                "nfServices":    [{
                                    "serviceInstanceId":    "ffd0a12a-b0d8-41ec-aa1c-2578b3121d9e",
                                    "serviceName":    "nausf-auth",
                                    "versions":    [{
                                        "apiVersionInUri":    "v1",
                                        "apiFullVersion":    "1.0.0"
                                    }],
                                    "scheme":    "http",
                                    "nfServiceStatus":    "REGISTERED",
                                    "ipEndPoints":    [{
                                        "ipv4Address":   str(ip),
                                        "port":    int(port)
                                    }],
                                    "allowedNfTypes":    [allowedNfTypes.upper()],
                                    "priority":    0,
                                    "capacity":    100,
                                    "load":    0
                                }],
                                "nfProfileChangesSupportInd": True
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThe NF Profile of a given NF instance, and must be directed at an NRF in the same PLMN. Direction: NF Service Consumer -->  NRF")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None

        def NF_Update():

            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.10)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(
                            input("Enter Port "+Fore.LIGHTBLACK_EX + "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    nf_instance_id = input("Enter NF Instance Id "+Fore.LIGHTBLACK_EX +
                                           "(Ex -  0e02d826-db22-41ec-87dd-bf9efe567155)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, nf_instance_id):
                        break

                    else:
                        print("Enter a Valid ID")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/nnrf-nfm/v1/nf-instances/'+str(nf_instance_id))
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(crl.CUSTOMREQUEST, 'PATCH')

                body_as_dict = [
                    {
                        "op": "add",
                        "path": "amf"
                    }
                ]
                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                crl.setopt(pycurl.READDATA, body_as_file_object)
                crl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nDeregisters a given NF Instance from the NRF. Direction: NF Service Consumer -->  NRF")
                crl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None

        def NF_Deregister():

            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.10)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(
                            input("Enter Port "+Fore.LIGHTBLACK_EX + "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    nf_instance_id = input("Enter NF Instance Id "+Fore.LIGHTBLACK_EX +
                                           "(Ex -  0e02d826-db22-41ec-87dd-bf9efe567155)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, nf_instance_id):
                        break

                    else:
                        print("Enter a Valid ID")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/nnrf-nfm/v1/nf-instances/'+str(nf_instance_id))
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(crl.CUSTOMREQUEST, "DELETE")
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nDeregisters a given NF Instance from the NRF. Direction: NF Service Consumer -->  NRF")
                crl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None

    class Subcriptions_Collection():

        def NF_Status_Subscribe():

            try:

                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.10)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(
                            input("Enter Port "+Fore.LIGHTBLACK_EX + "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    reqNfInstanceId = input("Enter Request NF Instance Id  "+Fore.LIGHTBLACK_EX +
                                            "(Ex -  b9a0d5f2-c628-41ec-905e-516c5b30fb11)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, reqNfInstanceId):
                        break

                    else:
                        print("Enter a Valid ID")
                        print('')
                        continue

                while True:
                    nfType = input(
                        "Enter NF Type "+Fore.LIGHTBLACK_EX + "(Ex -  AMF)"+Fore.RESET+"- ")
                    if re.fullmatch(nf_regex, nfType):
                        break

                    else:
                        print("Enter a Valid NF Type")
                        print('')
                        continue

                while True:
                    reqNfType = input(
                        "Enter Request NF Type "+Fore.LIGHTBLACK_EX + "(Ex -  SMF)"+Fore.RESET+"- ")
                    if re.fullmatch(nf_regex, reqNfType):
                        break

                    else:
                        print("Enter a Valid Request NF Type")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nnrf-nfm/v1/subscriptions')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {"nfStatusNotificationUri": "http://"+str(ip)+":"+str(port)+"/nnrf-nfm/v1/subscriptions",
                                "reqNfInstanceId": str(reqNfInstanceId),
                                "subscrCond": {
                    "nfType": nfType.upper()
                },
                    "reqNfType": reqNfType.upper()
                }
                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED+"\nRetrieves the NF Instances that are currently registered in the NRF andthat satisfy a number of filter criteria, such as those NF Instances offering a certain service name, or those NF Instances of a given NF type(e.g., AMF). This request may only be directed at an NRF in the same PLMN. Direction: NF Service Consumer -->  NRF")

                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None

    class Subcription_ID_Document():

        def Update_Subscription():

            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.10)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(
                            input("Enter Port "+Fore.LIGHTBLACK_EX + "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    subscriptionsID = input("Enter Subscriptions ID  "+Fore.LIGHTBLACK_EX +
                                            "(Ex -  16453ef0-daac-41ec-9bcb-a7bc9fb5c795)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, subscriptionsID):
                        break

                    else:
                        print("Enter a Valid ID")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/nnrf-nfm/v1/subscriptions/'+str(subscriptionsID))
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(crl.CUSTOMREQUEST, 'PATCH')
                body_as_dict = [
                    {
                        "op": "add",
                        "path": "amf"
                    }
                ]
                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                crl.setopt(pycurl.READDATA, body_as_file_object)
                crl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED+"\nRetrieves the NF Instances that are currently registered in the NRF andthat satisfy a number of filter criteria, such as those NF Instances offering a certain service name, or those NF Instances of a given NF type(e.g., AMF). This request may only be directed at an NRF in the same PLMN. Direction: NF Service Consumer -->  NRF")
                crl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None

        def NF_Status_Unsubscribe():

            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.10)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(
                            input("Enter Port "+Fore.LIGHTBLACK_EX + "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    subscriptionsID = input("Enter Subscriptions ID  "+Fore.LIGHTBLACK_EX +
                                            "(Ex -  0c35a388-db28-41ec-b8eb-69105407e89b)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, subscriptionsID):
                        break

                    else:
                        print("Enter a Valid ID")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/nnrf-nfm/v1/subscriptions/'+subscriptionsID)
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(crl.CUSTOMREQUEST, "DELETE")
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThe NF Profile of a given NF instance, and must be directed at an NRF in the same PLMN. Direction: NF Service Consumer -->  NRF")
                crl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None


class NF_Discovery():

    class NF_Instances_Store():

        def NF_Descover():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.10)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(
                            input("Enter Port "+Fore.LIGHTBLACK_EX + "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nnrf-nfm/v1/nf-instances')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED+"\nRetrieves the NF Instances that are currently registered in the NRF andthat satisfy a number of filter criteria, such as those NF Instances offering a certain service name, or those NF Instances of a given NF type(e.g., AMF). This request may only be directed at an NRF in the same PLMN. Direction: NF Service Consumer -->  NRF")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None


class Access_Token_OAuth2():

    def Access_Token_Request():
        pass
