from pickle import GET
import pycurl
import json
from io import StringIO
from colorama import Fore
import ipaddress
import re

id_regex = re.compile(r'([A-Za-z0-9])+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+')
nf_regex = re. compile(r'[A-Za-z]+')
supiOrsuci_regex = re. compile(r'imsi-[0-9]{5,15}|nai-.+|gli-.+|gci-.+|suci-(0-[0-9]{3}-[0-9]{2,3}|[1-7]-.+)-[0-9]{1,4}-(0-0-.+|[a-fA-F1-9]-([1-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])-[a-fA-F0-9]+)|.+')
servingNetworkName_regex = re. compile(r'5G:mnc[0-9]{3}[.]mcc[0-9]{3}[.]3gppnetwork[.]org(:[A-F0-9]{11})?')
mcc_regex = re.compile(r'[0-9]{3}')
mnc_regex = re.compile(r'[0-9]{2,3}')
supi_regex = re.compile(r'[0-9]{15,16}')

class UE_Authentication():

    class Default():

        def Authenticate_UE():
                       
                        try:
                            curl = pycurl.Curl()
                            while True:
                                try:
                                    ip = ipaddress.ip_address(input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.11)"+Fore.RESET+"- "))
                                    break

                                except ValueError:
                                    print("This is NOT a VALID IP Address.")
                                    print('')
                                    continue

                            while True:
                                try:
                                    port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +"(Ex - 7777)"+Fore.RESET+"- "))
                                    break

                                except ValueError:
                                    print("This is NOT a VALID port Number.")
                                    print('')
                                    continue

                            while True:
                                supiOrSuci = input("Enter SUPI or a SUCI. "+Fore.LIGHTBLACK_EX +"(Ex -  suci-0-000-00-0000-0-0-0000000001)"+Fore.RESET+"- ")
                                if re.fullmatch(supiOrsuci_regex, supiOrSuci):
                                    break
                                
                                else:
                                    print("Enter SUPI or a SUCI.")
                                    print('')
                                    continue

                            curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +str(port)+'/nausf-auth/v1/ue-authentications')
                            curl.setopt(pycurl.HTTP_VERSION, pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                            curl.setopt(pycurl.HTTPHEADER, ['Accept: application/3gppHal+json',
                                                            'Content-Type: application/json'])
                            curl.setopt(pycurl.POST, 1)
                            curl.setopt(pycurl.TIMEOUT_MS, 3000)

                            body_as_dict = {"supiOrSuci": str(supiOrSuci),
                        "servingNetworkName": "5G:mnc001.mcc001.3gppnetwork.org"
                            }
                            body_as_json_string = json.dumps(body_as_dict) # dict to json
                            body_as_file_object = StringIO(body_as_json_string)
                            curl.setopt(pycurl.READDATA, body_as_file_object) 
                            curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                            curl.perform()
                            status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                            if status_code != 200:
                                print ("Server returned HTTP status code {}".format(status_code))
                        
                            if status_code == 200:
                                print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                                print("\nVulnerability Description :"+Fore.RED+"\n Initiates the authentication process by providing inputs related to the UE: UE ID and serving network name. Direction: AMF --> AUSF ")

                            curl.close()

                        except KeyboardInterrupt:
                            print('') # Go to the next line so printing looks better.
                            print('') 
                            return None

        def AKA_Confirmation():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.11)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    authCtxId = input("Enter authCtxId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, authCtxId):
                        break

                    else:
                        print("Enter a Valid authCtxId")
                        print('')
                        continue


                curl.setopt(pycurl.URL, 'http://'+str(ip)+':'+str(port)+'/nausf-auth/v1/ue-authentications/'+str(authCtxId)+'/5g-aka-confirmation')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {"resStar": "0b51ae7cd3c4f90940d20a16869d6345"
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                        "\nThe RES* generated by the UE to the AUSF to confirm a successful authentications in the UE and the AMF. The AMF shall set the RES* to null if the UE could not be reached or if authentication failed in either the UE or the AMF. Direction: AMF --> AUSF ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


        def EAP_Session_Information():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.11)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    authCtxId = input("Enter authCtxId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  ismi-123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, authCtxId):
                        break

                    else:
                        print("Enter a Valid authCtxId")
                        print('')
                        continue


                curl.setopt(pycurl.URL, 'http://'+str(ip)+':'+str(port)+'/nausf-auth/v1/ue-authentications/'+str(authCtxId)+'/eap-session')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {
                                }

                body_as_json_string = json.dumps(body_as_dict)  
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                        "\nThe EAP packet response received from the UE. Direction: AMF --> AUSF ")
                curl.close()

            except KeyboardInterrupt:
                print('')  
                print('')
                return None
            

class SOR_Protection():

    class Default():

        def Generate_SOR_Data():
            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.11)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    mcc = input("Enter MCC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("This is NOT a VALID MCC ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter MNC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("This is NOT a VALID MNC")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':'+str(port)+'/nausf-sorprotection/v1/'+str(supi)+'/ue-sor')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {"steeringContainer": [
                                {
                                "plmnId": {
                                    "mcc": mcc,
                                    "mnc": mnc
                                }
                                }
                            ],
                            "ackInd": True
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                        "\nThe AUSF calculates the SoR-MAC-IAUSF and the CounterSoR to protect the Steering Information List provided. It may also calculate the SoR-XMAC-IUE to verify that the UE received the Steering Information List if the indication that an acknowledgement is requested from the UE is present. Direction: UDM --> AUSF ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None
            


class UPU_Protection():

    class Default():

        def Protect():
            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.11)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    try:
                        sst = int(input("Enter SST "+Fore.LIGHTBLACK_EX +
                                "(Ex - 1)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID SST ")
                        print('')
                        continue

                while True:
                    try:
                        sd = int(input("Enter SD "+Fore.LIGHTBLACK_EX +
                                "(Ex - 1)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID SD")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':'+str(port)+'/nausf-upuprotection/v1/'+str(supi)+'/ue-upu')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {  "upuDataList": [
                    {
                    "defaultConfNssai": [
                        {
                        "sst": sst,
                        "sd": sd
                        }
                    ]
                    }
                ],
                "upuAckInd": True
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                        "\nThe AUSF to compute the UPU-MAC-IAUSF and CounterUPU by providing the UE Parameters Update Data (UPU Data). The NF Service Consumer may also request the AUSF to compute the UPU-XMAC-IUE by providing the indication that an acknowledgement is requested from the UE. Direction: UDM --> AUSF ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

