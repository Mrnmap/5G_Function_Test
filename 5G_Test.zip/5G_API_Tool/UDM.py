import pycurl
import json
from io import StringIO
from colorama import Fore
import ipaddress
import re
import datetime

id_regex = re.compile(
    r'([A-Za-z0-9])+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+')
nf_regex = re. compile(r'[A-Za-z]+')
supiOrsuci_regex = re. compile(
    r'imsi-[0-9]{5,15}|nai-.+|gli-.+|gci-.+|suci-(0-[0-9]{3}-[0-9]{2,3}|[1-7]-.+)-[0-9]{1,4}-(0-0-.+|[a-fA-F1-9]-([1-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])-[a-fA-F0-9]+)|.+')
servingNetworkName_regex = re. compile(
    r'5G:mnc[0-9]{3}[.]mcc[0-9]{3}[.]3gppnetwork[.]org(:[A-F0-9]{11})?')
mcc_regex = re.compile(r'[0-9]{3}')
mnc_regex = re.compile(r'[0-9]{2,3}')
supi_regex = re.compile(r'[0-9]{15,16}')
amfId_regex = re.compile(r'[A-Fa-f0-9]{6}')
smsfDiameterAddress_regex = re.compile(
    r'([A-Za-z0-9]+([-A-Za-z0-9]+)\.)+[a-z]{2,}')
servingNetworkName_regex = re.compile(
    r'5G:mnc[0-9]{3}[.]mcc[0-9]{3}[.]3gppnetwork[.]org(:[A-F0-9]{11})')
rand_regex = re.compile(r'[A-Fa-f0-9]{32}')
auts_regex = re.compile(r'[A-Fa-f0-9]{28}')


class Subscriber_Data_Management():

    class Retrieval_of_multiple_data_sets():

        def Retrieve_Subscription_Data():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-sdm/v2/'+str(supi))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's subscribed Access and Mobility Subscription Data. It is queried by the AMF after registration. Direction: AMF --> UDM ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class Slice_Selection_Subscription_Data_Retrieval():

        def Retrieve_NSSAI():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-sdm/v2/'+str(supi)+'/nssai')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's subscribed Access and Mobility Subscription Data. It is queried by the AMF after registration. Direction: AMF --> UDM ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class Access_and_Mobility_Subscription_Data_Retrieval():

        def Retrieve_AM_Data():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-sdm/v2/'+str(supi)+'/am-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's subscribed Access and Mobility Subscription Data. It is queried by the AMF after registration. Direction: AMF --> UDM ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class SMF_Selection_Subscription_Data_Retrieval():

        def Retrieve_SMF_Selection_Data():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-sdm/v2/'+str(supi)+'/smf-select-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's subscribed Access and Mobility Subscription Data. It is queried by the AMF after registration. Direction: AMF --> UDM ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class UE_Context_In_SMF_Data_Retrieval():

        def Retrieve_UE_Context_in_SMF_Data():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-sdm/v2/'+str(supi)+'/ue-context-in-smf-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's subscribed Access and Mobility Subscription Data. It is queried by the AMF after registration. Direction: AMF --> UDM ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class UE_Context_In_SMSF_Data_Retrieval():

        def Retrieve_UE_Context_in_SMSF_Data():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-sdm/v2/'+str(supi)+'/ue-context-in-smsf-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's subscribed Access and Mobility Subscription Data. It is queried by the AMF after registration. Direction: AMF --> UDM ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class Trace_Configuration_Data_Retrieval():

        def Retrieve_Trace_Configuration_Data():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-sdm/v2/'+str(supi)+'/trace-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's subscribed Access and Mobility Subscription Data. It is queried by the AMF after registration. Direction: AMF --> UDM ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class Session_Management_Subscription_Data_Retrieval():

        def Retrieve_Session_Management_Subscription_Data():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-sdm/v2/'+str(supi)+'/sm-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's subscribed Access and Mobility Subscription Data. It is queried by the AMF after registration. Direction: AMF --> UDM ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class SMS_Subscription_Data_Retrieval():

        def Retrieve_SMS_Subscription_Data():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-sdm/v2/'+str(supi)+'/sms-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's subscribed Access and Mobility Subscription Data. It is queried by the AMF after registration. Direction: AMF --> UDM ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class SMS_Management_Subscription_Data_Retrieval():

        def Retrieve_SMS_Management_Subscription_Data():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-sdm/v2/'+str(supi)+'/sms-mng-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's subscribed Access and Mobility Subscription Data. It is queried by the AMF after registration. Direction: AMF --> UDM ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class Subscription_Creation():

        def Subscribe_to_Notifications():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter IMSI"+Fore.LIGHTBLACK_EX +
                                 "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid IMSI")
                        print('')
                        continue

                while True:
                    try:
                        sst = int(
                            input("Enter sst "+Fore.LIGHTBLACK_EX + "(Ex - 1)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID sst.")
                        print('')
                        continue

                while True:
                    try:
                        sd = int(input("Enter SD "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 000001)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID SD.")
                        print('')
                        continue

                while True:
                    mcc = input("Enter MCC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("This is NOT a VALID MCC ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter MNC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("This is NOT a VALID MNC")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-sdm/v2/'+str(supi)+'/sdm-subscriptions')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {"nfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                "callbackReference": "string",
                                "monitoredResourceUris": [
                                    "string"
                                ],
                                "singleNssai": {
                                    "sst": sst,
                                    "sd": str(sd)
                                },
                                "plmnId": {
                                    "mcc": str(mcc),
                                    "mnc": str(mnc)
                                }
                                }
                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis POST request is used to subscribe to notifications of changes in individual UE subscription data. Direction: NF Service Consumer --> UDM")

                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class Subscription_Deletion():

        def Unsubscribe():
            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter SUPI "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a SUPI")
                        print('')
                        continue

                while True:
                    subscription_id = input("Enter subscription Id "+Fore.LIGHTBLACK_EX +
                                            "(Ex -  0e02d826-db22-41ec-87dd-bf9efe567155)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, subscription_id):
                        break

                    else:
                        print("Enter a Valid ID")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/nudm-sdm/v2/'+str(supi)+'/sdm-subscriptions/'+str(subscription_id))
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(crl.CUSTOMREQUEST, "DELETE")
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nDeregisters a given NF Instance from the NRF. Direction: NF Service Consumer -->  NRF")
                crl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class Subscription_Modification():

        def Modify_Subscription():

            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter IMSI"+Fore.LIGHTBLACK_EX +
                                 "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid IMSI")
                        print('')
                        continue

                while True:
                    nf_instance_id = input("Enter subscriptionId "+Fore.LIGHTBLACK_EX +
                                           "(Ex -  0e02d826-db22-41ec-87dd-bf9efe567155)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, nf_instance_id):
                        break

                    else:
                        print("Enter a Valid ID")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/nudm-sdm/v2/'+str(supi)+'/sdm-subscriptions/'+str(nf_instance_id))

                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                               'Content-Type: application/json'])
                crl.setopt(crl.CUSTOMREQUEST, 'PATCH')

                body_as_dict = {
                    "monitoredResourceUris": [
                        "string"
                    ]
                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                crl.setopt(pycurl.READDATA, body_as_file_object)
                crl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PATCH reqeust is used to modify the subscription. Direction: NF Service Consumer --> UDM")
                crl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

        def Modify_Shared_Subscription_Data_Notification_Subscription():

            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    nf_instance_id = input("Enter subscriptionId "+Fore.LIGHTBLACK_EX +
                                           "(Ex -  0e02d826-db22-41ec-87dd-bf9efe567155)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, nf_instance_id):
                        break

                    else:
                        print("Enter a Valid ID")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/nudm-sdm/v2/shared-data-subscriptions/'+str(nf_instance_id))
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                               'Content-Type: application/json'])
                crl.setopt(crl.CUSTOMREQUEST, 'PATCH')

                body_as_dict = {
                    "monitoredResourceUris": [
                        "string"
                    ]
                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                crl.setopt(pycurl.READDATA, body_as_file_object)
                crl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PATCH reqeust is used to modify the subscription. Direction: NF Service Consumer --> UDM")
                crl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class GPSI_to_SUPI_Translation():

        def Retieve_SUPI():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-sdm/v2/'+str(supi)+'/id-translation-result')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print(
                        "\nRetrieve the SUPI associated with a GPSI or the GPSI associated with a SUPI. Direction: NEF --> UDM")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class Providing_acknowledgement_of_Steering_of_Roaming():

        def Provide_SoR_Ack():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-sdm/v2/'+str(supi)+'/am-data/sor-ack')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {"sorMacIue": "string",
                                "upuMacIue": "string",
                                "securedPacket": "string",
                                "provisioningTime": "2022-08-23T07:12:37.105Z"
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PUT request is used by the AMF to provide acknowledgement from the UE of Steering of Roaming delivery. Direction: AMF --> UDM ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class Providing_acknowledgement_of_UE_Parameters_Update():

        def UE_Parameter_Update_Ack():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-sdm/v2/'+str(supi)+'/am-data/upu-ack')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {"sorMacIue": "string",
                                "upuMacIue": "string",
                                "securedPacket": "string",
                                "provisioningTime": "2022-08-23T07:12:37.105Z"
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PUT request is used by the AMF to provide acknowledgement from the UE of Steering of Roaming delivery. Direction: AMF --> UDM ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class Providing_acknowledgement_of_S_NSSAIs_Update():

        def Network_Slicing_Subscription_Change_Ack():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-sdm/v2/'+str(supi)+'/am-data/subscribed-snssais-ack')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {"sorMacIue": "string",
                                "upuMacIue": "string",
                                "securedPacket": "string",
                                "provisioningTime": "2022-08-23T07:12:37.105Z"
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PUT request is used by the AMF to provide acknowledgement from the UE of Steering of Roaming delivery. Direction: AMF --> UDM ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class Retrieval_of_shared_data():

        def Retrieve_Shared_Subscription_Data():
            pass

    class Subscription_Creation_for_shared_data():

        def Subscribe_to_Shared_Subscription_Notifications():

            try:

                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    try:
                        sst = int(
                            input("Enter sst "+Fore.LIGHTBLACK_EX + "(Ex - 1)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID sst.")
                        print('')
                        continue

                while True:
                    mcc = input("Enter mcc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("Enter a Valid mcc ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter mnc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("Enter a Valid mnc ")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-sdm/v2/shared-data-subscriptions')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {"nfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                "callbackReference": "string",
                                "amfServiceName": "nnrf-nfm",
                                "monitoredResourceUris": [
                                    "string"
                                ],
                                "singleNssai": {
                                    "sst": sst
                                },
                                "plmnId": {
                                    "mcc": str(mcc),
                                    "mnc": str(mnc)
                                }
                                }
                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis POST request is used to subscribe to data change notifications for shared subscription data. Direction: NF Service Consumer --> UDM")

                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class Subscription_Deletion_for_shared_data():

        def Unsubscribe_from_Shared_Subscription_Data_Notifications():
            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    subscription_id = input("Enter subscription Id "+Fore.LIGHTBLACK_EX +
                                            "(Ex -  0e02d826-db22-41ec-87dd-bf9efe567155)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, subscription_id):
                        break

                    else:
                        print("Enter a Valid ID")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/nudm-sdm/v2/shared-data-subscriptions/'+str(subscription_id))
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(crl.CUSTOMREQUEST, "DELETE")
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\n unsubscribe from notifications for shared data. Direction: NF Service Consumer --> UDM ")
                crl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class Group_Identifiers():

        def Retrieve_Group_Identifier():
            pass


#####################################################

class UE_Context_Management():

    class AMF_registration_for_3GPP_access():

        def Register_AMF_for_3GPP_Access():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                while True:
                    mcc = input("Enter mcc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("Enter a Valid mcc ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter mnc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("Enter a Valid mnc ")
                        print('')
                        continue

                while True:
                    amfId = input("Enter amfId "+Fore.LIGHTBLACK_EX +
                                  "(Ex - 123456)"+Fore.RESET+"- ")
                    if re.fullmatch(amfId_regex, amfId):
                        break

                    else:
                        print("This is NOT a VALID amfId")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-uecm/v1/'+str(supi)+'/registrations/amf-3gpp-access')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {"amfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                "deregCallbackUri": "string",
                                "guami": {
                                    "plmnId": {
                                        "mcc": str(mcc),
                                        "mnc": str(mnc)
                                    },
                                    "amfId": str(amfId)
                                },
                                "backupAmfInfo": [
                                    {
                                        "backupAmf": "string",
                                        "guamiList": [
                                            {
                                                "plmnId": {
                                                    "mcc": str(mcc),
                                                    "mnc": str(mnc)
                                                },
                                                "amfId": str(amfId)
                                            }
                                        ]
                                    }
                                ],
                                "drFlag": True,
                                "ratType": "NR",
                                "urrpIndicator": True,
                                "amfEeSubscriptionId": "string",
                                "epsInterworkingInfo": {
                                    "epsIwkPgws": {
                                        "additionalProp1": {
                                            "pgwFqdn": "string",
                                            "smfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6"
                                        },
                                        "additionalProp2": {
                                            "pgwFqdn": "string",
                                            "smfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6"
                                        },
                                        "additionalProp3": {
                                            "pgwFqdn": "string",
                                            "smfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6"
                                        }
                                    }
                                }
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PUT request is used to register the AMF in a UE's 3GPP access registration context. Direction: AMF --> UDM")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None

    class Parameter_update_in_the_AMF_registration_for_3GPP_access():

        def Update_UE_Parameter_3GPP_Access():

            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                while True:
                    mcc = input("Enter mcc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("Enter a Valid mcc ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter mnc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("Enter a Valid mnc ")
                        print('')
                        continue

                while True:
                    amfId = input("Enter amfId "+Fore.LIGHTBLACK_EX +
                                  "(Ex - 123456)"+Fore.RESET+"- ")
                    if re.fullmatch(amfId_regex, amfId):
                        break

                    else:
                        print("This is NOT a VALID amfId")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/nudm-uecm/v1/'+str(supi)+'/registrations/amf-3gpp-access')
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                               'Content-Type: application/json'])
                crl.setopt(crl.CUSTOMREQUEST, 'PATCH')

                body_as_dict = {
                    "guami": {
                        "plmnId": {
                            "mcc": str(mcc),
                            "mnc": str(mnc)
                        },
                        "amfId": str(amfId)
                    },
                    "backupAmfInfo": [
                        {
                            "backupAmf": "string",
                            "guamiList": [
                                {
                                    "plmnId": {
                                        "mcc": str(mcc),
                                        "mnc": str(mnc)
                                    },
                                    "amfId": str(amfId)
                                }
                            ]
                        }
                    ]
                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                crl.setopt(pycurl.READDATA, body_as_file_object)
                crl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PATCH request is used to update a parameter in a UE's 3GPP access registration context. Direction: AMF --> UDM")
                crl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class AMF_3Gpp_access_Registration_Info_Retrieval():

        def Retrieve_UE_Context_3GPP_Access():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-uecm/v1/'+str(supi)+'/registrations/amf-3gpp-access')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print(
                        "\nRetrieve a UE's 3GPP access registration context. Direction: NEF --> UDM ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class AMF_registration_for_non_3GPP_access():

        def Register_AMF_for_Non_3GPP_Access():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                while True:
                    mcc = input("Enter mcc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("Enter a Valid mcc ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter mnc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("Enter a Valid mnc ")
                        print('')
                        continue

                while True:
                    amfId = input("Enter amfId "+Fore.LIGHTBLACK_EX +
                                  "(Ex - 123456)"+Fore.RESET+"- ")
                    if re.fullmatch(amfId_regex, amfId):
                        break

                    else:
                        print("This is NOT a VALID amfId")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-uecm/v1/'+str(supi)+'/registrations/amf-non-3gpp-access ')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {"amfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                "supportedFeatures": "string",
                                "purgeFlag": True,
                                "pei": "string",
                                "imsVoPs": "HOMOGENEOUS_SUPPORT",
                                "deregCallbackUri": "string",
                                "amfServiceNameDereg": "nnrf-nfm",
                                "pcscfRestorationCallbackUri": "string",
                                "amfServiceNamePcscfRest": "nnrf-nfm",
                                "guami": {
                                    "plmnId": {
                                        "mcc": str(mcc),
                                        "mnc": str(mnc)
                                    },
                                    "amfId": str(amfId)
                                },
                                "backupAmfInfo": [
                                    {
                                        "backupAmf": "string",
                                        "guamiList": [
                                            {
                                                "plmnId": {
                                                    "mcc": str(mcc),
                                                    "mnc": str(mnc)
                                                },
                                                "amfId": str(amfId)
                                            }
                                        ]
                                    }
                                ],
                                "ratType": "NR",
                                "urrpIndicator": True,
                                "amfEeSubscriptionId": "string"
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PUT request is used to register the AMF in a UE's non-3GPP access registration context. Direction: AMF --> UDM")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None

    class Parameter_update_in_the_AMF_registration_for_non_3GPP_access():

        def Update_Registration_Non_3GPP_Access():

            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                while True:
                    mcc = input("Enter mcc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("Enter a Valid mcc ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter mnc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("Enter a Valid mnc ")
                        print('')
                        continue

                while True:
                    amfId = input("Enter amfId "+Fore.LIGHTBLACK_EX +
                                  "(Ex - 123456)"+Fore.RESET+"- ")
                    if re.fullmatch(amfId_regex, amfId):
                        break

                    else:
                        print("This is NOT a VALID amfId")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/nudm-uecm/v1/'+str(supi)+'/registrations/amf-non-3gpp-access')
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                               'Content-Type: application/json'])
                crl.setopt(crl.CUSTOMREQUEST, 'PATCH')

                body_as_dict = {
                    "guami": {
                        "plmnId": {
                            "mcc": str(mcc),
                            "mnc": str(mnc)
                        },
                        "amfId": str(amfId)
                    },
                    "backupAmfInfo": [
                        {
                            "backupAmf": "string",
                            "guamiList": [
                                {
                                    "plmnId": {
                                        "mcc": str(mcc),
                                        "mnc": str(mnc)
                                    },
                                    "amfId": str(amfId)
                                }
                            ]
                        }
                    ]
                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                crl.setopt(pycurl.READDATA, body_as_file_object)
                crl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PATCH request is used to update a parameter in a UE's non-3GPP access registration context. Direction: AMF --> UDM")
                crl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class AMF_non_3GPP_access_Registration_Info_Retrieval():

        def Retrieve_UE_Context_Non_3GPP_Access():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-uecm/v1/'+str(supi)+'/registrations/amf-non-3gpp-access')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print(
                        "\nRetrieve a UE's 3GPP access registration context. Direction: NEF --> UDM ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class SMF_Registration():

        def Register_SMF():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                while True:
                    try:
                        pduSessionId = int(input("Enter pduSessionId "+Fore.LIGHTBLACK_EX +
                                                 "(Ex - 255)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID pduSessionId.")
                        print('')
                        continue

                while True:
                    try:
                        sst = int(input("Enter SST "+Fore.LIGHTBLACK_EX +
                                        "(Ex - 255)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID SST ")
                        print('')
                        continue

                while True:
                    mcc = input("Enter mcc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("Enter a Valid mcc ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter mnc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("Enter a Valid mnc ")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-uecm/v1/'+str(supi)+'/registrations/smf-registrations'+str(pduSessionId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {"smfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                "pduSessionId": pduSessionId,
                                "singleNssai": {
                                    "sst": sst
                                },
                                "plmnId": {
                                    "mcc": str(mcc),
                                    "mnc": str(mnc)
                                }
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PUT request is used to register an SMF as serving the specified UE's PDU session. Direction: SMF --> UDM")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None

    class SMF_Deregistration():

        def Deregister_SMF():
            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter SUPI "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid SUPI")
                        print('')
                        continue

                while True:
                    subscription_id = input("Enter subscription Id "+Fore.LIGHTBLACK_EX +
                                            "(Ex -  0e02d826-db22-41ec-87dd-bf9efe567155)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, subscription_id):
                        break

                    else:
                        print("Enter a Valid ID")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/nudm-uecm/v1/'+str(supi)+'/registrations/smf-registrations/'+str(subscription_id))
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(crl.CUSTOMREQUEST, "DELETE")
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nSMF to deregister itself from the specified PDU session context. Direction: SMF --> UDM ")
                crl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None

    class SMSF_registration_for_3GPP_access():

        def Register_SMSF_for_3GPP_Access():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                while True:
                    mcc = input("Enter mcc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("Enter a Valid mcc ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter mnc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("Enter a Valid mnc ")
                        print('')
                        continue

                while True:
                    name = input("Enter name "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  ([A-Za-z0-9]+([-A-Za-z0-9]+)\.)+[a-z]{2,})"+Fore.RESET+"- ")
                    if re.fullmatch(smsfDiameterAddress_regex, name):
                        break

                    else:
                        print("Enter a Valid name ")
                        print('')
                        continue

                while True:
                    realm = input("Enter realm "+Fore.LIGHTBLACK_EX +
                                  "(Ex -  ([A-Za-z0-9]+([-A-Za-z0-9]+)\.)+[a-z]{2,})"+Fore.RESET+"- ")
                    if re.fullmatch(smsfDiameterAddress_regex, realm):
                        break

                    else:
                        print("Enter a Valid realm ")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-uecm/v1/'+str(supi)+'/registrations/smsf-3gpp-access')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {"smsfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                "plmnId": {
                                    "mcc": str(mcc),
                                    "mnc": str(mnc)
                                },
                                "smsfDiameterAddress": {
                                    "name": str(name),
                                    "realm": str(realm)
                                }
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PUT request is used to register the serving SMSF for a UE registered via 3GPP access. Direction: SMSF --> UDM")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None

    class SMSF_Deregistration_for_3GPP_Access():

        def Deregiser_SMSF_3GPP_Access():
            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter SUPI "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a SUPI")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/nudm-uecm/v1/'+str(supi)+'/registrations/smsf-3gpp-access/')
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(crl.CUSTOMREQUEST, "DELETE")
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nDeregister an SMSF from a UE that registered via 3GPP access. Direction: SMSF --> UDM")
                crl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class SMSF_3GPP_access_Registration_Info_Retrieval():

        def Retrieve_SMSF_Registration_3GPP_Access():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-uecm/v1/'+str(supi)+'/registrations/smsf-3gpp-access')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print(
                        "\nRetrieve a UE's SMSF registration for 3GPP access. Direction: NEF --> UDM")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class SMSF_registration_for_non_3GPP_access():

        def Register_SMSF_for_Non_3GPP_Access():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                while True:
                    mcc = input("Enter mcc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("Enter a Valid mcc ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter mnc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("Enter a Valid mnc ")
                        print('')
                        continue

                while True:
                    name = input("Enter name "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  ([A-Za-z0-9]+([-A-Za-z0-9]+)\.)+[a-z]{2,})"+Fore.RESET+"- ")
                    if re.fullmatch(smsfDiameterAddress_regex, name):
                        break

                    else:
                        print("Enter a Valid name ")
                        print('')
                        continue

                while True:
                    realm = input("Enter realm "+Fore.LIGHTBLACK_EX +
                                  "(Ex -  ([A-Za-z0-9]+([-A-Za-z0-9]+)\.)+[a-z]{2,})"+Fore.RESET+"- ")
                    if re.fullmatch(smsfDiameterAddress_regex, realm):
                        break

                    else:
                        print("Enter a Valid realm ")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-uecm/v1/'+str(supi)+'/registrations/smsf-non-3gpp-access')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {"smsfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                "plmnId": {
                                    "mcc": str(mcc),
                                    "mnc": str(mnc)
                                },
                                "smsfDiameterAddress": {
                                    "name": str(name),
                                    "realm": str(realm)
                                }
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PUT request is used to register the serving SMSF for a UE registered via 3GPP access. Direction: SMSF --> UDM")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None

    class SMSF_Deregistration_for_non_3GPP_access():

        def Deregiser_SMSF_Non_3GPP_Access():
            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/nudm-uecm/v1/'+str(supi)+'/registrations/smsf-non-3gpp-access/')
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(crl.CUSTOMREQUEST, "DELETE")
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nSMF to deregister itself from the specified PDU session context. Direction: SMF --> UDM ")
                crl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class SMSF_non_3GPP_access_Registration_Info_Retrieval():

        def Retrieve_SMSF_Registration_Non_3GPP_Access():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-uecm/v1/'+str(supi)+'/registrations/smsf-non-3gpp-access')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, [
                            'Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print(
                        "\nRetrieve a UE's SMSF registration for non-3GPP access. Direction: NEF --> UDM ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


class UE_Authentication():

    class Generate_Auth_Data():

        def Generate_Authentication_Data():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter SUPI or SUCI  "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID SUPI or SUCI  ")
                        print('')
                        continue

                while True:
                    servingNetworkName = input("Enter serving Network Name "+Fore.LIGHTBLACK_EX +
                                               "(Ex -  (5G:mnc[0-9]{3}[.]mcc[0-9]{3}[.]3gppnetwork[.]org(:[A-F0-9]{11}))"+Fore.RESET+"- ")
                    if re.fullmatch(servingNetworkName_regex, servingNetworkName):
                        break

                    else:
                        print("Enter a Valid serving Network Name ")
                        print('')
                        continue

                while True:
                    rand = input("Enter rand "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  ([A-Za-z0-9]+([-A-Za-z0-9]+)\.)+[a-z]{2,})"+Fore.RESET+"- ")
                    if re.fullmatch(rand_regex, rand):
                        break

                    else:
                        print("Enter a Valid rand ")
                        print('')
                        continue

                while True:
                    auts = input("Enter auts "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  ([A-Za-z0-9]+([-A-Za-z0-9]+)\.)+[a-z]{2,})"+Fore.RESET+"- ")
                    if re.fullmatch(auts_regex, auts):
                        break

                    else:
                        print("Enter a Valid auts ")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-ueau/v1/'+str(supi)+'/security-information/generate-auth-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {
                    "servingNetworkName": str(servingNetworkName),
                    "resynchronizationInfo": {
                        "rand": str(rand),
                        "auts": str(auts)
                    },
                    "ausfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6"
                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nRetrieve authentication data for the UE. The UDM calculates a fresh authentication vector based on the received information and the stored security information for the SUPI if 5G-AKA or EAP-AKA' is selected. Otherwise, the UDM provides corresponding authentication information. Direction: AUSF --> UDM")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None

    class Confirm_Auth():

        def Confirm_Authentication():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter SUPI or SUCI  "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID SUPI or SUCI  ")
                        print('')
                        continue

                while True:
                    servingNetworkName = input("Enter serving Network Name "+Fore.LIGHTBLACK_EX +
                                               "(Ex -  (5G:mnc[0-9]{3}[.]mcc[0-9]{3}[.]3gppnetwork[.]org(:[A-F0-9]{11}))"+Fore.RESET+"- ")
                    if re.fullmatch(servingNetworkName_regex, servingNetworkName):
                        break

                    else:
                        print("Enter a Valid serving Network Name ")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-ueau/v1/'+str(supi)+'/auth-events')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {
                    "nfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                    "success": True,
                    "timeStamp": str(datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")),
                    "authType": "5G_AKA",
                                "servingNetworkName": str(servingNetworkName)
                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\ncreate a new authentication event. The AUSF reports the occurence of a successful or unsuccessful authentication to the UDM. Direction: AUSF --> UDM")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None


class Event_Exposure():

    class Create_EE_Subscription():

        def Create_Event_Exposure_Subscription():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter SUPI or SUCI  "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID SUPI or SUCI  ")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-ee/v1/'+str(supi)+'/ee-subscriptions')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {
                    "callbackReference": "string",
                    "monitoringConfigurations": {}
                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis POST request is sent to the UDM, to subscribe an NEF to the specified events in the UDM for a particular UE. Direction: NEF --> UDM")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None

    class Delete_EE_Subscription():

        def Delete_Event_Exposure_Subscription():
            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter SUPI "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid SUPI")
                        print('')
                        continue

                while True:
                    subscription_id = input("Enter subscription Id "+Fore.LIGHTBLACK_EX +
                                            "(Ex -  0e02d826-db22-41ec-87dd-bf9efe567155)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, subscription_id):
                        break

                    else:
                        print("Enter a Valid ID")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/nudm-ee/v1/'+str(supi)+'/ee-subscriptions/'+str(subscription_id))
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(crl.CUSTOMREQUEST, "DELETE")
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nSMF to deregister itself from the specified PDU session context. Direction: SMF --> UDM ")
                crl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class Update_EE_Subscription():

        def Update_Event_Exposure_Subscription():

            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                while True:
                    nf_instance_id = input("Enter subscriptionId "+Fore.LIGHTBLACK_EX +
                                           "(Ex -  0e02d826-db22-41ec-87dd-bf9efe567155)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, nf_instance_id):
                        break

                    else:
                        print("Enter a Valid ID")
                        print('')
                        continue

                while True:
                    try:
                        path = str(input("Enter path "+Fore.LIGHTBLACK_EX +
                                         "(Ex - )"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID path.")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/nudm-ee/v1/'+str(supi)+'/ee-subscriptions/'+str(nf_instance_id))
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                               'Content-Type: application/json'])
                crl.setopt(crl.CUSTOMREQUEST, 'PATCH')

                body_as_dict = [
                    {
                        "op": "add",
                        "path": str(path)
                    }
                ]

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                crl.setopt(pycurl.READDATA, body_as_file_object)
                crl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PATCH request is used to update the subscription identified by {subscriptionId}. Direction: NEF --> UDM")
                crl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


class Parameter_Provisioning():

    class Subscription_Data_Update():

        def Update_Subscription():

            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/nudm-pp/v1/'+str(supi)+'/pp-data')
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                               'Content-Type: application/json'])
                crl.setopt(crl.CUSTOMREQUEST, 'PATCH')

                body_as_dict = {
                    "communicationCharacteristics": {
                        "ppSubsRegTimer": {
                            "subsRegTimer": 0,
                            "afInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                            "referenceId": 0
                        },
                        "ppActiveTime": {
                            "activeTime": 0,
                            "afInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                            "referenceId": 0
                        },
                        "ppDlPacketCount": 0
                    }
                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                crl.setopt(pycurl.READDATA, body_as_file_object)
                crl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PATCH request is used to update a UE's provisioned parameters. Direction: NEF --> UDM or AMF --> UDM or SOR-AF --> UDM")
                crl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None
