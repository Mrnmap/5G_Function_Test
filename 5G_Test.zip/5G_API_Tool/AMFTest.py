from operator import concat
import inquirer
from secrets import choice
from colorama import Fore
from regex import P, T
import AMF
import API_PenTesting_Tool


# def cont():
#     questions = [
#         inquirer.List('Choice',
#                       message="Do you want continue ?",
#                       choices=['YES', 'NO'],)]
#     answers = inquirer.prompt(questions)
#     if answers['Choice'] == 'NO':
#         return False

#     return True


# def fun():
#     questions = [
#         inquirer.List('Function',
#                       message="Select the function",
#                       choices=['AUSF', 'BSF', 'AMF', 'NSSF', 'AMF'],), ]
#     answers = inquirer.prompt(questions)
#     print(answers)
#     if answers != None:
#         if answers["Function"] == 'AMF':
#             amf()

def amf():
    questions = [
        inquirer.List('AMF',
                      message="Select the AMF",
                      choices=['Communication', 'Event_Exposure','Location','MT'],), ]
    answers = inquirer.prompt(questions)
    if answers == None:
        API_PenTesting_Tool.fun()

    if answers["AMF"] == 'Communication':
        Communication()

    if answers["AMF"] == 'Event_Exposure':
        Event_Exposure()

    if answers["AMF"] == 'Location':
        Location()

    if answers["AMF"] == 'MT':
        MT()


def Communication():
    questions = [
        inquirer.List('Communication',
                      message="Select the Communication",
                      choices=['Individual_ueContext_Document', 'n1N2Message_collection_Document', 'N1N2_Subscriptions_Collection_for_Individual_UE_Contexts_Document', 'N1N2_Individual_Subscription_Document','Non_UE_N2Messages_collection_Document','Non_UE_N2Messages_Subscriptions_collection_Document','Non_UE_N2_Message_Notification_Individual_SubscriptionDocument','subscriptions_collection_Document','individual_subscription_Document'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        amf()

    elif answers["Communication"] == 'Individual_ueContext_Document':
        Individual_ueContext_Document()

    elif answers["Communication"] == 'n1N2Message_collection_Document':
        n1N2Message_collection_Document()

    elif answers["Communication"] == 'N1N2_Subscriptions_Collection_for_Individual_UE_Contexts_Document':
        N1N2_Subscriptions_Collection_for_Individual_UE_Contexts_Document()

    elif answers["Communication"] == 'N1N2_Individual_Subscription_Document':
        N1N2_Individual_Subscription_Document()

    elif answers["Communication"] == 'Non_UE_N2Messages_collection_Document':
        Non_UE_N2Messages_collection_Document()

    elif answers["Communication"] == 'Non_UE_N2Messages_Subscriptions_collection_Document':
        Non_UE_N2Messages_Subscriptions_collection_Document()

    elif answers["Communication"] == 'Non_UE_N2_MessaSubcriptions_Collectioncollection_Document':
        subscriptions_collection_Document()

    elif answers["Communication"] == 'individual_subscription_Document':
        individual_subscription_Document()


def Individual_ueContext_Document():
    questions = [
        inquirer.List('Individual_ueContext_Document',
                      message="Select the Individual_ueContext_Document",
                      choices=['Release_UE_Context', 'EBI_Assignment', 'UE_Context_Transfer', 'Registration_Status_Update'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Communication()

    elif answers["Individual_ueContext_Document"] == 'Release_UE_Context':
        AMF.Communication.Individual_ueContext_Document.Release_UE_Context()

    elif answers["Individual_ueContext_Document"] == 'EBI_Assignment':
        AMF.Communication.Individual_ueContext_Document.EBI_Assignment()

    elif answers["Individual_ueContext_Document"] == 'UE_Context_Transfer':
        AMF.Communication.Individual_ueContext_Document.UE_Context_Transfer()

    elif answers["Individual_ueContext_Document"] == 'Registration_Status_Update':
        AMF.Communication.Individual_ueContext_Document.Registration_Status_Update()


def n1N2Message_collection_Document():
    questions = [
        inquirer.List('n1N2Message_collection_Document',
                      message="Select the n1N2Message_collection_Document",
                      choices=['N1N2_Message_Transfer'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Communication()

    elif answers["n1N2Message_collection_Document"] == 'N1N2_Message_Transfer':
        AMF.Communication.n1N2Message_collection_Document.N1N2_Message_Transfer()

def N1N2_Subscriptions_Collection_for_Individual_UE_Contexts_Document():
    questions = [
        inquirer.List('N1N2_Subscriptions_Collection_for_Individual_UE_Contexts_Document',
                      message="Select the N1N2_Subscriptions_Collection_for_Individual_UE_Contexts_Document",
                      choices=['N1N2_Message_Subscribe'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Communication()

    elif answers["N1N2_Subscriptions_Collection_for_Individual_UE_Contexts_Document"] == 'N1N2_Message_Subscribe':
        AMF.Communication.N1N2_Subscriptions_Collection_for_Individual_UE_Contexts_Document.N1N2_Message_Subscribe()

def N1N2_Individual_Subscription_Document():
    questions = [
        inquirer.List('N1N2_Individual_Subscription_Document',
                      message="Select the N1N2_Individual_Subscription_Document",
                      choices=['N1N2_Message_UnSubscribe'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Communication()

    elif answers["N1N2_Individual_Subscription_Document"] == 'N1N2_Message_UnSubscribe':
        AMF.Communication.N1N2_Individual_Subscription_Document.N1N2_Message_UnSubscribe()

def Non_UE_N2Messages_collection_Document():
    questions = [
        inquirer.List('Non_UE_N2Messages_collection_Document',
                      message="Select the Non_UE_N2Messages_collection_Document",
                      choices=['Non_UE_N2_Message_Transfer'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Communication()

    elif answers["Non_UE_N2Messages_collection_Document"] == 'Non_UE_N2_Message_Transfer':
        AMF.Communication.Non_UE_N2Messages_collection_Document.Non_UE_N2_Message_Transfer()


def Non_UE_N2Messages_Subscriptions_collection_Document():
    questions = [
        inquirer.List('Non_UE_N2Messages_Subscriptions_collection_Document',
                      message="Select the Non_UE_N2Messages_Subscriptions_collection_Document",
                      choices=['Non_UE_N2_Information_Subscribe'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Communication()

    elif answers["Non_UE_N2Messages_Subscriptions_collection_Document"] == 'Non_UE_N2_Information_Subscribe':
        AMF.Communication.Non_UE_N2Messages_Subscriptions_collection_Document.Non_UE_N2_Information_Subscribe()


def Non_UE_N2_Message_Notification_Individual_SubscriptionDocument():
    questions = [
        inquirer.List('Non_UE_N2_Message_Notification_Individual_SubscriptionDocument',
                      message="Select the Non_UE_N2_Message_Notification_Individual_SubscriptionDocument",
                      choices=['Non_UE_N2_Information_Unsubscribe'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Communication()

    elif answers["Non_UE_N2_Message_Notification_Individual_SubscriptionDocument"] == 'Non_UE_N2_Information_Unsubscribe':
        AMF.Communication.Non_UE_N2_Message_Notification_Individual_SubscriptionDocument.Non_UE_N2_Information_Unsubscribe()


def subscriptions_collection_Document():
    questions = [
        inquirer.List('subscriptions_collection_Document',
                      message="Select the subscriptions_collection_Document",
                      choices=['AMF_Status_Change_Subscribe'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Communication()

    elif answers["subscriptions_collection_Document"] == 'AMF_Status_Change_Subscribe':
        AMF.Communication.subscriptions_collection_Document.AMF_Status_Change_Subscribe()


def individual_subscription_Document():
    questions = [
        inquirer.List('individual_subscription_Document',
                      message="Select the individual_subscription_Document",
                      choices=['AMF_Status_Change_Unsubscribe','Modify_an_AMF_Status_Change_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Communication()

    elif answers["individual_subscription_Document"] == 'AMF_Status_Change_Unsubscribe':
        AMF.Communication.individual_subscription_Document.AMF_Status_Change_Unsubscribe()

    elif answers["individual_subscription_Document"] == 'Modify_an_AMF_Status_Change_Subscription':
        AMF.Communication.individual_subscription_Document.Modify_an_AMF_Status_Change_Subscription()





def Event_Exposure():
    questions = [
        inquirer.List('Event_Exposure',
                      message="Select the Event_Exposure",
                      choices=['Subscriptions_collection_Document','Individual_subscription_Document'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        amf()

    elif answers["Event_Exposure"] == 'Subscriptions_collection_Document':
        AMF.Event_Exposure.Subscriptions_collection_Document()

    elif answers["Event_Exposure"] == 'Individual_subscription_Document':
        AMF.Event_Exposure.Individual_subscription_Document()

def Subscriptions_collection_Document():
    questions = [
        inquirer.List('Subscriptions_collection_Document',
                      message="Select the Subscriptions_collection_Document",
                      choices=['Create_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Event_Exposure()

    elif answers["Subscriptions_collection_Document"] == 'Create_Subscription':
        AMF.Subscriptions_collection_Document.Create_Subscription()

def Individual_subscription_Document():
    questions = [
        inquirer.List('Individual_subscription_Document',
                      message="Select the Individual_subscription_Document",
                      choices=['Modify_Subscription','Delete_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Event_Exposure()

    elif answers["Individual_subscription_Document"] == 'Modify_Subscription':
        AMF.Individual_subscription_Document.Modify_Subscription()

    elif answers["Individual_subscription_Document"] == 'Delete_Subscription':
        AMF.Individual_subscription_Document.Delete_Subscription()

def Location():
    questions = [
        inquirer.List('Location',
                      message="Select the Location",
                      choices=['Individual_UE_context_Document'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        amf()

    elif answers["Location"] == 'Individual_UE_context_Document':
        AMF.Location.Individual_UE_context_Document()


def Individual_UE_context_Document():
    questions = [
        inquirer.List('Individual_UE_context_Document',
                      message="Select the Individual_UE_context_Document",
                      choices=['Provide_Positioning_Info','Provide_Location_Info'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Event_Exposure()

    elif answers["Individual_UE_context_Document"] == 'Provide_Positioning_Info':
        AMF.Individual_UE_context_Document.Provide_Positioning_Info()

    elif answers["Individual_UE_context_Document"] == 'Provide_Location_Info':
        AMF.Individual_UE_context_Document.Provide_Location_Info()


def MT():
    questions = [
        inquirer.List('MT',
                      message="Select the MT",
                      choices=['ueContext_Document','ueReachInd_Document'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        amf()

    elif answers["MT"] == 'ueContext_Document':
        AMF.MT.ueContext_Document()

    elif answers["MT"] == 'ueReachInd_Document':
        AMF.MT.ueReachInd_Document()

def ueContext_Document():
    questions = [
        inquirer.List('ueContext_Document',
                      message="Select the ueContext_Document",
                      choices=['Provide_Domain_Selection_Info'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        MT()

    elif answers["ueContext_Document"] == 'Provide_Domain_Selection_Info':
        AMF.ueContext_Document.Provide_Domain_Selection_Info()

def ueReachInd_Document():
    questions = [
        inquirer.List('ueReachInd_Document',
                      message="Select the ueReachInd_Document",
                      choices=['Update_UE_Reachable_Indication'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        MT()

    elif answers["ueReachInd_Document"] == 'Update_UE_Reachable_Indication':
        AMF.ueReachInd_Document.Update_UE_Reachable_Indication()


# while True:
#     fun()

#     if not cont():
#         break


