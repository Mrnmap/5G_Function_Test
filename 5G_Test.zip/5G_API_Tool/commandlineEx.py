
## run like this 
# python3 filename num1 num2
import sys
a= sys.argv[1]
b= sys.argv[2]
sum=str( a+b)
print (" sum is", sum )  