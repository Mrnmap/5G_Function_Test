import pycurl
import json
from io import StringIO
from colorama import Fore
import ipaddress
import re


id_regex = re.compile(r'([A-Za-z0-9])+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+')
nf_regex = re. compile(r'[A-Za-z]+')
supiOrsuci_regex = re. compile(r'imsi-[0-9]{5,15}|nai-.+|gli-.+|gci-.+|suci-(0-[0-9]{3}-[0-9]{2,3}|[1-7]-.+)-[0-9]{1,4}-(0-0-.+|[a-fA-F1-9]-([1-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])-[a-fA-F0-9]+)|.+')
servingNetworkName_regex = re. compile(r'5G:mnc[0-9]{3}[.]mcc[0-9]{3}[.]3gppnetwork[.]org(:[A-F0-9]{11})?')
mcc_regex = re.compile(r'[0-9]{3}')
mnc_regex = re.compile(r'[0-9]{2,3}')
supi_regex = re.compile(r'[0-9]{15,16}')
amfId_regex = re.compile(r'[A-Fa-f0-9]{6}')

class Communication():

    class Individual_ueContext_Document():

        def Create_UE_Context():
            pass

        def Release_UE_Context():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.5)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    ueContextId = input("Enter ue Context Id "+Fore.LIGHTBLACK_EX +
                                            "(Ex -  b9a0d5f2-c628-41ec-905e-516c5b30fb11)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, ueContextId):
                        break

                    else:
                        print("Enter a Valid ue Context Id")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/namf-comm/v1/ue-contexts/'+str(ueContextId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {"supi": str(supi),
                                "ngapCause": {
                                    "group": 0,
                                    "value": 0
                                }
                                }
                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED+"\nThis POST request is used by the source AMF to instruct the target AMF to release the specified UE Context when an Inter-RAN node N2-based handover is cancelled (see TS 23.502, clause 4.9.1.4). Direction: Source AMF --> Target AMF")

                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


        def EBI_Assignment():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.5)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    ueContextId = input("Enter ue Context Id "+Fore.LIGHTBLACK_EX +
                                            "(Ex -  b9a0d5f2-c628-41ec-905e-516c5b30fb11)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, ueContextId):
                        break

                    else:
                        print("Enter a Valid ue Context Id")
                        print('')
                        continue

                while True:
                    try:
                        pduSessionId = int(input("Enter pduSessionId "+Fore.LIGHTBLACK_EX +
                                "(Ex - 255)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID pduSessionId.")
                        print('')
                        continue


                while True:
                    mcc = input("Enter MCC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("This is NOT a VALID MCC ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter MNC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("This is NOT a VALID MNC")
                        print('')
                        continue

                while True:
                    amfId = input("Enter amfId "+Fore.LIGHTBLACK_EX +
                                "(Ex - 123456)"+Fore.RESET+"- ")
                    if re.fullmatch(amfId_regex, amfId):
                        break

                    else:
                        print("This is NOT a VALID amfId")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/namf-comm/v1/ue-contexts/'+str(ueContextId)+'/assign-ebi')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {  "pduSessionId": pduSessionId,
                                    "arpList": [
                                        {
                                        "priorityLevel": 15,   # Values are ordered in decreasing order of priority, with 1 as the highest priority and 15 as the lowest.
                                        "preemptCap": "NOT_PREEMPT",
                                        "preemptVuln": "NOT_PREEMPTABLE"
                                        }
                                    ],
                                    "releasedEbiList": [
                                        15
                                    ],
                                    "oldGuami": {
                                        "plmnId": {
                                        "mcc": str(mcc),
                                        "mnc": str(mnc)
                                        },
                                        "amfId": str(amfId)
                                    }
                                }
                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED+"\nThis POST request is used by an SMF to request that the serving AMF allocate EPS bearer ID(s) to the bearers mapped from QoS flow(s) for an existing PDU session. EBI allocation shall apply only to PDU Session(s) via 3GPP access supporting EPS interworking with N26. Direction: SMF --> AMF")

                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


        def UE_Context_Transfer():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.5)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    ueContextId = input("Enter ue Context Id "+Fore.LIGHTBLACK_EX +
                                            "(Ex -  b9a0d5f2-c628-41ec-905e-516c5b30fb11)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, ueContextId):
                        break

                    else:
                        print("Enter a Valid ue Context Id")
                        print('')
                        continue

                while True:
                    mcc = input("Enter MCC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("This is NOT a VALID MCC ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter MNC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("This is NOT a VALID MNC")
                        print('')
                        continue

                while True:
                    contentId = input("Enter contentId "+Fore.LIGHTBLACK_EX +
                                "(Ex - 123456)"+Fore.RESET+"- ")
                    if re.fullmatch(amfId_regex, contentId):
                        break

                    else:
                        print("This is NOT a VALID contentId")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/namf-comm/v1/ue-contexts/'+str(ueContextId)+'/transfer')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = { "reason": "INIT_REG",
                                "accessType": "3GPP_ACCESS",
                                "plmnId": {
                                    "mcc": str(mcc),
                                    "mnc": str(mnc)
                                },
                                "regRequest": {
                                    "n1MessageClass": "5GMM",
                                    "n1MessageContent": {
                                    "contentId": "string"
                                    }
                                }
                                }
                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED+"\nThis POST request is invoked by a target AMF towards the source AMF when the target AMF receives a Registration Request with the UE's 5G-GUTI included, and the serving AMF has changed since last registration, to retrieve the UE Context, e.g. the UE's SUPI and MM Context, in the source AMF. Direction: Target AMF --> Source AMF")

                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


        def Registration_Status_Update():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.5)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    ueContextId = input("Enter ue Context Id "+Fore.LIGHTBLACK_EX +
                                            "(Ex -  b9a0d5f2-c628-41ec-905e-516c5b30fb11)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, ueContextId):
                        break

                    else:
                        print("Enter a Valid ue Context Id")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/namf-comm/v1/ue-contexts/'+str(ueContextId)+'/transfer-update')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {  "transferStatus": "TRANSFERRED",
                                    "toReleaseSessionList": [
                                        255
                                    ],  
                                    "pcfReselectedInd": True
                                }
                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED+"\nThis POST request is invoked by a target AMF towards the source AMF when the target AMF receives a Registration Request with the UE's 5G-GUTI included, and the serving AMF has changed since last registration, to retrieve the UE Context, e.g. the UE's SUPI and MM Context, in the source AMF. Direction: Target AMF --> Source AMF")

                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


    class n1N2Message_collection_Document():

        def N1N2_Message_Transfer():
            pass

    class N1N2_Subscriptions_Collection_for_Individual_UE_Contexts_Document():

        def N1N2_Message_Subscribe():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.5)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    ueContextId = input("Enter ue Context Id "+Fore.LIGHTBLACK_EX +
                                            "(Ex -  b9a0d5f2-c628-41ec-905e-516c5b30fb11)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, ueContextId):
                        break

                    else:
                        print("Enter a Valid ue Context Id")
                        print('')
                        continue

                while True:
                    mcc = input("Enter MCC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("This is NOT a VALID MCC ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter MNC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("This is NOT a VALID MNC")
                        print('')
                        continue

                while True:
                    amfID = input("Enter amfID "+Fore.LIGHTBLACK_EX +
                                "(Ex - 123456)"+Fore.RESET+"- ")
                    if re.fullmatch(amfId_regex, amfID):
                        break

                    else:
                        print("This is NOT a VALID amfID")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/namf-comm/v1/ue-contexts/'+str(ueContextId)+'/n1-n2-messages/subscriptions')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {
                                    "oldGuami": {
                                        "plmnId": {
                                        "mcc": str(mcc),
                                        "mnc": str(mnc)
                                        },
                                        "amfId": str(amfID)
                                    }
                                }
                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED+"\nThis POST request is used by NF service consumers to subscribe to the AMF for notification of UE-specific N1 messages of a specific type or N2 information of a specific type. Direction: NF Service Consumer --> AMF")

                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


    class N1N2_Individual_Subscription_Document():

        def N1N2_Message_UnSubscribe():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.5)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter ue Context Id"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid ue Context Id")
                        print('')
                        continue

                while True:
                    subsId = input("Enter subscriptionId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  b9f2f940-c628-41ec-aa78-9163487d7302)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, subsId):
                        break

                    else:
                        print("Enter a Valid subscriptionId")
                        print('')
                        continue
                    
                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/namf-comm/v1/ue-contexts/'+str(supi)+'/n1-n2-messages/subscriptions/'+str(subsId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()      

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nThis DELETE request is used by an NF service consumer to cancel its N1N2 message subscription. Direction: NF Service Consumer --> AMF")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


    class Non_UE_N2Messages_collection_Document():

        def Non_UE_N2_Message_Transfer():
            pass

    class Non_UE_N2Messages_Subscriptions_collection_Document():

        def Non_UE_N2_Information_Subscribe():
            pass

    class Non_UE_N2_Message_Notification_Individual_SubscriptionDocument:

        def Non_UE_N2_Information_Unsubscribe():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.5)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue


                while True:
                    subsId = input("Enter n2 Notify Subscription Id "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  b9f2f940-c628-41ec-aa78-9163487d7302)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, subsId):
                        break

                    else:
                        print("Enter a Valid n2 Notify Subscription Id ")
                        print('')
                        continue
                    
                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/namf-comm/v1/non-ue-n2-messages/subscriptions/'+str(subsId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()      

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nThis DELETE request is used by an NF service consumer to cancel its N1N2 message subscription. Direction: NF Service Consumer --> AMF")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


    class subscriptions_collection_Document():

        def AMF_Status_Change_Subscribe():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.5)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    try:
                        amfStatusUri = int(input("Enter amfStatusUri "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID amfStatusUri.")
                        print('')
                        continue

                while True:
                    mcc = input("Enter MCC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("This is NOT a VALID MCC ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter MNC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("This is NOT a VALID MNC")
                        print('')
                        continue

                while True:
                    amfID = input("Enter amfID "+Fore.LIGHTBLACK_EX +
                                "(Ex - 123456)"+Fore.RESET+"- ")
                    if re.fullmatch(amfId_regex, amfID):
                        break

                    else:
                        print("This is NOT a VALID amfID")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/namf-comm/v1/subscriptions')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {
                                "amfStatusUri": str(amfStatusUri),
                                "guamiList": [
                                    {
                                    "plmnId": {
                                        "mcc": str(mcc),
                                        "mnc": str(mnc)
                                    },
                                    "amfId": str(amfID)
                                    }
                                ]
                                }
                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED+"\nThis POST request is used by an NF Service Consumer to subscribe the status change of the AMF and is used during the procedure AMF planned removal. Direction NF Service Consumer --> AMF")

                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


    class individual_subscription_Document():

        def AMF_Status_Change_Unsubscribe():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.5)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue


                while True:
                    subsId = input("Enter n2 Notify Subscription Id "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  b9f2f940-c628-41ec-aa78-9163487d7302)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, subsId):
                        break

                    else:
                        print("Enter a Valid n2 Notify Subscription Id ")
                        print('')
                        continue
                    
                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/namf-comm/v1/subscriptions/'+str(subsId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()      

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nThis DELETE request is used by an NF service consumer to cancel its N1N2 message subscription. Direction: NF Service Consumer --> AMF")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


        def Modify_an_AMF_Status_Change_Subscription():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.5)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    try:
                        amfStatusUri = int(input("Enter amfStatusUri "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID amfStatusUri.")
                        print('')
                        continue

                while True:
                    mcc = input("Enter MCC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("This is NOT a VALID MCC ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter MNC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("This is NOT a VALID MNC")
                        print('')
                        continue

                while True:
                    amfID = input("Enter amfID "+Fore.LIGHTBLACK_EX +
                                "(Ex - 123456)"+Fore.RESET+"- ")
                    if re.fullmatch(amfId_regex, amfID):
                        break

                    else:
                        print("This is NOT a VALID amfID")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/namf-comm/v1/subscriptions')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {
                                "amfStatusUri": str(amfStatusUri),
                                "guamiList": [
                                    {
                                    "plmnId": {
                                        "mcc": str(mcc),
                                        "mnc": str(mnc)
                                    },
                                    "amfId": str(amfID)
                                    }
                                ]
                                }
                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED+"\nThis POST request is used by an NF Service Consumer to subscribe the status change of the AMF and is used during the procedure AMF planned removal. Direction NF Service Consumer --> AMF")

                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None



class Event_Exposure():

    class Subscriptions_collection_Document():

        def Create_Subscription():
            pass

    class Individual_subscription_Document():

        def Modify_Subscription():
            pass

        def Delete_Subscription():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.5)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter ue Identity"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid ueIdentity")
                        print('')
                        continue

                while True:
                    subsId = input("Enter subscriptionId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  b9f2f940-c628-41ec-aa78-9163487d7302)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, subsId):
                        break

                    else:
                        print("Enter a Valid subscriptionId")
                        print('')
                        continue
                    
                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-ee/v1/'+str(supi)+'/ee-subscriptions/'+str(subsId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()      

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nThis DELETE request is used by the subscribed NF service consumer to unsubscribe from event notifications. Direction: NF Service Consumer --> AMF")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None



class Location():

    class Individual_UE_context_Document():

        def Provide_Positioning_Info():
            pass

        def Provide_Loaction_Info():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.5)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    ueContextId = input("Enter ue Context Id "+Fore.LIGHTBLACK_EX +
                                            "(Ex -  b9a0d5f2-c628-41ec-905e-516c5b30fb11)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, ueContextId):
                        break

                    else:
                        print("Enter a Valid ue Context Id")
                        print('')
                        continue

                while True:
                    mcc = input("Enter MCC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("This is NOT a VALID MCC ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter MNC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("This is NOT a VALID MNC")
                        print('')
                        continue

                while True:
                    amfID = input("Enter amfID "+Fore.LIGHTBLACK_EX +
                                "(Ex - 123456)"+Fore.RESET+"- ")
                    if re.fullmatch(amfId_regex, amfID):
                        break

                    else:
                        print("This is NOT a VALID amfID")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/namf-loc/v1/'+str(ueContextId)+'/provide-loc-info')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {  "oldGuami": {
                                    "plmnId": {
                                    "mcc": str(mcc),
                                    "mnc": str(mnc)
                                    },
                                    "amfId": str(amfID)
                                }
                                }
                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED+"\nThis POST request is used to request the Network Provided Location Information (NPLI) of a target UE. Direction: UDM --> AMF")

                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None



class MT():

    class ueContext_Document():

        def Provide_Domain_Selection_Info():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.5)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/namf-mt/v1/ue-contexts/'+str(supi))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRequest UE information for terminating domain selection of IMS voice. Direction: UDM --> AMF")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class ueReachInd_Document():

        def Update_UE_Reachable_Indication():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.5)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    ueContextId = input("Enter ue Context Id "+Fore.LIGHTBLACK_EX +
                                            "(Ex -  b9a0d5f2-c628-41ec-905e-516c5b30fb11)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, ueContextId):
                        break

                    else:
                        print("Enter a Valid ue Context Id")
                        print('')
                        continue

                while True:
                    mcc = input("Enter MCC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("This is NOT a VALID MCC ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter MNC "+Fore.LIGHTBLACK_EX +
                                "(Ex - 45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("This is NOT a VALID MNC")
                        print('')
                        continue

                while True:
                    amfID = input("Enter amfID "+Fore.LIGHTBLACK_EX +
                                "(Ex - 123456)"+Fore.RESET+"- ")
                    if re.fullmatch(amfId_regex, amfID):
                        break

                    else:
                        print("This is NOT a VALID amfID")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/namf-mt/v1/ue-contexts/'+str(ueContextId)+'/ue-reachind')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {   "reachability": "UNREACHABLE",
                                    "supportedFeatures": "string",
                                    "oldGuami": {
                                    "plmnId": {
                                    "mcc": str(mcc),
                                    "mnc": str(mnc)
                                    },
                                    "amfId": str(amfID)
                                }
                                }
                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED+"\nThis PUT request is used to enable the reachability of the UE. Direction: SMSF --> AMF or SMF --> AMF")

                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

