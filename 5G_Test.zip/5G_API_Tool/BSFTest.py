from operator import concat
import inquirer
from secrets import choice
from colorama import Fore
from regex import P, T
import BSF
import API_PenTesting_Tool


# def cont():
#     questions = [
#         inquirer.List('Choice',
#                       message="Do you want continue ?",
#                       choices=['YES', 'NO'],)]
#     answers = inquirer.prompt(questions)
#     if answers['Choice'] == 'NO':
#         return False

#     return True


# def fun():
#     questions = [
#         inquirer.List('Function',
#                       message="Select the function",
#                       choices=['AUSF', 'BSF', 'AMF', 'NSSF', 'AMF'],), ]
#     answers = inquirer.prompt(questions)
#     print(answers)
#     if answers != None:
#         if answers["Function"] == 'BSF':
#             bsf()

def bsf():
    questions = [
        inquirer.List('BSF',
                      message="Select the BSF",
                      choices=['Management'],), ]
    answers = inquirer.prompt(questions)
    if answers == None:
        API_PenTesting_Tool.fun()

    if answers["BSF"] == 'Management':
        Management()


def Management():
    questions = [
        inquirer.List('Management',
                      message="Select the Management",
                      choices=['Default'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        bsf()

    elif answers["Management"] == 'Default':
        Default()


def Default():
    questions = [
        inquirer.List('Default',
                      message="Select the Default",
                      choices=['Register','Retrieve_Session_Binding','Deregister'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Management()

    elif answers["Default"] == 'Register':
        BSF.Management.Default.Register()

    elif answers["Default"] == 'Retrieve_Session_Binding':
        BSF.Management.Default.Retrieve_Session_Binding()

    elif answers["Default"] == 'Deregister':
        BSF.Management.Default.Deregister()

# while True:
#     fun()

#     if not cont():
#         break


