from operator import concat
import inquirer
from secrets import choice
from colorama import Fore
from regex import P, T
import AUSF
import API_PenTesting_Tool


# def cont():
#     questions = [
#         inquirer.List('Choice',
#                       message="Do you want continue ?",
#                       choices=['YES', 'NO'],)]
#     answers = inquirer.prompt(questions)
#     if answers['Choice'] == 'NO':
#         return False

#     return True


# def fun():
#     questions = [
#         inquirer.List('Function',
#                       message="Select the function",
#                       choices=['AUSF', 'BSF', 'AMF', 'NSSF', 'AMF'],), ]
#     answers = inquirer.prompt(questions)
#     print(answers)
#     if answers != None:
#         if answers["Function"] == 'AUSF':
#             ausf()

def ausf():
    questions = [
        inquirer.List('AUSF',
                      message="Select the AUSF",
                      choices=['UE_Authentication','SOR_Protection','UPU_Protection'],), ]
    answers = inquirer.prompt(questions)
    if answers == None:
        API_PenTesting_Tool.fun()

    if answers["AUSF"] == 'UE_Authentication':
        UE_Authentication()

    if answers["AUSF"] == 'SOR_Protection':
        SOR_Protection()

    if answers["AUSF"] == 'UPU_Protection':
        UPU_Protection()

def UE_Authentication():
    questions = [
        inquirer.List('UE_Authentication',
                      message="Select the UE_Authentication",
                      choices=['Default'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        ausf()

    elif answers["UE_Authentication"] == 'Default':
        Default1()


def Default1():
    questions = [
        inquirer.List('Default',
                      message="Select the Default",
                      choices=['Authenticate_UE','AKA_Confirmation','EAP_Session_Information'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Authentication()

    elif answers["Default"] == 'Authenticate_UE':
        AUSF.UE_Authentication.Default.Authenticate_UE()

    elif answers["Default"] == 'AKA_Confirmation':
        AUSF.UE_Authentication.Default.AKA_Confirmation()

    elif answers["Default"] == 'EAP_Session_Information':
        AUSF.UE_Authentication.Default.EAP_Session_Information()

def SOR_Protection():
    questions = [
        inquirer.List('SOR_Protection',
                      message="Select the 5G_SOR_Protection",
                      choices=['Default'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        ausf()

    elif answers["SOR_Protection"] == 'Default':
        Default2()


def Default2():
    questions = [
        inquirer.List('Default',
                      message="Select the Default",
                      choices=['Generate_SoR_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        SOR_Protection()

    elif answers["Default"] == 'Generate_SoR_Data':
        AUSF.SOR_Protection.Default.Generate_SOR_Data()

def UPU_Protection():
    questions = [
        inquirer.List('UPU_Protection',
                      message="Select the UPU_Protection",
                      choices=['Default'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        ausf()

    elif answers["UPU_Protection"] == 'Default':
        Default3()


def Default3():
    questions = [
        inquirer.List('Default',
                      message="Select the Default",
                      choices=['Protect'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UPU_Protection()

    elif answers["Default"] == 'Protect':
        AUSF.UPU_Protection.Default.Protect()

# while True:
#     fun()

#     if not cont():
#         break


