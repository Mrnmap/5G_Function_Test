from operator import concat
import inquirer
from secrets import choice
from colorama import Fore
from regex import P, T
import UDM
import API_PenTesting_Tool


# def cont():
#     questions = [
#         inquirer.List('Choice',
#                       message="Do you want continue ?",
#                       choices=['YES', 'NO'],)]
#     answers = inquirer.prompt(questions)
#     if answers['Choice'] == 'NO':
#         return False

#     return True


# def fun():
#     questions = [
#         inquirer.List('Function',
#                       message="Select the function",
#                       choices=['AUSF', 'BSF', 'NSSF', 'AMF','UDM'],), ]
#     answers = inquirer.prompt(questions)
#     print(answers)
#     if answers != None:
#         if answers["Function"] == 'UDM':
#             udm()

def udm():
    questions = [
        inquirer.List('UDM',
                      message="Select the UDM",
                      choices=['Subscriber_Data_Management', 'UE_Context_Management','UE_Authentication','Event_Exposure','Parameter_Provisioning'],), ]
    answers = inquirer.prompt(questions)
    if answers == None:
        API_PenTesting_Tool.fun()

    if answers["UDM"] == 'Subscriber_Data_Management':
        Subscriber_Data_Management()

    if answers["UDM"] == 'UE_Context_Management':
        UE_Context_Management()

    if answers["UDM"] == 'UE_Authentication':
        UE_Authentication()

    if answers["UDM"] == 'Event_Exposure':
        Event_Exposure()

    if answers["UDM"] == 'Parameter_Provisioning':
        Parameter_Provisioning()


def Subscriber_Data_Management():
    questions = [
        inquirer.List('Subscriber_Data_Management',
                      message="Select the Subscriber_Data_Management",
                      choices=['Retrieval_of_multiple_data_sets', 'Slice_Selection_Subscription_Data_Retrieval', 'Access_and_Mobility_Subscription_Data_Retrieval', 'SMF_Selection_Subscription_Data_Retrieval','UE_Context_In_SMF_Data_Retrieval','UE_Context_In_SMSF_Data_Retrieval','Trace_Configuration_Data_Retrieval','Session_Management_Subscription_Data_Retrieval','SMS_Subscription_Data_Retrieval','SMS_Management_Subscription_Data_Retrieval','Subscription_Creation','Subscription_Deletion','Subscription_Modification','GPSI_to_SUPI_Translation','Providing_acknowledgement_of_Steering_of_Roaming','Providing_acknowledgement_of_UE_Parameters_Update','Providing_acknowledgement_of_S_NSSAIs_Update','Retrieval_of_shared_data','Subscription_Creation_for_shared_data','Subscription_Deletion_for_shared_data','Group_Identifiers'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        udm()

    elif answers["Subscriber_Data_Management"] == 'Retrieval_of_multiple_data_sets':
        Retrieval_of_multiple_data_sets()

    elif answers["Subscriber_Data_Management"] == 'Slice_Selection_Subscription_Data_Retrieval':
        Slice_Selection_Subscription_Data_Retrieval()

    elif answers["Subscriber_Data_Management"] == 'Access_and_Mobility_Subscription_Data_Retrieval':
        Access_and_Mobility_Subscription_Data_Retrieval()

    elif answers["Subscriber_Data_Management"] == 'SMF_Selection_Subscription_Data_Retrieval':
        SMF_Selection_Subscription_Data_Retrieval()

    elif answers["Subscriber_Data_Management"] == 'UE_Context_In_SMF_Data_Retrieval':
        UE_Context_In_SMF_Data_Retrieval()

    elif answers["Subscriber_Data_Management"] == 'UE_Context_In_SMSF_Data_Retrieval':
        UE_Context_In_SMSF_Data_Retrieval()

    elif answers["Subscriber_Data_Management"] == 'Session_Management_Subscription_Data_Retrieval':
        Session_Management_Subscription_Data_Retrieval()

    elif answers["Subscriber_Data_Management"] == 'SMS_Subscription_Data_Retrieval':
        SMS_Subscription_Data_Retrieval()

    elif answers["Subscriber_Data_Management"] == 'SMS_Management_Subscription_Data_Retrieval':
        SMS_Management_Subscription_Data_Retrieval()

    elif answers["Subscriber_Data_Management"] == 'Subscription_Creation':
        Subscription_Creation()

    elif answers["Subscriber_Data_Management"] == 'Subscription_Deletion':
        Subscription_Deletion()

    elif answers["Subscriber_Data_Management"] == 'Subscription_Modification':
        Subscription_Modification()

    elif answers["Subscriber_Data_Management"] == 'GPSI_to_SUPI_Translation':
        GPSI_to_SUPI_Translation()

    elif answers["Subscriber_Data_Management"] == 'Providing_acknowledgement_of_Steering_of_Roaming':
        Providing_acknowledgement_of_Steering_of_Roaming()

    elif answers["Subscriber_Data_Management"] == 'Providing_acknowledgement_of_UE_Parameters_Update':
        Providing_acknowledgement_of_UE_Parameters_Update()

    elif answers["Subscriber_Data_Management"] == 'Providing_acknowledgement_of_S_NSSAIs_Update':
        Providing_acknowledgement_of_S_NSSAIs_Update()

    elif answers["Subscriber_Data_Management"] == 'Retrieval_of_shared_data':
        Retrieval_of_shared_data()

    elif answers["Subscriber_Data_Management"] == 'Subscription_Creation_for_shared_data':
        Subscription_Creation_for_shared_data()

    elif answers["Subscriber_Data_Management"] == 'Subscription_Deletion_for_shared_data':
        Subscription_Deletion_for_shared_data()

    elif answers["Subscriber_Data_Management"] == 'Group_Identifiers':
        Group_Identifiers()

    elif answers["Subscriber_Data_Management"] == 'Trace_Configuration_Data_Retrieval':
        Trace_Configuration_Data_Retrieval()
        
def Retrieval_of_multiple_data_sets():
    questions = [
        inquirer.List('Retrieval_of_multiple_data_sets',
                      message="Select the Retrieval_of_multiple_data_sets",
                      choices=['Retrieve_Subscription_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["Retrieval_of_multiple_data_sets"] == 'Retrieve_Subscription_Data':
        UDM.Subscriber_Data_Management.Retrieval_of_multiple_data_sets.Retrieve_Subscription_Data()


def Slice_Selection_Subscription_Data_Retrieval():
    questions = [
        inquirer.List('Slice_Selection_Subscription_Data_Retrieval',
                      message="Select the Slice_Selection_Subscription_Data_Retrieval",
                      choices=['Retrieve_NSSAI'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["Slice_Selection_Subscription_Data_Retrieval"] == 'Retrieve_NSSAI':
        UDM.Subscriber_Data_Management.Slice_Selection_Subscription_Data_Retrieval.Retrieve_NSSAI()

def Access_and_Mobility_Subscription_Data_Retrieval():
    questions = [
        inquirer.List('Access_and_Mobility_Subscription_Data_Retrieval',
                      message="Select the Access_and_Mobility_Subscription_Data_Retrieval",
                      choices=['Retrieve_AM_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["Access_and_Mobility_Subscription_Data_Retrieval"] == 'Retrieve_AM_Data':
        UDM.Subscriber_Data_Management.Access_and_Mobility_Subscription_Data_Retrieval.Retrieve_AM_Data()

def SMF_Selection_Subscription_Data_Retrieval():
    questions = [
        inquirer.List('SMF_Selection_Subscription_Data_Retrieval',
                      message="Select the SMF_Selection_Subscription_Data_Retrieval",
                      choices=['Retrieve_SMF_Selection_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["SMF_Selection_Subscription_Data_Retrieval"] == 'Retrieve_SMF_Selection_Data':
        UDM.Subscriber_Data_Management.SMF_Selection_Subscription_Data_Retrieval.Retrieve_SMF_Selection_Data()

def UE_Context_In_SMF_Data_Retrieval():
    questions = [
        inquirer.List('UE_Context_In_SMF_Data_Retrieval',
                      message="Select the UE_Context_In_SMF_Data_Retrieval",
                      choices=['Retrieve_UE_Context_in_SMF_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["UE_Context_In_SMF_Data_Retrieval"] == 'Retrieve_UE_Context_in_SMF_Data':
        UDM.Subscriber_Data_Management.UE_Context_In_SMF_Data_Retrieval.Retrieve_UE_Context_in_SMF_Data()


def UE_Context_In_SMSF_Data_Retrieval():
    questions = [
        inquirer.List('UE_Context_In_SMSF_Data_Retrieval',
                      message="Select the UE_Context_In_SMSF_Data_Retrieval",
                      choices=['Retrieve_UE_Context_in_SMSF_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["UE_Context_In_SMSF_Data_Retrieval"] == 'Retrieve_UE_Context_in_SMSF_Data':
        UDM.Subscriber_Data_Management.UE_Context_In_SMSF_Data_Retrieval.Retrieve_UE_Context_in_SMSF_Data()


def Trace_Configuration_Data_Retrieval():
    questions = [
        inquirer.List('Trace_Configuration_Data_Retrieval',
                      message="Select the Trace_Configuration_Data_Retrieval",
                      choices=['Retrieve_Trace_Configuration_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["Trace_Configuration_Data_Retrieval"] == 'Retrieve_Trace_Configuration_Data':
        UDM.Subscriber_Data_Management.Trace_Configuration_Data_Retrieval.Retrieve_Trace_Configuration_Data()


def Session_Management_Subscription_Data_Retrieval():
    questions = [
        inquirer.List('Session_Management_Subscription_Data_Retrieval',
                      message="Select the Session_Management_Subscription_Data_Retrieval",
                      choices=['Retrieve_Session_Management_Subscription_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["Session_Management_Subscription_Data_Retrieval"] == 'Retrieve_Session_Management_Subscription_Data':
        UDM.Subscriber_Data_Management.Session_Management_Subscription_Data_Retrieval.Retrieve_Session_Management_Subscription_Data()


def SMS_Subscription_Data_Retrieval():
    questions = [
        inquirer.List('SMS_Subscription_Data_Retrieval',
                      message="Select the SMS_Subscription_Data_Retrieval",
                      choices=['Retrieve_SMS_Subscription_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["SMS_Subscription_Data_Retrieval"] == 'Retrieve_SMS_Subscription_Data':
        UDM.Subscriber_Data_Management.SMS_Subscription_Data_Retrieval.Retrieve_SMS_Subscription_Data()

def SMS_Management_Subscription_Data_Retrieval():
    questions = [
        inquirer.List('SMS_Management_Subscription_Data_Retrieval',
                      message="Select the SMS_Management_Subscription_Data_Retrieval",
                      choices=['Retrieve_SMS_Management_Subscription_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["SMS_Management_Subscription_Data_Retrieval"] == 'Retrieve_SMS_Management_Subscription_Data':
        UDM.Subscriber_Data_Management.SMS_Management_Subscription_Data_Retrieval.Retrieve_SMS_Management_Subscription_Data()

def Subscription_Creation():
    questions = [
        inquirer.List('Subscription_Creation',
                      message="Select the Subscription_Creation",
                      choices=['Subscribe_to_Notifications'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["Subscription_Creation"] == 'Subscribe_to_Notifications':
        UDM.Subscriber_Data_Management.Subscription_Creation.Subscribe_to_Notifications()

def Subscription_Deletion():
    questions = [
        inquirer.List('Subscription_Deletion',
                      message="Select the Subscription_Deletion",
                      choices=['Unsubscribe'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["Subscription_Deletion"] == 'Unsubscribe':
        UDM.Subscriber_Data_Management.Subscription_Deletion.Unsubscribe()

def Subscription_Modification():
    questions = [
        inquirer.List('Subscription_Modification',
                      message="Select the Subscription_Modification",
                      choices=['Modify_Subscription','Modify_Shared_Subscription_Data_Notification_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["Subscription_Modification"] == 'Modify_Subscription':
        UDM.Subscriber_Data_Management.Subscription_Modification.Modify_Subscription()

    elif answers["Subscription_Modification"] == 'Modify_Shared_Subscription_Data_Notification_Subscription':
        UDM.Subscriber_Data_Management.Subscription_Modification.Modify_Shared_Subscription_Data_Notification_Subscription()

def GPSI_to_SUPI_Translation():
    questions = [
        inquirer.List('GPSI_to_SUPI_Translation',
                      message="Select the GPSI_to_SUPI_Translation",
                      choices=['Retieve_SUPI'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["GPSI_to_SUPI_Translation"] == 'Retieve_SUPI':
        UDM.Subscriber_Data_Management.GPSI_to_SUPI_Translation.Retieve_SUPI()       

def Providing_acknowledgement_of_Steering_of_Roaming():
    questions = [
        inquirer.List('Providing_acknowledgement_of_Steering_of_Roaming',
                      message="Select the Providing_acknowledgement_of_Steering_of_Roaming",
                      choices=['Provide_SoR_Ack'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["Providing_acknowledgement_of_Steering_of_Roaming"] == 'Provide_SoR_Ack':
        UDM.Subscriber_Data_Management.Providing_acknowledgement_of_Steering_of_Roaming.Provide_SoR_Ack()

def Providing_acknowledgement_of_UE_Parameters_Update():
    questions = [
        inquirer.List('Providing_acknowledgement_of_UE_Parameters_Update',
                      message="Select the Providing_acknowledgement_of_UE_Parameters_Update",
                      choices=['UE_Parameter_Update_Ack'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["Providing_acknowledgement_of_UE_Parameters_Update"] == 'UE_Parameter_Update_Ack':
        UDM.Subscriber_Data_Management.Providing_acknowledgement_of_UE_Parameters_Update.UE_Parameter_Update_Ack()

def Providing_acknowledgement_of_S_NSSAIs_Update():
    questions = [
        inquirer.List('Providing_acknowledgement_of_S_NSSAIs_Update',
                      message="Select the Providing_acknowledgement_of_S_NSSAIs_Update",
                      choices=['Network_Slicing_Subscription_Change_Ack'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["Providing_acknowledgement_of_S_NSSAIs_Update"] == 'Network_Slicing_Subscription_Change_Ack':
        UDM.Subscriber_Data_Management.Providing_acknowledgement_of_S_NSSAIs_Update.Network_Slicing_Subscription_Change_Ack()

def Retrieval_of_shared_data():
    questions = [
        inquirer.List('Retrieval_of_shared_data',
                      message="Select the Retrieval_of_shared_data",
                      choices=['Retrieve_Shared_Subscription_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["Retrieval_of_shared_data"] == 'Retrieve_Shared_Subscription_Data':
        UDM.Subscriber_Data_Management.Retrieval_of_shared_data.Retrieve_Shared_Subscription_Data()


def Subscription_Creation_for_shared_data():
    questions = [
        inquirer.List('Subscription_Creation_for_shared_data',
                      message="Select the Subscription_Creation_for_shared_data",
                      choices=['Subscribe_to_Shared_Subscription_Notifications'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["Subscription_Creation_for_shared_data"] == 'Subscribe_to_Shared_Subscription_Notifications':
        UDM.Subscriber_Data_Management.Subscription_Creation_for_shared_data.Subscribe_to_Shared_Subscription_Notifications()       

def Subscription_Deletion_for_shared_data():
    questions = [
        inquirer.List('Subscription_Deletion_for_shared_data',
                      message="Select the Subscription_Deletion_for_shared_data",
                      choices=['Unsubscribe_from_Shared_Subscription_Data_Notifications'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["Subscription_Deletion_for_shared_data"] == 'Unsubscribe_from_Shared_Subscription_Data_Notifications':
        UDM.Subscriber_Data_Management.Subscription_Deletion_for_shared_data.Unsubscribe_from_Shared_Subscription_Data_Notifications()      

def Group_Identifiers():
    questions = [
        inquirer.List('Group_Identifiers',
                      message="Select the Group_Identifiers",
                      choices=['Retrieve_Group_Identifier'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscriber_Data_Management()

    elif answers["Group_Identifiers"] == 'Retrieve_Group_Identifier':
        UDM.Subscriber_Data_Management.Group_Identifiers.Retrieve_Group_Identifier()      




def UE_Context_Management():
    questions = [
        inquirer.List('UE_Context_Management',
                      message="Select the UE_Context_Management",
                      choices=['AMF_registration_for_3GPP_access', 'Parameter_update_in_the_AMF_registration_for_3GPP_access', 'AMF_3Gpp_access_Registration_Info_Retrieval', 'AMF_registration_for_non_3GPP_access','Parameter_update_in_the_AMF_registration_for_non_3GPP_access','AMF_non_3GPP_access_Registration_Info_Retrieval','SMF_Registration','SMF_Deregistration','SMSF_registration_for_3GPP_access','SMSF_Deregistration_for_3GPP_Access','SMSF_3GPP_access_Registration_Info_Retrieval','SMSF_registration_for_non_3GPP_access','SMSF_Deregistration_for_non_3GPP_access','SMSF_non_3GPP_access_Registration_Info_Retrieval'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        udm()

    elif answers["UE_Context_Management"] == 'AMF_registration_for_3GPP_access':
        AMF_registration_for_3GPP_access()

    elif answers["UE_Context_Management"] == 'Parameter_update_in_the_AMF_registration_for_3GPP_access':
        Parameter_update_in_the_AMF_registration_for_3GPP_access()

    elif answers["UE_Context_Management"] == 'AMF_3Gpp_access_Registration_Info_Retrieval':
        AMF_3Gpp_access_Registration_Info_Retrieval()

    elif answers["UE_Context_Management"] == 'AMF_registration_for_non_3GPP_access':
        AMF_registration_for_non_3GPP_access()

    elif answers["UE_Context_Management"] == 'Parameter_update_in_the_AMF_registration_for_non_3GPP_access':
        Parameter_update_in_the_AMF_registration_for_non_3GPP_access()

    elif answers["UE_Context_Management"] == 'AMF_non_3GPP_access_Registration_Info_Retrieval':
        AMF_non_3GPP_access_Registration_Info_Retrieval()

    elif answers["UE_Context_Management"] == 'SMF_Deregistration':
        SMF_Deregistration()

    elif answers["UE_Context_Management"] == 'SMF_Registration':
        SMF_Registration()

    elif answers["UE_Context_Management"] == 'SMSF_registration_for_3GPP_access':
        SMSF_registration_for_3GPP_access()

    elif answers["UE_Context_Management"] == 'SMSF_Deregistration_for_3GPP_Access':
        SMSF_Deregistration_for_3GPP_Access()

    elif answers["UE_Context_Management"] == 'SMSF_3GPP_access_Registration_Info_Retrieval':
        SMSF_3GPP_access_Registration_Info_Retrieval()

    elif answers["UE_Context_Management"] == 'SMSF_registration_for_non_3GPP_access':
        SMSF_registration_for_non_3GPP_access()

    elif answers["UE_Context_Management"] == 'SMSF_Deregistration_for_non_3GPP_access':
        SMSF_Deregistration_for_non_3GPP_access()

    elif answers["UE_Context_Management"] == 'SMSF_non_3GPP_access_Registration_Info_Retrieval':
        SMSF_non_3GPP_access_Registration_Info_Retrieval()
    
def AMF_registration_for_3GPP_access():
    questions = [
        inquirer.List('AMF_registration_for_3GPP_access',
                      message="Select the AMF_registration_for_3GPP_access",
                      choices=['Register_AMF_for_3GPP_Access'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Context_Management()

    elif answers["AMF_registration_for_3GPP_access"] == 'Register_AMF_for_3GPP_Access':
        UDM.UE_Context_Management.AMF_registration_for_3GPP_access.Register_AMF_for_3GPP_Access()


def Parameter_update_in_the_AMF_registration_for_3GPP_access():
    questions = [
        inquirer.List('Parameter_update_in_the_AMF_registration_for_3GPP_access',
                      message="Select the Parameter_update_in_the_AMF_registration_for_3GPP_access",
                      choices=['Update_UE_Parameter_3GPP_Access'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Context_Management()

    elif answers["Parameter_update_in_the_AMF_registration_for_3GPP_access"] == 'Update_UE_Parameter_3GPP_Access':
        UDM.UE_Context_Management.Parameter_update_in_the_AMF_registration_for_3GPP_access.Update_UE_Parameter_3GPP_Access()

def AMF_3Gpp_access_Registration_Info_Retrieval():
    questions = [
        inquirer.List('AMF_3Gpp_access_Registration_Info_Retrieval',
                      message="Select the AMF_3Gpp_access_Registration_Info_Retrieval",
                      choices=['Retrieve_UE_Context_3GPP_Access'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Context_Management()

    elif answers["AMF_3Gpp_access_Registration_Info_Retrieval"] == 'Retrieve_UE_Context_3GPP_Access':
        UDM.UE_Context_Management.AMF_3Gpp_access_Registration_Info_Retrieval.Retrieve_UE_Context_3GPP_Access()

def AMF_registration_for_non_3GPP_access():
    questions = [
        inquirer.List('AMF_registration_for_non_3GPP_access',
                      message="Select the AMF_registration_for_non_3GPP_access",
                      choices=['Register_AMF_for_Non_3GPP_Access'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Context_Management()

    elif answers["AMF_registration_for_non_3GPP_access"] == 'Register_AMF_for_Non_3GPP_Access':
        UDM.UE_Context_Management.AMF_registration_for_non_3GPP_access.Register_AMF_for_Non_3GPP_Access()

def Parameter_update_in_the_AMF_registration_for_non_3GPP_access():
    questions = [
        inquirer.List('Parameter_update_in_the_AMF_registration_for_non_3GPP_access',
                      message="Select the Parameter_update_in_the_AMF_registration_for_non_3GPP_access",
                      choices=['Update_Registration_Non_3GPP_Access'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Context_Management()

    elif answers["Parameter_update_in_the_AMF_registration_for_non_3GPP_access"] == 'Update_Registration_Non_3GPP_Access':
        UDM.UE_Context_Management.Parameter_update_in_the_AMF_registration_for_non_3GPP_access.Update_Registration_Non_3GPP_Access()


def AMF_non_3GPP_access_Registration_Info_Retrieval():
    questions = [
        inquirer.List('AMF_non_3GPP_access_Registration_Info_Retrieval',
                      message="Select the AMF_non_3GPP_access_Registration_Info_Retrieval",
                      choices=['Retrieve_UE_Context_Non_3GPP_Access'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Context_Management()

    elif answers["AMF_non_3GPP_access_Registration_Info_Retrieval"] == 'Retrieve_UE_Context_Non_3GPP_Access':
        UDM.UE_Context_Management.AMF_non_3GPP_access_Registration_Info_Retrieval.Retrieve_UE_Context_Non_3GPP_Access()


def SMF_Registration():
    questions = [
        inquirer.List('SMF_Registration',
                      message="Select the SMF_Registration",
                      choices=['Register_SMF'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Context_Management()

    elif answers["SMF_Registration"] == 'Register_SMF':
        UDM.UE_Context_Management.SMF_Registration.Register_SMF()


def SMF_Deregistration():
    questions = [
        inquirer.List('SMF_Deregistration',
                      message="Select the SMF_Deregistration",
                      choices=['Deregister_SMF'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Context_Management()

    elif answers["SMF_Deregistration"] == 'Deregister_SMF':
        UDM.UE_Context_Management.SMF_Deregistration.Deregister_SMF()


def SMSF_registration_for_3GPP_access():
    questions = [
        inquirer.List('SMSF_registration_for_3GPP_access',
                      message="Select the SMSF_registration_for_3GPP_access",
                      choices=['Register_SMSF_for_3GPP_Access'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Context_Management()

    elif answers["SMSF_registration_for_3GPP_access"] == 'Register_SMSF_for_3GPP_Access':
        UDM.UE_Context_Management.SMSF_registration_for_3GPP_access.Register_SMSF_for_3GPP_Access()

def SMSF_Deregistration_for_3GPP_Access():
    questions = [
        inquirer.List('SMSF_Deregistration_for_3GPP_Access',
                      message="Select the SMSF_Deregistration_for_3GPP_Access",
                      choices=['Deregiser_SMSF_3GPP_Access'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Context_Management()

    elif answers["SMSF_Deregistration_for_3GPP_Access"] == 'Deregiser_SMSF_3GPP_Access':
        UDM.UE_Context_Management.SMSF_Deregistration_for_3GPP_Access.Deregiser_SMSF_3GPP_Access()

def SMSF_3GPP_access_Registration_Info_Retrieval():
    questions = [
        inquirer.List('SMSF_3GPP_access_Registration_Info_Retrieval',
                      message="Select the SMSF_3GPP_access_Registration_Info_Retrieval",
                      choices=['Retrieve_SMSF_Registration_3GPP_Access'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Context_Management()

    elif answers["SMSF_3GPP_access_Registration_Info_Retrieval"] == 'Retrieve_SMSF_Registration_3GPP_Access':
        UDM.UE_Context_Management.SMSF_3GPP_access_Registration_Info_Retrieval.Retrieve_SMSF_Registration_3GPP_Access()

def SMSF_registration_for_non_3GPP_access():
    questions = [
        inquirer.List('SMSF_registration_for_non_3GPP_access',
                      message="Select the SMSF_registration_for_non_3GPP_access",
                      choices=['Register_SMSF_for_Non_3GPP_Access'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Context_Management()

    elif answers["SMSF_registration_for_non_3GPP_access"] == 'Register_SMSF_for_Non_3GPP_Access':
        UDM.UE_Context_Management.SMSF_registration_for_non_3GPP_access.Register_SMSF_for_Non_3GPP_Access()

def SMSF_Deregistration_for_non_3GPP_access():
    questions = [
        inquirer.List('SMSF_Deregistration_for_non_3GPP_access',
                      message="Select the SMSF_Deregistration_for_non_3GPP_access",
                      choices=['Deregiser_SMSF_Non_3GPP_Access'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Context_Management()

    elif answers["SMSF_Deregistration_for_non_3GPP_access"] == 'Deregiser_SMSF_Non_3GPP_Access':
        UDM.UE_Context_Management.SMSF_Deregistration_for_non_3GPP_access.Deregiser_SMSF_Non_3GPP_Access()


def SMSF_non_3GPP_access_Registration_Info_Retrieval():
    questions = [
        inquirer.List('SMSF_non_3GPP_access_Registration_Info_Retrieval',
                      message="Select the SMSF_non_3GPP_access_Registration_Info_Retrieval",
                      choices=['Retrieve_SMSF_Registration_Non_3GPP_Access'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Context_Management()

    elif answers["SMSF_non_3GPP_access_Registration_Info_Retrieval"] == 'Retrieve_SMSF_Registration_Non_3GPP_Access':
        UDM.UE_Context_Management.SMSF_non_3GPP_access_Registration_Info_Retrieval.Retrieve_SMSF_Registration_Non_3GPP_Access()


def UE_Authentication():
    questions = [
        inquirer.List('UE_Authentication',
                      message="Select the UE_Authentication",
                      choices=['Generate_Auth_Data', 'Confirm_Auth'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        udm()

    elif answers["UE_Authentication"] == 'Generate_Auth_Data':
        Generate_Auth_Data()

    elif answers["UE_Authentication"] == 'Confirm_Auth':
        Confirm_Auth()


def Generate_Auth_Data():
    questions = [
        inquirer.List('Generate_Auth_Data',
                      message="Select the Generate_Auth_Data",
                      choices=['Generate_Authentication_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Authentication()

    elif answers["Generate_Auth_Data"] == 'Generate_Authentication_Data':
        UDM.UE_Authentication.Generate_Auth_Data.Generate_Authentication_Data()


def Confirm_Auth():
    questions = [
        inquirer.List('Confirm_Auth',
                      message="Select the Confirm_Auth",
                      choices=['Confirm_Authentication'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Authentication()

    elif answers["Confirm_Auth"] == 'Confirm_Authentication':
        UDM.UE_Authentication.Confirm_Auth.Confirm_Authentication()


def Event_Exposure():
    questions = [
        inquirer.List('Event_Exposure',
                      message="Select the Event_Exposure",
                      choices=['Create_EE_Subscription', 'Delete_EE_Subscription','Update_EE_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        udm()

    elif answers["Event_Exposure"] == 'Create_EE_Subscription':
        Create_EE_Subscription()

    elif answers["Event_Exposure"] == 'Delete_EE_Subscription':
        Delete_EE_Subscription()

    elif answers["Event_Exposure"] == 'Update_EE_Subscription':
        Update_EE_Subscription()


def Create_EE_Subscription():
    questions = [
        inquirer.List('Create_EE_Subscription',
                      message="Select the Create_EE_Subscription",
                      choices=['Create_Event_Exposure_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Event_Exposure()

    elif answers["Create_EE_Subscription"] == 'Create_Event_Exposure_Subscription':
        UDM.Event_Exposure.Create_EE_Subscription.Create_Event_Exposure_Subscription()


def Delete_EE_Subscription():
    questions = [
        inquirer.List('Delete_EE_Subscription',
                      message="Select the Delete_EE_Subscription",
                      choices=['Delete_Event_Exposure_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Event_Exposure()

    elif answers["Delete_EE_Subscription"] == 'Delete_Event_Exposure_Subscription':
        UDM.Event_Exposure.Delete_EE_Subscription.Delete_Event_Exposure_Subscription()

def Update_EE_Subscription():
    questions = [
        inquirer.List('Update_EE_Subscription',
                      message="Select the Update_EE_Subscription",
                      choices=['Update_Event_Exposure_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Event_Exposure()

    elif answers["Update_EE_Subscription"] == 'Update_Event_Exposure_Subscription':
        UDM.Event_Exposure.Update_EE_Subscription.Update_Event_Exposure_Subscription()

def Parameter_Provisioning():
    questions = [
        inquirer.List('Parameter_Provisioning',
                      message="Select the Parameter_Provisioning",
                      choices=['Subscription_Data_Update'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        udm()

    elif answers["Parameter_Provisioning"] == 'Subscription_Data_Update':
        Subscription_Data_Update()



def Subscription_Data_Update():
    questions = [
        inquirer.List('Subscription_Data_Update',
                      message="Select the Subscription_Data_Update",
                      choices=['Update_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Parameter_Provisioning()

    elif answers["Subscription_Data_Update"] == 'Update_Subscription':
        UDM.Parameter_Provisioning.Subscription_Data_Update.Update_Subscription()


# while True:
#     fun()

#     if not cont():
#         break


