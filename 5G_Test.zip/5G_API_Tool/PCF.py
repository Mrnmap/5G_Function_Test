from pickle import GET
import pycurl
import json
from io import StringIO
from colorama import Fore
import ipaddress
import re

id_regex = re.compile(r'([A-Za-z0-9])+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+')
nf_regex = re. compile(r'[A-Za-z]+')
supiOrsuci_regex = re. compile(r'imsi-[0-9]{5,15}|nai-.+|gli-.+|gci-.+|suci-(0-[0-9]{3}-[0-9]{2,3}|[1-7]-.+)-[0-9]{1,4}-(0-0-.+|[a-fA-F1-9]-([1-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])-[a-fA-F0-9]+)|.+')
servingNetworkName_regex = re. compile(r'5G:mnc[0-9]{3}[.]mcc[0-9]{3}[.]3gppnetwork[.]org(:[A-F0-9]{11})?')
mcc_regex = re.compile(r'[0-9]{3}')
mnc_regex = re.compile(r'[0-9]{2,3}')
supi_regex = re.compile(r'[0-9]{15,16}')



class Policy_Authorization():

    class Application_Sessions_Collection():

        def Create_Application_Session_Context():
            pass


    class Individual_Application_Session_Context_Document():

        def Retrieve_Application_Session_Context():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.13)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter appSessionId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid appSessionId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/npcf-policyauthorization/v1/app-sessions/'+str(supi))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve an existing Individual Application Session Context. Direction: AF --> PCF or NEF --> PCF")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

        def Update_Application_Session_Context():
            pass

        def Delete_Application_Session_Context():
            pass 

    class Events_Subscription_Document():

        def Update_Event_Subscription():
            pass

        def Delete_Event_Subscription():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.13)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    appSessionId = input("Enter appSessionId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, appSessionId):
                        break

                    else:
                        print("Enter a Valid appSessionId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/npcf-policyauthorization/v1/app-sessions/'+str(appSessionId)+'/events-subscription')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve an existing Individual Application Session Context. Direction: AF --> PCF or NEF --> PCF")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None
            

class Access_and_Mobility_Policy_Control():

    class Default():

        def Create_Policy_Association():
            pass

        def Retrieve_Policy_Association():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.13)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    polAssoId = input("Enter polAssoId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, polAssoId):
                        break

                    else:
                        print("Enter a Valid polAssoId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/npcf-am-policy-control/v1/policies/'+str(polAssoId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve an existing Individual Application Session Context. Direction: AF --> PCF or NEF --> PCF")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


        def Update_Policy_Association():
            pass

        def Delete_Policy_Association():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.13)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    polAssoId = input("Enter polAssoId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, polAssoId):
                        break

                    else:
                        print("Enter a Valid polAssoId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/npcf-am-policy-control/v1/policies/'+str(polAssoId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve an existing Individual Application Session Context. Direction: AF --> PCF or NEF --> PCF")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

            
class Session_Management_Policy_Control():

    class Default2():

        def Create_SM_Policy():
            pass

        def Update_SM_Policy():
            pass

        def Retrieve_SM_Policy():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.13)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    smPolicyId = input("Enter smPolicyId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, smPolicyId):
                        break

                    else:
                        print("Enter a Valid smPolicyId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/npcf-smpolicycontrol/v1/sm-policies/'+str(smPolicyId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve an existing Individual Application Session Context. Direction: AF --> PCF or NEF --> PCF")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


        def Delete_SM_Policy():
            pass

class Background_Data_Transfer_Policy_Control():

    class BDT_policies_Collection():

        def Create_BDT_Policy():
            pass

    class Individual_BDT_policy_Document():

        def Retrieve_BDT_Policy():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.13)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    bdtPolicyId = input("Enter bdtPolicyId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, bdtPolicyId):
                        break

                    else:
                        print("Enter a Valid bdtPolicyId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/npcf-bdtpolicycontrol/v1/bdtpolicies/'+str(bdtPolicyId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve an existing Individual Application Session Context. Direction: AF --> PCF or NEF --> PCF")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

  
        def Update_BDT_Policy():
            pass
                      
class Policy_Control_Event_Exposure():

    class Policy_Control_Events_Subscription_Collection():

        def Create_Subscription():
            pass

    class Individual_Policy_Control_Events_Subscription_Document():

        def Retrieve_Subscription():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.13)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    subscriptionId = input("Enter subscriptionId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, subscriptionId):
                        break

                    else:
                        print("Enter a Valid subscriptionId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/npcf-eventexposure/v1/subscriptions/'+str(subscriptionId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve an existing Individual Application Session Context. Direction: AF --> PCF or NEF --> PCF")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

  
        def Modify_Subscription():
            pass

        def Delete_Subscription():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.13)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    subscriptionId = input("Enter subscriptionId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, subscriptionId):
                        break

                    else:
                        print("Enter a Valid subscriptionId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/npcf-eventexposure/v1/subscriptions/'+str(subscriptionId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve an existing Individual Application Session Context. Direction: AF --> PCF or NEF --> PCF")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None



class UE_Policy_Control():

    class UE_Policy_Associations_Collection():

        def Create_Subscription():
            pass

    class Individual_UE_Policy_Association_Document():

        def Read_Association():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.13)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    polAssoId = input("Enter polAssoId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, polAssoId):
                        break

                    else:
                        print("Enter a Valid polAssoId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/npcf-ue-policy-control/v1/policies/'+str(polAssoId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve an existing Individual Application Session Context. Direction: AF --> PCF or NEF --> PCF")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


        def Delete_Association():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.13)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    polAssoId = input("Enter polAssoId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, polAssoId):
                        break

                    else:
                        print("Enter a Valid polAssoId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/npcf-ue-policy-control/v1/policies/'+str(polAssoId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve an existing Individual Application Session Context. Direction: AF --> PCF or NEF --> PCF")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


        def Update_Association():
            pass
