from operator import concat
import inquirer
from secrets import choice
from colorama import Fore
from regex import P, T
import UDR
import API_PenTesting_Tool


# def cont():
#     questions = [
#         inquirer.List('Choice',
#                       message="Do you want continue ?",
#                       choices=['YES', 'NO'],)]
#     answers = inquirer.prompt(questions)
#     if answers['Choice'] == 'NO':
#         return False

#     return True


# def fun():
#     questions = [
#         inquirer.List('Function',
#                       message="Select the function",
#                       choices=['AUSF', 'BSF', 'NSSF', 'AMF','UDM','UDR'],), ]
#     answers = inquirer.prompt(questions)
#     print(answers)
#     if answers != None:
#         if answers["Function"] == 'UDR':
#             udr()

def udr():
    questions = [
        inquirer.List('UDR',
                      message="Select the UDR",
                      choices=['Subscription_Data', 'Policy_Data', 'Exposure_Data', 'Application_Data'],), ]
    answers = inquirer.prompt(questions)
    if answers == None:
        API_PenTesting_Tool.fun()

    if answers["UDR"] == 'Subscription_Data':
        Subscription_Data()

    if answers["UDR"] == 'Policy_Data':
        Policy_Data()

    if answers["UDR"] == 'Exposure_Data':
        Exposure_Data()

    if answers["UDR"] == 'Application_Data':
        Application_Data()


def Subscription_Data():
    questions = [
        inquirer.List('Subscription_Data',
                      message="Select the Subscription_Data",
                      choices=['Authentication_Data_Document', 'Authentication_Subscription_Document', 'Authentication_Status_Document', 'AuthEvent_Document', 'Authentication_SoR_Document', 'Authentication_UPU_Document', 'Provisioned_Data_Document ', 'Provisioned_Data_Document', 'Access_And_Mobility_Subscription_Data_Document', 'SMF_Selection_Subscription_Data_Document', 'Session_Management_Subscription_Data', 'AMF_3GPP_Access_Registration_Document', 'AMF_Non_3GPP_Access_Registration_Document', 'SMF_Registrations_Collection', 'SMF_Registration_Document', 'Operator_Specific_Data_Container_Document', 'SMSF_3GPP_Registration_Document', 'SMSF_Non_3GPP_Registration_Document', 'SMS_Management_Subscription_Data_Document', 'SMS_Subscription_Data_Document', 'Parameter_Provision_Document', 'ProvisionedParameterData_Document', 'Event_Exposure_Subscriptions_Collection', 'Event_Exposure_Subscription_Document', 'AMF_Subscription_Info_Document', 'Event_AMF_Subscription_Info_Document', 'AmfSubscriptionInfo_Document', 'Query_AMF_Subscription_Info_Document', 'Event_Exposure_Group_Subscriptions_Collection', 'Event_Exposure_Data_Document', 'SDM_Subscriptions_Collection', 'SDM_Subscription_Document', 'Retrieval_of_shared_data', 'Subs_To_Nofify_Collection', 'Subs_To_Notify_Collection', 'Subs_To_Notify_Document', 'Trace_Data_Document', 'Query_Identity_Data_by_SUPI_or_GPSI_Document', 'Query_ODB_Data_by_SUPI_or_GPSI_Document', 'Context_Data_Document', 'Group_Identifiers'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        udr()

    elif answers["Subscription_Data"] == 'Authentication_Data_Document':
        Authentication_Data_Document()

    elif answers["Subscription_Data"] == 'Authentication_Subscription_Document':
        Authentication_Subscription_Document()

    elif answers["Subscription_Data"] == 'Authentication_Status_Document':
        Authentication_Status_Document()

    elif answers["Subscription_Data"] == 'AuthEvent_Document':
        AuthEvent_Document()

    elif answers["Subscription_Data"] == 'Authentication_SoR_Document':
        Authentication_SoR_Document()

    elif answers["Subscription_Data"] == 'Authentication_UPU_Document':
        Authentication_UPU_Document()

    elif answers["Subscription_Data"] == 'Provisioned_Data_Document':
        Provisioned_Data_Document()

    elif answers["Subscription_Data"] == 'Access_And_Mobility_Subscription_Data_Document':
        Access_And_Mobility_Subscription_Data_Document()

    elif answers["Subscription_Data"] == 'SMF_Selection_Subscription_Data_Document':
        SMF_Selection_Subscription_Data_Document()

    elif answers["Subscription_Data"] == 'Session_Management_Subscription_Data':
        Session_Management_Subscription_Data()

    elif answers["Subscription_Data"] == 'AMF_3GPP_Access_Registration_Document':
        AMF_3GPP_Access_Registration_Document()

    elif answers["Subscription_Data"] == 'AMF_Non_3GPP_Access_Registration_Document':
        AMF_Non_3GPP_Access_Registration_Document()

    elif answers["Subscription_Data"] == 'SMF_Registrations_Collection':
        SMF_Registrations_Collection()

    elif answers["Subscription_Data"] == 'SMF_Registration_Document':
        SMF_Registration_Document()

    elif answers["Subscription_Data"] == 'Operator_Specific_Data_Container_Document':
        Operator_Specific_Data_Container_Document()

    elif answers["Subscription_Data"] == 'SMSF_3GPP_Registration_Document':
        SMSF_3GPP_Registration_Document()

    elif answers["Subscription_Data"] == 'SMSF_Non_3GPP_Registration_Document':
        SMSF_Non_3GPP_Registration_Document()

    elif answers["Subscription_Data"] == 'SMS_Management_Subscription_Data_Document':
        SMS_Management_Subscription_Data_Document()

    elif answers["Subscription_Data"] == 'SMS_Subscription_Data_Document':
        SMS_Subscription_Data_Document()

    elif answers["Subscription_Data"] == 'Parameter_Provision_Document':
        Parameter_Provision_Document()

    elif answers["Subscription_Data"] == 'ProvisionedParameterData_Document':
        ProvisionedParameterData_Document()

    elif answers["Subscription_Data"] == 'Event_Exposure_Subscriptions_Collection':
        Event_Exposure_Subscriptions_Collection()

    elif answers["Subscription_Data"] == 'Event_Exposure_Subscription_Document':
        Event_Exposure_Subscription_Document()

    elif answers["Subscription_Data"] == 'AMF_Subscription_Info_Document':
        AMF_Subscription_Info_Document()

    elif answers["Subscription_Data"] == 'Event_AMF_Subscription_Info_Document':
        Event_AMF_Subscription_Info_Document()

    elif answers["Subscription_Data"] == 'AmfSubscriptionInfo_Document':
        AmfSubscriptionInfo_Document()

    elif answers["Subscription_Data"] == 'Query_AMF_Subscription_Info_Document':
        Query_AMF_Subscription_Info_Document()

    elif answers["Subscription_Data"] == 'Event_Exposure_Group_Subscriptions_Collection':
        Event_Exposure_Group_Subscriptions_Collection()

    elif answers["Subscription_Data"] == 'Event_Exposure_Data_Document':
        Event_Exposure_Data_Document()

    elif answers["Subscription_Data"] == 'SDM_Subscriptions_Collection':
        SDM_Subscriptions_Collection()

    elif answers["Subscription_Data"] == 'SDM_Subscription_Document':
        SDM_Subscription_Document()

    elif answers["Subscription_Data"] == 'Retrieval_of_shared_data':
        Retrieval_of_shared_data()

    elif answers["Subscription_Data"] == 'Subs_To_Nofify_Collection':
        Subs_To_Nofify_Collection()

    elif answers["Subscription_Data"] == 'Subs_To_Notify_Collection':
        Subs_To_Notify_Collection()

    elif answers["Subscription_Data"] == 'Subs_To_Notify_Document':
        Subs_To_Notify_Document()

    elif answers["Subscription_Data"] == 'Trace_Data_Document':
        Trace_Data_Document()

    elif answers["Subscription_Data"] == 'Query_Identity_Data_by_SUPI_or_GPSI_Document':
        Query_Identity_Data_by_SUPI_or_GPSI_Document()

    elif answers["Subscription_Data"] == 'Query_ODB_Data_by_SUPI_or_GPSI_Document':
        Query_ODB_Data_by_SUPI_or_GPSI_Document()

    elif answers["Subscription_Data"] == 'Context_Data_Document':
        Context_Data_Document()

    elif answers["Subscription_Data"] == 'Group_Identifiers':
        Group_Identifiers()


def Authentication_Data_Document():
    questions = [
        inquirer.List('Authentication_Data_Document',
                      message="Select the Authentication_Data_Document",
                      choices=['Query_Authentication_Data '],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Authentication_Data_Document"] == 'Query_Authentication_Data ':
        UDR.Subscription_Data.Authentication_Data_Document.Query_Authentication_Data()


def Authentication_Subscription_Document():
    questions = [
        inquirer.List('Authentication_Subscription_Document',
                      message="Select the Authentication_Subscription_Document",
                      choices=['Modify_Authentication_Data '],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Authentication_Subscription_Document"] == 'Modify_Authentication_Data ':
        UDR.Subscription_Data.Authentication_Subscription_Document.Modify_Authentication_Data()


def Authentication_Status_Document():
    questions = [
        inquirer.List('Authentication_Status_Document',
                      message="Select the Authentication_Status_Document",
                      choices=['Create_Authentication_Status '],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Authentication_Status_Document"] == 'Create_Authentication_Status ':
        UDR.Subscription_Data.Authentication_Status_Document.Create_Authentication_Status()


def AuthEvent_Document():
    questions = [
        inquirer.List('AuthEvent_Document',
                      message="Select the AuthEvent_Document",
                      choices=['Query_Authentication_Status '],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["AuthEvent_Document"] == 'Query_Authentication_Status ':
        UDR.Subscription_Data.AuthEvent_Document.Query_Authentication_Status()


def Authentication_SoR_Document():
    questions = [
        inquirer.List('Authentication_SoR_Document',
                      message="Select the Authentication_SoR_Document",
                      choices=['Store_Authentication_SoR ', 'Query_Authentication_SoR'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Authentication_SoR_Document"] == 'Store_Authentication_SoR ':
        UDR.Subscription_Data.Authentication_SoR_Document.Store_Authentication_SoR()

    elif answers["Authentication_SoR_Document"] == 'Query_Authentication_SoR ':
        UDR.Subscription_Data.Authentication_SoR_Document.Query_Authentication_SoR()


def Authentication_UPU_Document():
    questions = [
        inquirer.List('Authentication_UPU_Document',
                      message="Select the Authentication_UPU_Document",
                      choices=['Store_UE_Parameter_Update_Data ', 'Query_UE_Parameter_Update_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Authentication_UPU_Document"] == 'Store_UE_Parameter_Update_Data ':
        UDR.Subscription_Data.Authentication_UPU_Document.Store_UE_Parameter_Update_Data()

    elif answers["Authentication_UPU_Document"] == 'Query_UE_Parameter_Update_Data ':
        UDR.Subscription_Data.Authentication_UPU_Document.Query_UE_Parameter_Update_Data()


def Provisioned_Data_Document():
    questions = [
        inquirer.List('Provisioned_Data_Document ',
                      message="Select the Provisioned_Data_Document ",
                      choices=['Retrieve_Trace_Configuration_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Provisioned_Data_Document "] == 'Retrieve_Trace_Configuration_Data':
        UDR.Subscription_Data.Provisioned_Data_Document .Retrieve_Trace_Configuration_Data()


def Provisioned_Data_Document():
    questions = [
        inquirer.List('Provisioned_Data_Document',
                      message="Select the Provisioned_Data_Document",
                      choices=['Query_Provisioned_Data '],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Provisioned_Data_Document"] == 'Query_Provisioned_Data':
        UDR.Subscription_Data.Provisioned_Data_Document.Query_Provisioned_Data()


def Access_And_Mobility_Subscription_Data_Document():
    questions = [
        inquirer.List('Access_And_Mobility_Subscription_Data_Document',
                      message="Select the Access_And_Mobility_Subscription_Data_Document",
                      choices=['Query_AM_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Access_And_Mobility_Subscription_Data_Document"] == 'Query_AM_Data':
        UDR.Subscription_Data.Access_And_Mobility_Subscription_Data_Document.Query_AM_Data()


def SMF_Selection_Subscription_Data_Document():
    questions = [
        inquirer.List('SMF_Selection_Subscription_Data_Document',
                      message="Select the SMF_Selection_Subscription_Data_Document",
                      choices=['Query_Selection_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["SMF_Selection_Subscription_Data_Document"] == 'Query_Selection_Data':
        UDR.Subscription_Data.SMF_Selection_Subscription_Data_Document.Query_Selection_Data()


def Session_Management_Subscription_Data():
    questions = [
        inquirer.List('Session_Management_Subscription_Data',
                      message="Select the Session_Management_Subscription_Data",
                      choices=['Query_SM_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Session_Management_Subscription_Data"] == 'Query_SM_Data':
        UDR.Subscription_Data.Session_Management_Subscription_Data.Query_SM_Data()


def AMF_3GPP_Access_Registration_Document():
    questions = [
        inquirer.List('AMF_3GPP_Access_Registration_Document',
                      message="Select the AMF_3GPP_Access_Registration_Document",
                      choices=['Query_AMF_Context_3GPP_Access', 'Create_AMF_Context_3GPP_Access', 'Modify_AMF_Context_3GPP_Access'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["AMF_3GPP_Access_Registration_Document"] == 'Query_AMF_Context_3GPP_Access':
        UDR.Subscription_Data.AMF_3GPP_Access_Registration_Document.Query_AMF_Context_3GPP_Access()

    elif answers["AMF_3GPP_Access_Registration_Document"] == 'Create_AMF_Context_3GPP_Access':
        UDR.Subscription_Data.AMF_3GPP_Access_Registration_Document.Create_AMF_Context_3GPP_Access()

    elif answers["AMF_3GPP_Access_Registration_Document"] == 'Modify_AMF_Context_3GPP_Access':
        UDR.Subscription_Data.AMF_3GPP_Access_Registration_Document.Modify_AMF_Context_3GPP_Access()


def AMF_Non_3GPP_Access_Registration_Document():
    questions = [
        inquirer.List('AMF_Non_3GPP_Access_Registration_Document',
                      message="Select the AMF_Non_3GPP_Access_Registration_Document",
                      choices=['Retrieve_AMF_Context_Non_3GPP_Access', 'Store_AMF_Context_Non_3GPP_Access', 'Modify_AMF_Context_Non_3GPP_Access'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["AMF_Non_3GPP_Access_Registration_Document"] == 'Retrieve_AMF_Context_Non_3GPP_Access':
        UDR.Subscription_Data.AMF_Non_3GPP_Access_Registration_Document.Retrieve_AMF_Context_Non_3GPP_Access()

    elif answers["AMF_Non_3GPP_Access_Registration_Document"] == 'Store_AMF_Context_Non_3GPP_Access':
        UDR.Subscription_Data.AMF_Non_3GPP_Access_Registration_Document.Store_AMF_Context_Non_3GPP_Access()

    elif answers["AMF_Non_3GPP_Access_Registration_Document"] == 'Modify_AMF_Context_Non_3GPP_Access':
        UDR.Subscription_Data.AMF_Non_3GPP_Access_Registration_Document.Modify_AMF_Context_Non_3GPP_Access()


def SMF_Registrations_Collection():
    questions = [
        inquirer.List('SMF_Registrations_Collection',
                      message="Select the SMF_Registrations_Collection",
                      choices=['Query_SMF_Registrations'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["SMF_Registrations_Collection"] == 'Query_SMF_Registrations':
        UDR.Subscription_Data.SMF_Registrations_Collection.Query_SMF_Registrations()


def SMF_Registration_Document():
    questions = [
        inquirer.List('SMF_Registration_Document',
                      message="Select the SMF_Registration_Document",
                      choices=['Query_SMF_Registration', 'Store_SMF_Registration', 'Delete_SMF_Registration'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["SMF_Registration_Document"] == 'Query_SMF_Registration':
        UDR.Subscription_Data.SMF_Registration_Document.Query_SMF_Registration()

    elif answers["SMF_Registration_Document"] == 'Store_SMF_Registration':
        UDR.Subscription_Data.SMF_Registration_Document.Store_SMF_Registration()

    elif answers["SMF_Registration_Document"] == 'Delete_SMF_Registration':
        UDR.Subscription_Data.SMF_Registration_Document.Delete_SMF_Registration()


def Operator_Specific_Data_Container_Document():
    questions = [
        inquirer.List('Operator_Specific_Data_Container_Document',
                      message="Select the Operator_Specific_Data_Container_Document",
                      choices=['Query_Operator_Specific_Data', 'Modify_Operator_Specific_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Operator_Specific_Data_Container_Document"] == 'Query_Operator_Specific_Data':
        UDR.Subscription_Data.Operator_Specific_Data_Container_Document.Query_Operator_Specific_Data()

    elif answers["Operator_Specific_Data_Container_Document"] == 'Modify_Operator_Specific_Data':
        UDR.Subscription_Data.Operator_Specific_Data_Container_Document.Modify_Operator_Specific_Data()


def SMSF_3GPP_Registration_Document():
    questions = [
        inquirer.List('SMSF_3GPP_Registration_Document',
                      message="Select the SMSF_3GPP_Registration_Document",
                      choices=['Store_SMSF_Registration_3GPP_Access', 'Delete_SMSF_Registration_3GPP_Access', 'Query_SMSF_Registration_3GPP_Access'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["SMSF_3GPP_Registration_Document"] == 'Store_SMSF_Registration_3GPP_Access':
        UDR.Subscription_Data.SMSF_3GPP_Registration_Document.Store_SMSF_Registration_3GPP_Access()

    elif answers["SMSF_3GPP_Registration_Document"] == 'Delete_SMSF_Registration_3GPP_Access':
        UDR.Subscription_Data.SMSF_3GPP_Registration_Document.Delete_SMSF_Registration_3GPP_Access()

    elif answers["SMSF_3GPP_Registration_Document"] == 'Query_SMSF_Registration_3GPP_Access':
        UDR.Subscription_Data.SMSF_3GPP_Registration_Document.Query_SMSF_Registration_3GPP_Access()


def SMSF_Non_3GPP_Registration_Document():
    questions = [
        inquirer.List('SMSF_Non_3GPP_Registration_Document',
                      message="Select the SMSF_Non_3GPP_Registration_Document",
                      choices=['Store_SMSF_Registration_Non_3GPP_Access', 'Delete_SMSF_Registration_Non_3GPP_Access', 'Query_SMSF_Registration_Non_3GPP_Access'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["SMSF_Non_3GPP_Registration_Document"] == 'Store_SMSF_Registration_Non_3GPP_Access':
        UDR.Subscription_Data.SMSF_Non_3GPP_Registration_Document.Store_SMSF_Registration_Non_3GPP_Access()

    elif answers["SMSF_Non_3GPP_Registration_Document"] == 'Delete_SMSF_Registration_Non_3GPP_Access':
        UDR.Subscription_Data.SMSF_Non_3GPP_Registration_Document.Delete_SMSF_Registration_Non_3GPP_Access()

    elif answers["SMSF_Non_3GPP_Registration_Document"] == 'Query_SMSF_Registration_Non_3GPP_Access':
        UDR.Subscription_Data.SMSF_Non_3GPP_Registration_Document.Query_SMSF_Registration_Non_3GPP_Access()


def SMS_Management_Subscription_Data_Document():
    questions = [
        inquirer.List('SMS_Management_Subscription_Data_Document',
                      message="Select the SMS_Management_Subscription_Data_Document",
                      choices=['Query_SMS_Management_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["SMS_Management_Subscription_Data_Document"] == 'Query_SMS_Management_Data':
        UDR.Subscription_Data.SMS_Management_Subscription_Data_Document.Query_SMS_Management_Data()


def SMS_Subscription_Data_Document():
    questions = [
        inquirer.List('SMS_Subscription_Data_Document',
                      message="Select the SMS_Subscription_Data_Document",
                      choices=['Query_SMS_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["SMS_Subscription_Data_Document"] == 'Query_SMS_Subscription':
        UDR.Subscription_Data.SMS_Subscription_Data_Document.Query_SMS_Subscription()


def Parameter_Provision_Document():
    questions = [
        inquirer.List('Parameter_Provision_Document',
                      message="Select the Parameter_Provision_Document",
                      choices=['Query_PP_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Parameter_Provision_Document"] == 'Query_PP_Data':
        UDR.Subscription_Data.Parameter_Provision_Document.Query_PP_Data()


def ProvisionedParameterData_Document():
    questions = [
        inquirer.List('ProvisionedParameterData_Document',
                      message="Select the ProvisionedParameterData_Document",
                      choices=['Modify_PP_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["ProvisionedParameterData_Document"] == 'Modify_PP_Data':
        UDR.Subscription_Data.ProvisionedParameterData_Document.Modify_PP_Data()


def Event_Exposure_Subscriptions_Collection():
    questions = [
        inquirer.List('Event_Exposure_Subscriptions_Collection',
                      message="Select the Event_Exposure_Subscriptions_Collection",
                      choices=['Query_EE_Subscription', 'Create_EE_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Event_Exposure_Subscriptions_Collection"] == 'Query_EE_Subscription':
        UDR.Subscription_Data.Event_Exposure_Subscriptions_Collection.Query_EE_Subscription()

    elif answers["Event_Exposure_Subscriptions_Collection"] == 'Create_EE_Subscription':
        UDR.Subscription_Data.Event_Exposure_Subscriptions_Collection.Create_EE_Subscription()


def Event_Exposure_Subscription_Document():
    questions = [
        inquirer.List('Event_Exposure_Subscription_Document',
                      message="Select the Event_Exposure_Subscription_Document",
                      choices=['Update_EE_Subscription(PUT)', 'Remove_EE_Subscription', 'Update_EE_Subscription(PATCH)', 'Update_EE_Group_Subscription(PUT)', 'Remove_EE_Group_Subscriptions', 'Update_EE_Group_Subscription(PATCH)'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Event_Exposure_Subscription_Document"] == 'Update_EE_Subscription(PUT)':
        UDR.Subscription_Data.Event_Exposure_Subscription_Document.Update_EE_Subscription_Put()

    elif answers["Event_Exposure_Subscription_Document"] == 'Remove_EE_Subscription':
        UDR.Subscription_Data.Event_Exposure_Subscription_Document.Remove_EE_Subscription()

    elif answers["Event_Exposure_Subscription_Document"] == 'Update_EE_Subscription(PATCH)':
        UDR.Subscription_Data.Event_Exposure_Subscription_Document.Update_EE_Subscription_Patch()

    elif answers["Event_Exposure_Subscription_Document"] == 'Update_EE_Group_Subscription(PUT)':
        UDR.Subscription_Data.Event_Exposure_Subscription_Document.Update_EE_Group_Subscription_Put()

    elif answers["Event_Exposure_Subscription_Document"] == 'Remove_EE_Group_Subscriptions':
        UDR.Subscription_Data.Event_Exposure_Subscription_Document.Remove_EE_Group_Subscriptions()

    elif answers["Event_Exposure_Subscription_Document"] == 'Update_EE_Group_Subscription(PATCH)':
        UDR.Subscription_Data.Event_Exposure_Subscription_Document.Update_EE_Group_Subscription_Patch()


def AMF_Subscription_Info_Document():
    questions = [
        inquirer.List('AMF_Subscription_Info_Document',
                      message="Select the AMF_Subscription_Info_Document",
                      choices=['Store_AMF_EE_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["AMF_Subscription_Info_Document"] == 'Store_AMF_EE_Subscription':
        UDR.Subscription_Data.AMF_Subscription_Info_Document.Store_AMF_EE_Subscription()


def Event_AMF_Subscription_Info_Document():
    questions = [
        inquirer.List('Event_AMF_Subscription_Info_Document',
                      message="Select the Event_AMF_Subscription_Info_Document",
                      choices=['Remove_AMF_EE_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Event_AMF_Subscription_Info_Document"] == 'Remove_AMF_EE_Subscription':
        UDR.Subscription_Data.Event_AMF_Subscription_Info_Document.Remove_AMF_EE_Subscription()


def AmfSubscriptionInfo_Document():
    questions = [
        inquirer.List('AmfSubscriptionInfo_Document',
                      message="Select the AmfSubscriptionInfo_Document",
                      choices=['Modify_AMF_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["AmfSubscriptionInfo_Document"] == 'Modify_AMF_Subscription':
        UDR.Subscription_Data.AmfSubscriptionInfo_Document.Modify_AMF_Subscription()


def Query_AMF_Subscription_Info_Document():
    questions = [
        inquirer.List('Query_AMF_Subscription_Info_Document',
                      message="Select the Query_AMF_Subscription_Info_Document",
                      choices=['Query_AMF_Subscription_Info'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Query_AMF_Subscription_Info_Document"] == 'Query_AMF_Subscription_Info':
        UDR.Subscription_Data.Query_AMF_Subscription_Info_Document.Query_AMF_Subscription_Info()


def Event_Exposure_Group_Subscriptions_Collection():
    questions = [
        inquirer.List('Event_Exposure_Group_Subscriptions_Collection',
                      message="Select the Event_Exposure_Group_Subscriptions_Collection",
                      choices=['Query_EE_Group_Subscriptions', 'Create_EE_Group_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Event_Exposure_Group_Subscriptions_Collection"] == 'Query_EE_Group_Subscriptions':
        UDR.Subscription_Data.Event_Exposure_Group_Subscriptions_Collection.Query_EE_Group_Subscriptions()

    elif answers["Event_Exposure_Group_Subscriptions_Collection"] == 'Create_EE_Group_Subscription':
        UDR.Subscription_Data.Event_Exposure_Group_Subscriptions_Collection.Create_EE_Group_Subscription()


def Event_Exposure_Data_Document():
    questions = [
        inquirer.List('Event_Exposure_Data_Document',
                      message="Select the Event_Exposure_Data_Document",
                      choices=['Query_EE_Profile'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Event_Exposure_Data_Document"] == 'Query_EE_Profile':
        UDR.Subscription_Data.Event_Exposure_Data_Document.Query_EE_Profile()


def SDM_Subscriptions_Collection():
    questions = [
        inquirer.List('SDM_Subscriptions_Collection',
                      message="Select the SDM_Subscriptions_Collection",
                      choices=['Query_SDM_Subscription', 'Create_SDM_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["SDM_Subscriptions_Collection"] == 'Query_SDM_Subscription':
        UDR.Subscription_Data.SDM_Subscriptions_Collection.Query_SDM_Subscription()

    elif answers["SDM_Subscriptions_Collection"] == 'Create_SDM_Subscription':
        UDR.Subscription_Data.SDM_Subscriptions_Collection.Create_SDM_Subscription()


def SDM_Subscription_Document():
    questions = [
        inquirer.List('SDM_Subscription_Document',
                      message="Select the SDM_Subscription_Document",
                      choices=['Update_SDM_Subscription', 'Remove_SDM_Subscription', 'Modify_SDM_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["SDM_Subscription_Document"] == 'Update_SDM_Subscription':
        UDR.Subscription_Data.SDM_Subscription_Document.Update_SDM_Subscription()

    elif answers["SDM_Subscription_Document"] == 'Remove_SDM_Subscription':
        UDR.Subscription_Data.SDM_Subscription_Document.Remove_SDM_Subscription()

    elif answers["SDM_Subscription_Document"] == 'Modify_SDM_Subscription':
        UDR.Subscription_Data.SDM_Subscription_Document.Modify_SDM_Subscription()


def Retrieval_of_shared_data():
    questions = [
        inquirer.List('Retrieval_of_shared_data',
                      message="Select the Retrieval_of_shared_data",
                      choices=['Query_Shared_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Retrieval_of_shared_data"] == 'Query_Shared_Data':
        UDR.Subscription_Data.Retrieval_of_shared_data.Query_Shared_Data()


def Subs_To_Nofify_Collection():
    questions = [
        inquirer.List('Subs_To_Nofify_Collection',
                      message="Select the Subs_To_Nofify_Collection",
                      choices=['Subscribe_for_Subscription_Data_Notifications', 'Query_Subscription_Data_Notification_Subscriptions'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Subs_To_Nofify_Collection"] == 'Subscribe_for_Subscription_Data_Notifications':
        UDR.Subscription_Data.Subs_To_Nofify_Collection.Subscribe_for_Subscription_Data_Notifications()

    elif answers["Subs_To_Nofify_Collection"] == 'Query_Subscription_Data_Notification_Subscriptions':
        UDR.Subscription_Data.Subs_To_Nofify_Collection.Query_Subscription_Data_Notification_Subscriptions()


def Subs_To_Notify_Collection():
    questions = [
        inquirer.List('Subs_To_Notify_Collection',
                      message="Select the Subs_To_Notify_Collection",
                      choices=['Delete_Subscription_Data_Notification_Subscriptions'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Subs_To_Notify_Collection"] == 'Delete_Subscription_Data_Notification_Subscriptions':
        UDR.Subscription_Data.Subs_To_Notify_Collection.Delete_Subscription_Data_Notification_Subscriptions()


def Subs_To_Notify_Document():
    questions = [
        inquirer.List('Subs_To_Notify_Document',
                      message="Select the Subs_To_Notify_Document",
                      choices=['Delete_a_Subscription_Data_Notification_Subscription', 'Modify_a_Subscription_Data_Notification_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Subs_To_Notify_Document"] == 'Delete_a_Subscription_Data_Notification_Subscription':
        UDR.Subscription_Data.Subs_To_Notify_Document.Delete_a_Subscription_Data_Notification_Subscription()

    elif answers["Subs_To_Notify_Document"] == 'Modify_a_Subscription_Data_Notification_Subscription':
        UDR.Subscription_Data.Subs_To_Notify_Document.Modify_a_Subscription_Data_Notification_Subscription()


def Trace_Data_Document():
    questions = [
        inquirer.List('Trace_Data_Document',
                      message="Select the Trace_Data_Document",
                      choices=['Query_Trace_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Trace_Data_Document"] == 'Query_Trace_Data':
        UDR.Subscription_Data.Trace_Data_Document.Query_Trace_Data()


def Query_Identity_Data_by_SUPI_or_GPSI_Document():
    questions = [
        inquirer.List('Query_Identity_Data_by_SUPI_or_GPSI_Document',
                      message="Select the Query_Identity_Data_by_SUPI_or_GPSI_Document",
                      choices=['Query_Identity_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Query_Identity_Data_by_SUPI_or_GPSI_Document"] == 'Query_Identity_Data':
        UDR.Subscription_Data.Query_Identity_Data_by_SUPI_or_GPSI_Document.Query_Identity_Data()


def Query_ODB_Data_by_SUPI_or_GPSI_Document():
    questions = [
        inquirer.List('Query_ODB_Data_by_SUPI_or_GPSI_Document',
                      message="Select the Query_ODB_Data_by_SUPI_or_GPSI_Document",
                      choices=['Query_ODB_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Query_ODB_Data_by_SUPI_or_GPSI_Document"] == 'Query_ODB_Data':
        UDR.Subscription_Data.Query_ODB_Data_by_SUPI_or_GPSI_Document.Query_ODB_Data()


def Context_Data_Document():
    questions = [
        inquirer.List('Context_Data_Document',
                      message="Select the Context_Data_Document",
                      choices=['Query_Context_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Context_Data_Document"] == 'Query_Context_Data':
        UDR.Subscription_Data.Context_Data_Document.Query_Context_Data()


def Group_Identifiers():
    questions = [
        inquirer.List('Group_Identifiers',
                      message="Select the Group_Identifiers",
                      choices=['Query_Group_Identifiers'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Subscription_Data()

    elif answers["Group_Identifiers"] == 'Query_Group_Identifiers':
        UDR.Subscription_Data.Group_Identifiers.Query_Group_Identifiers()


def Policy_Data():
    questions = [
        inquirer.List('Policy_Data',
                      message="Select the Policy_Data",
                      choices=['Access_And_Mobility_Policy_Data_Document', 'UE_Policy_Set_Document', 'Session_Management_Policy_Data_Document', 'Usage_Monitoring_Information_Document', 'Sponsor_Connectivity_Data_Document', 'BDT_Data_Store', 'Policy_Data_Subscriptions_Collection', 'Individual_BDT_Data_Document', 'Individual_Policy_Data_Subscription_Document', 'Operator_Specific_Data_Document', 'PLMN_UE_Policy_Set_Document'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        udr()

    elif answers["Policy_Data"] == 'Access_And_Mobility_Policy_Data_Document':
        Access_And_Mobility_Policy_Data_Document()

    elif answers["Policy_Data"] == 'UE_Policy_Set_Document':
        UE_Policy_Set_Document()

    elif answers["Policy_Data"] == 'Session_Management_Policy_Data_Document':
        Session_Management_Policy_Data_Document()

    elif answers["Policy_Data"] == 'Usage_Monitoring_Information_Document':
        Usage_Monitoring_Information_Document()

    elif answers["Policy_Data"] == 'Sponsor_Connectivity_Data_Document':
        Sponsor_Connectivity_Data_Document()

    elif answers["Policy_Data"] == 'BDT_Data_Store':
        BDT_Data_Store()

    elif answers["Policy_Data"] == 'Individual_BDT_Data_Document':
        Individual_BDT_Data_Document()

    elif answers["Policy_Data"] == 'Individual_Policy_Data_Subscription_Document':
        Individual_Policy_Data_Subscription_Document()

    elif answers["Policy_Data"] == 'Operator_Specific_Data_Document':
        Operator_Specific_Data_Document()

    elif answers["Policy_Data"] == 'PLMN_UE_Policy_Set_Document':
        PLMN_UE_Policy_Set_Document()

    elif answers["Policy_Data"] == 'Policy_Data_Subscriptions_Collection':
        Policy_Data_Subscriptions_Collection()


def Access_And_Mobility_Policy_Data_Document():
    questions = [
        inquirer.List('Access_And_Mobility_Policy_Data_Document',
                      message="Select the Access_And_Mobility_Policy_Data_Document",
                      choices=['Retrieve_Access_and_Mobility_Policy'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Policy_Data()

    elif answers["Access_And_Mobility_Policy_Data_Document"] == 'Retrieve_Access_and_Mobility_Policy':
        UDR.Policy_Data.Access_And_Mobility_Policy_Data_Document.Retrieve_Access_and_Mobility_Policy()


def UE_Policy_Set_Document():
    questions = [
        inquirer.List('UE_Policy_Set_Document',
                      message="Select the UE_Policy_Set_Document",
                      choices=['Retrieve_UE_Policy_Set', 'Store_UE_Policy_Set_Data', 'Modify_UE_Policy_Set_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Policy_Data()

    elif answers["UE_Policy_Set_Document"] == 'Retrieve_UE_Policy_Set':
        UDR.Policy_Data.UE_Policy_Set_Document.Retrieve_UE_Policy_Set()

    elif answers["UE_Policy_Set_Document"] == 'Store_UE_Policy_Set_Data':
        UDR.Policy_Data.UE_Policy_Set_Document.Store_UE_Policy_Set_Data()

    elif answers["UE_Policy_Set_Document"] == 'Modify_UE_Policy_Set_Data':
        UDR.Policy_Data.UE_Policy_Set_Document.Modify_UE_Policy_Set_Data()


def Session_Management_Policy_Data_Document():
    questions = [
        inquirer.List('Session_Management_Policy_Data_Document',
                      message="Select the Session_Management_Policy_Data_Document",
                      choices=['Retrieve_Session_Management_Policy_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Policy_Data()

    elif answers["Session_Management_Policy_Data_Document"] == 'Retrieve_Session_Management_Policy_Data':
        UDR.Policy_Data.Session_Management_Policy_Data_Document.Retrieve_Session_Management_Policy_Data()


def Usage_Monitoring_Information_Document():
    questions = [
        inquirer.List('Usage_Monitoring_Information_Document',
                      message="Select the Usage_Monitoring_Information_Document",
                      choices=['Retrieve_Usage_Monitoring_Data', 'Store_Usage_Monitoring_Data', 'Delete_Usage_Monitoring_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Policy_Data()

    elif answers["Usage_Monitoring_Information_Document"] == 'Retrieve_Usage_Monitoring_Data':
        UDR.Policy_Data.Usage_Monitoring_Information_Document.Retrieve_Usage_Monitoring_Data()

    elif answers["Usage_Monitoring_Information_Document"] == 'Store_Usage_Monitoring_Data':
        UDR.Policy_Data.Usage_Monitoring_Information_Document.Store_Usage_Monitoring_Data()

    elif answers["Usage_Monitoring_Information_Document"] == 'Delete_Usage_Monitoring_Data':
        UDR.Policy_Data.Usage_Monitoring_Information_Document.Delete_Usage_Monitoring_Data()


def Sponsor_Connectivity_Data_Document():
    questions = [
        inquirer.List('Sponsor_Connectivity_Data_Document',
                      message="Select the Sponsor_Connectivity_Data_Document",
                      choices=['Retrieve_Sponsored_Connectivity_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Policy_Data()

    elif answers["Sponsor_Connectivity_Data_Document"] == 'Retrieve_Sponsored_Connectivity_Data':
        UDR.Policy_Data.Sponsor_Connectivity_Data_Document.Retrieve_Sponsored_Connectivity_Data()


def BDT_Data_Store():
    questions = [
        inquirer.List('BDT_Data_Store',
                      message="Select the BDT_Data_Store",
                      choices=['Retrieve_BDT_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Policy_Data()

    elif answers["BDT_Data_Store"] == 'Retrieve_BDT_Data':
        UDR.Policy_Data.BDT_Data_Store.Retrieve_BDT_Data()


def Policy_Data_Subscriptions_Collection():
    questions = [
        inquirer.List('Policy_Data_Subscriptions_Collection',
                      message="Select the Policy_Data_Subscriptions_Collection",
                      choices=['Create_Policy_Data_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Policy_Data()

    elif answers["Policy_Data_Subscriptions_Collection"] == 'Create_Policy_Data_Subscription':
        UDR.Policy_Data.Policy_Data_Subscriptions_Collection.Create_Policy_Data_Subscription()


def Individual_BDT_Data_Document():
    questions = [
        inquirer.List('Individual_BDT_Data_Document',
                      message="Select the Individual_BDT_Data_Document",
                      choices=['Retrieve_BDT_Policy', 'Create_BDT_Data_Resource', 'Delete_BDT_Data_Resource'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Policy_Data()

    elif answers["Individual_BDT_Data_Document"] == 'Retrieve_BDT_Policy':
        UDR.Policy_Data.Individual_BDT_Data_Document.Retrieve_BDT_Policy()

    elif answers["Individual_BDT_Data_Document"] == 'Create_BDT_Data_Resource':
        UDR.Policy_Data.Individual_BDT_Data_Document.Create_BDT_Data_Resource()

    elif answers["Individual_BDT_Data_Document"] == 'Delete_BDT_Data_Resource':
        UDR.Policy_Data.Individual_BDT_Data_Document.Delete_BDT_Data_Resource()


def Individual_Policy_Data_Subscription_Document():
    questions = [
        inquirer.List('Individual_Policy_Data_Subscription_Document',
                      message="Select the Individual_Policy_Data_Subscription_Document",
                      choices=['Replace_Policy_Data_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Policy_Data()

    elif answers["Individual_Policy_Data_Subscription_Document"] == 'Replace_Policy_Data_Subscription':
        UDR.Policy_Data.Individual_Policy_Data_Subscription_Document.Replace_Policy_Data_Subscription()


def Operator_Specific_Data_Document():
    questions = [
        inquirer.List('Operator_Specific_Data_Document',
                      message="Select the Operator_Specific_Data_Document",
                      choices=['Retrieve_Operator_Specific_Data', 'Modify_Operator_Specific_Policy_Data', 'Store_Operator_Specific_Policy_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Policy_Data()

    elif answers["Operator_Specific_Data_Document"] == 'Retrieve_Operator_Specific_Data':
        UDR.Policy_Data.Operator_Specific_Data_Document.Retrieve_Operator_Specific_Data()

    elif answers["Operator_Specific_Data_Document"] == 'Modify_Operator_Specific_Policy_Data':
        UDR.Policy_Data.Operator_Specific_Data_Document.Modify_Operator_Specific_Policy_Data()

    elif answers["Operator_Specific_Data_Document"] == 'Store_Operator_Specific_Policy_Data':
        UDR.Policy_Data.Operator_Specific_Data_Document.Store_Operator_Specific_Policy_Data()


def PLMN_UE_Policy_Set_Document():
    questions = [
        inquirer.List('PLMN_UE_Policy_Set_Document',
                      message="Select the PLMN_UE_Policy_Set_Document",
                      choices=['Retrieve_UE_Policy_Set'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Policy_Data()

    elif answers["PLMN_UE_Policy_Set_Document"] == 'Retrieve_UE_Policy_Set':
        UDR.Policy_Data.PLMN_UE_Policy_Set_Document.Retrieve_UE_Policy_Set()


def Exposure_Data():
    questions = [
        inquirer.List('Exposure_Data',
                      message="Select the Exposure_Data",
                      choices=['Access_And_Mobility_Data', 'PDU_Session_Management_Data', 'Exposure_Data_Subscriptions_Collection', 'Individual_Exposure_Data_Subscription_Document'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        udr()

    elif answers["Exposure_Data"] == 'Access_And_Mobility_Data':
        Access_And_Mobility_Data()

    elif answers["Exposure_Data"] == 'PDU_Session_Management_Data':
        PDU_Session_Management_Data()

    elif answers["Exposure_Data"] == 'Exposure_Data_Subscriptions_Collection':
        Exposure_Data_Subscriptions_Collection()

    elif answers["Exposure_Data"] == 'Individual_Exposure_Data_Subscription_Document':
        Individual_Exposure_Data_Subscription_Document()


def Access_And_Mobility_Data():
    questions = [
        inquirer.List('Access_And_Mobility_Data',
                      message="Select the Access_And_Mobility_Data",
                      choices=['Store_Access_And_Mobility_Data', 'Retrieve_Access_And_Mobility_Data', 'Delete_Access_And_Mobility_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Exposure_Data()

    elif answers["Access_And_Mobility_Data"] == 'Store_Access_And_Mobility_Data':
        UDR.Exposure_Data.Access_And_Mobility_Data.Store_Access_And_Mobility_Data()

    elif answers["Access_And_Mobility_Data"] == 'Retrieve_Access_And_Mobility_Data':
        UDR.Exposure_Data.Access_And_Mobility_Data.Retrieve_Access_And_Mobility_Data()

    elif answers["Access_And_Mobility_Data"] == 'Delete_Access_And_Mobility_Data':
        UDR.Exposure_Data.Access_And_Mobility_Data.Delete_Access_And_Mobility_Data()


def PDU_Session_Management_Data():
    questions = [
        inquirer.List('PDU_Session_Management_Data',
                      message="Select the PDU_Session_Management_Data",
                      choices=['Store_Session_Management_Data', 'Retrieve_Session_Management_Data', 'Delete_Session_Management_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Exposure_Data()

    elif answers["PDU_Session_Management_Data"] == 'Store_Session_Management_Data':
        UDR.Exposure_Data.PDU_Session_Management_Data.Store_Session_Management_Data()

    elif answers["PDU_Session_Management_Data"] == 'Retrieve_Session_Management_Data':
        UDR.Exposure_Data.PDU_Session_Management_Data.Retrieve_Session_Management_Data()

    elif answers["PDU_Session_Management_Data"] == 'Delete_Session_Management_Data':
        UDR.Exposure_Data.PDU_Session_Management_Data.Delete_Session_Management_Data()


def Exposure_Data_Subscriptions_Collection():
    questions = [
        inquirer.List('Exposure_Data_Subscriptions_Collection',
                      message="Select the Exposure_Data_Subscriptions_Collection",
                      choices=['Create_Exposure_Data_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Exposure_Data()

    elif answers["Exposure_Data_Subscriptions_Collection"] == 'Create_Exposure_Data_Subscription':
        UDR.Exposure_Data.Exposure_Data_Subscriptions_Collection.Create_Exposure_Data_Subscription()


def Individual_Exposure_Data_Subscription_Document():
    questions = [
        inquirer.List('Individual_Exposure_Data_Subscription_Document',
                      message="Select the Individual_Exposure_Data_Subscription_Document",
                      choices=['Modify_Exposure_Data_Subscription', 'Delete_Exposure_Data_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Exposure_Data()

    elif answers["Individual_Exposure_Data_Subscription_Document"] == 'Modify_Exposure_Data_Subscription':
        UDR.Exposure_Data.Individual_Exposure_Data_Subscription_Document.Modify_Exposure_Data_Subscription()

    elif answers["Individual_Exposure_Data_Subscription_Document"] == 'Delete_Exposure_Data_Subscription':
        UDR.Exposure_Data.Individual_Exposure_Data_Subscription_Document.Delete_Exposure_Data_Subscription()


def Application_Data():
    questions = [
        inquirer.List('Application_Data',
                      message="Select the Application_Data",
                      choices=['PFD_Data_Store', 'Individual_PFD_Data_Document', 'Influence_Data_Store', 'Individual_Influence_Data_Document', 'Influence_Data_Subscriptions_Collection', 'Individual_Influence_Data_Subscription_Document'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        udr()

    elif answers["Application_Data"] == 'PFD_Data_Store':
        PFD_Data_Store()

    elif answers["Application_Data"] == 'Individual_PFD_Data_Document':
        Individual_PFD_Data_Document()

    elif answers["Application_Data"] == 'Influence_Data_Store':
        Influence_Data_Store()

    elif answers["Application_Data"] == 'Individual_Influence_Data_Document':
        Individual_Influence_Data_Document()

    elif answers["Application_Data"] == 'Influence_Data_Subscriptions_Collection':
        Influence_Data_Subscriptions_Collection()

    elif answers["Application_Data"] == 'Individual_Influence_Data_Subscription_Document':
        Individual_Influence_Data_Subscription_Document()


def PFD_Data_Store():
    questions = [
        inquirer.List('PFD_Data_Store',
                      message="Select the PFD_Data_Store",
                      choices=['Retrieve_ALL_PFDs'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Application_Data()

    elif answers["PFD_Data_Store"] == 'Retrieve_ALL_PFDs':
        UDR.Application_Data.PFD_Data_Store.Retrieve_ALL_PFDs()


def Individual_PFD_Data_Document():
    questions = [
        inquirer.List('Individual_PFD_Data_Document',
                      message="Select the Individual_PFD_Data_Document",
                      choices=['Retrieve_a_PFD', 'Delete_PFD_Data', 'Store_PFD_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Application_Data()

    elif answers["Individual_PFD_Data_Document"] == 'Retrieve_a_PFD':
        UDR.Application_Data.Individual_PFD_Data_Document.Retrieve_a_PFD()

    elif answers["Individual_PFD_Data_Document"] == 'Delete_PFD_Data':
        UDR.Application_Data.Individual_PFD_Data_Document.Delete_PFD_Data()

    elif answers["Individual_PFD_Data_Document"] == 'Store_PFD_Data':
        UDR.Application_Data.Individual_PFD_Data_Document.Store_PFD_Data()


def Influence_Data_Store():
    questions = [
        inquirer.List('Influence_Data_Store',
                      message="Select the Influence_Data_Store",
                      choices=['Retreive_Influence_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Application_Data()

    elif answers["Influence_Data_Store"] == 'Retreive_Influence_Data':
        UDR.Application_Data.Influence_Data_Store.Retreive_Influence_Data()


def Individual_Influence_Data_Document():
    questions = [
        inquirer.List('Individual_Influence_Data_Document',
                      message="Select the Individual_Influence_Data_Document",
                      choices=['Store_Influence_Data', 'Modify_Influence_Data', 'Delete_Influence_Data'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Application_Data()

    elif answers["Individual_Influence_Data_Document"] == 'Store_Influence_Data':
        UDR.Application_Data.Individual_Influence_Data_Document.Store_Influence_Data()

    elif answers["Individual_Influence_Data_Document"] == 'Modify_Influence_Data':
        UDR.Application_Data.Individual_Influence_Data_Document.Modify_Influence_Data()

    elif answers["Individual_Influence_Data_Document"] == 'Delete_Influence_Data':
        UDR.Application_Data.Individual_Influence_Data_Document.Delete_Influence_Data()


def Influence_Data_Subscriptions_Collection():
    questions = [
        inquirer.List('Influence_Data_Subscriptions_Collection',
                      message="Select the Influence_Data_Subscriptions_Collection",
                      choices=['Create_Influence_Data_Subscription', 'Retrieve_Influence_Data_Subscriptions'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Application_Data()

    elif answers["Influence_Data_Subscriptions_Collection"] == 'Create_Influence_Data_Subscription':
        UDR.Application_Data.Influence_Data_Subscriptions_Collection.Create_Influence_Data_Subscription()

    elif answers["Influence_Data_Subscriptions_Collection"] == 'Retrieve_Influence_Data_Subscriptions':
        UDR.Application_Data.Influence_Data_Subscriptions_Collection.Retrieve_Influence_Data_Subscriptions()


def Individual_Influence_Data_Subscription_Document():
    questions = [
        inquirer.List('Individual_Influence_Data_Subscription_Document',
                      message="Select the Individual_Influence_Data_Subscription_Document",
                      choices=['Retrieve_Influence_Data_Subscription', 'Modify_Influence_Data_Subscription', 'Delete_Influence_Data_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Application_Data()

    elif answers["Individual_Influence_Data_Subscription_Document"] == 'Retrieve_Influence_Data_Subscription':
        UDR.Application_Data.Individual_Influence_Data_Subscription_Document.Retrieve_Influence_Data_Subscription()

    elif answers["Individual_Influence_Data_Subscription_Document"] == 'Modify_Influence_Data_Subscription':
        UDR.Application_Data.Individual_Influence_Data_Subscription_Document.Modify_Influence_Data_Subscription()

    elif answers["Individual_Influence_Data_Subscription_Document"] == 'Delete_Influence_Data_Subscription':
        UDR.Application_Data.Individual_Influence_Data_Subscription_Document.Delete_Influence_Data_Subscription()


# while True:
#     fun()

#     if not cont():
#         break
