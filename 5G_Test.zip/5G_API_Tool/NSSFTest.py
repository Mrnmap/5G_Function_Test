from operator import concat
import inquirer
from secrets import choice
from colorama import Fore
from regex import P, T
import NSSF
import API_PenTesting_Tool


# def cont():
#     questions = [
#         inquirer.List('Choice',
#                       message="Do you want continue ?",
#                       choices=['YES', 'NO'],)]
#     answers = inquirer.prompt(questions)
#     if answers['Choice'] == 'NO':
#         return False

#     return True


# def fun():
#     questions = [
#         inquirer.List('Function',
#                       message="Select the function",
#                       choices=['AUSF', 'BSF', 'AMF', 'NSSF', 'AMF','NSSF'],), ]
#     answers = inquirer.prompt(questions)
#     print(answers)
#     if answers != None:
#         if answers["Function"] == 'NSSF':
#             nssf()

def nssf():
    questions = [
        inquirer.List('NSSF',
                      message="Select the NSSF",
                      choices=['NSSAI_Availability','NS_Selection'],), ]
    answers = inquirer.prompt(questions)
    if answers == None:
        API_PenTesting_Tool.fun()

    if answers["NSSF"] == 'NSSAI_Availability':
        NSSAI_Availability()

    if answers["NSSF"] == 'NS_Selection':
        NS_Selection()


def NSSAI_Availability():
    questions = [
        inquirer.List('NSSAI_Availability',
                      message="Select the NSSAI_Availability",
                      choices=['NF_Instance_ID_Document','Subscriptions_Collection','Subscription_ID_Document','NSSAI_Availability_Store'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        nssf()

    elif answers["NSSAI_Availability"] == 'NF_Instance_ID_Document':
        NF_Instance_ID_Document()

    elif answers["NSSAI_Availability"] == 'Subscriptions_Collection':
        Subscriptions_Collection()

    elif answers["NSSAI_Availability"] == 'Subscription_ID_Document':
        Subscription_ID_Document()

    elif answers["NSSAI_Availability"] == 'NSSAI_Availability_Store':
        NSSAI_Availability_Store()

def NF_Instance_ID_Document():
    questions = [
        inquirer.List('NF_Instance_ID_Document',
                      message="Select the NF_Instance_ID_Document",
                      choices=['Update_Network_Slice_Selection_Assistance_Information','Update_NSSAI_Availability','Delete_NSSAI_Availability'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        NSSAI_Availability()

    elif answers["NF_Instance_ID_Document"] == 'Update_Network_Slice_Selection_Assistance_Information':
        NSSF.NSSAI_Availability.NF_Instance_ID_Document.Update_Network_Slice_Selection_Assistance_Information()

    elif answers["NF_Instance_ID_Document"] == 'Update_NSSAI_Availability':
        NSSF.NSSAI_Availability.NF_Instance_ID_Document.Update_NSSAI_Availability()

    elif answers["NF_Instance_ID_Document"] == 'Delete_NSSAI_Availability':
        NSSF.NSSAI_Availability.NF_Instance_ID_Document.Delete_NSSAI_Availability()

def Subscriptions_Collection():
    questions = [
        inquirer.List('Subscriptions_Collection',
                      message="Select the Subscriptions_Collection",
                      choices=['Create_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        NSSAI_Availability()

    elif answers["Subscriptions_Collection"] == 'Create_Subscription':
        NSSF.NSSAI_Availability.Subscriptions_Collection.Create_Subscription()


def Subscription_ID_Document():
    questions = [
        inquirer.List('Subscription_ID_Document',
                      message="Select the Subscription_ID_Document",
                      choices=['Delete_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        NSSAI_Availability()

    elif answers["Subscription_ID_Document"] == 'Delete_Subscription':
        NSSF.NSSAI_Availability.Subscription_ID_Document.Delete_Subscription()

def NSSAI_Availability_Store():
    questions = [
        inquirer.List('NSSAI_Availability_Store',
                      message="Select the NSSAI_Availability_Store",
                      choices=['Discover_Communication_Options'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        NSSAI_Availability()

    elif answers["NSSAI_Availability_Store"] == 'Discover_Communication_Options':
        NSSF.NSSAI_Availability.NSSAI_Availability_Store.Discover_Communication_Options()


def NS_Selection():
    questions = [
        inquirer.List('NS_Selection',
                      message="Select the NS_Selection",
                      choices=['Network_Slice_Information_Document'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        nssf()

    elif answers["NS_Selection"] == 'Network_Slice_Information_Document':
        Network_Slice_Information_Document()



def Network_Slice_Information_Document():
    questions = [
        inquirer.List('Network_Slice_Information_Document',
                      message="Select the Network_Slice_Information_Document",
                      choices=['Retrieve_Network_Slice_Information'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        NS_Selection()

    elif answers["Network_Slice_Information_Document"] == 'Retrieve_Network_Slice_Information':
        NSSF.NS_Selection.Network_Slice_Information_Document.Retrieve_Network_Slice_Information()



# while True:
#     fun()

#     if not cont():
#         break


