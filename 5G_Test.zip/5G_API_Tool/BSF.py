
import pycurl
import json
from io import StringIO
from colorama import Fore
import ipaddress
import re


id_regex = re.compile(r'([A-Za-z0-9])+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+')
nf_regex = re. compile(r'[A-Za-z]+')
supiOrsuci_regex = re. compile(r'imsi-[0-9]{5,15}|nai-.+|gli-.+|gci-.+|suci-(0-[0-9]{3}-[0-9]{2,3}|[1-7]-.+)-[0-9]{1,4}-(0-0-.+|[a-fA-F1-9]-([1-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])-[a-fA-F0-9]+)|.+')
servingNetworkName_regex = re. compile(r'5G:mnc[0-9]{3}[.]mcc[0-9]{3}[.]3gppnetwork[.]org(:[A-F0-9]{11})?')
mcc_regex = re.compile(r'[0-9]{3}')
mnc_regex = re.compile(r'[0-9]{2,3}')
supi_regex = re.compile(r'[0-9]{15,16}')


class Management():

    class Default():

        def Register():
            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.15)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +"(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    try:
                        imsi = int(input("Enter IMSI "+Fore.LIGHTBLACK_EX +"(Ex -  12345678900987)"+Fore.RESET+"- "))
                        
                        break

                    except ValueError:
                        print("Enter a Valid ID")
                        print('')
                        continue
                      
                # while True:
                #     try:
                #         ipv4Addr = ipaddress.ip_address(input("Enter pcfIpEndPoints IP "+Fore.LIGHTBLACK_EX+"(Ex -  10.45.0.15)"+Fore.RESET+"- "))
                #         break

                #     except ValueError:
                #         print("This is NOT a VALID IP Address.")
                #         print('')
                #         continue

                while True:
                    DNN = input("Enter DNN "+Fore.LIGHTBLACK_EX +"(Ex -  internet)"+Fore.RESET+"- ")
                    if re.fullmatch(nf_regex, DNN):
                        break

                    else:
                        print("Enter a Valid DNN")
                        print('')
                        continue

                # while True:
                #     try:
                #         ipv4Addresses = ipaddress.ip_address(input("Enter pcfIpEndPoints IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.10)"+Fore.RESET+"- "))
                #         break

                #     except ValueError:
                #         print("This is NOT a VALID IP Address.")
                #         print('')
                #         continue
                
                # while True:
                #     try:
                #         port1 = int(input("Enter pcfIpEndPoints IP Port "+Fore.LIGHTBLACK_EX +"(Ex - 7777)"+Fore.RESET+"- "))
                #         break

                #     except ValueError:
                #         print("This is NOT a VALID port Number.")
                #         print('')
                #         continue

                # while True:
                #     try:
                #         sst = int(input("Enter sst "+Fore.LIGHTBLACK_EX +"(Ex - 1)"+Fore.RESET+"- "))
                #         break

                #     except ValueError:
                #         print("This is NOT a VALID sst.")
                #         print('')
                #         continue

                # while True:
                #     try:
                #         suppFeat = int(input("Enter suppFeat "+Fore.LIGHTBLACK_EX +"(Ex - 2)"+Fore.RESET+"- "))
                #         break

                #     except ValueError:
                #         print("This is NOT a suppFeat.")
                #         print('')
                #         continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':'+str(port)+'/nbsf-management/v1/pcfBindings')
                curl.setopt(pycurl.HTTP_VERSION, pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)
                body_as_dict = {"supi":"imsi-"+str(imsi),"ipv4Addr":str(ip),"dnn":str(DNN),"pcfIpEndPoints":[{"ipv4Address":str(ip),"port":int(port)}],"snssai":{"sst":1},"suppFeat":str(2)}
                body_as_json_string = json.dumps(body_as_dict) 
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object) 
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()
                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print ("Server returned HTTP status code {}".format(status_code))
            
                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +"\nThe Register request register the session binding information of a UE in the BSF. Direction: PCF --> BSF ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('') 
                return None 


        def Retrieve_Session_Binding():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.15)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +"(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                      
                # while True:
                #     try:
                #         ipv4Addr = ipaddress.ip_address(input("Enter IPv4 Address of the served UE "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.15)"+Fore.RESET+"- "))
                #         break

                #     except ValueError:
                #         print("This is NOT a VALID IP Address.")
                #         print('')
                #         continue


                # while True:
                #     try:
                #         sst = int(input("Enter sst "+Fore.LIGHTBLACK_EX +"(Ex - 2)"+Fore.RESET+"- "))
                #         break

                #     except ValueError:
                #         print("This is NOT a VALID sst.")
                #         print('')
                #         continue

                # while True:
                #     try:
                #         sd = int(input("Enter sd "+Fore.LIGHTBLACK_EX +"(Ex - 1)"+Fore.RESET+"- "))
                #         break

                #     except ValueError:
                #         print("This is NOT a sd.")
                #         print('')
                #         continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':'+str(port)+'/nbsf-management/v1/pcfBindings?ipv4Addr='+str(ip))
                curl.setopt(pycurl.HTTP_VERSION, pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.TIMEOUT_MS, 3000)
                body_as_dict = {"snssai":{"sst":2},"sd":str(1)}
                body_as_json_string = json.dumps(body_as_dict) 
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object) 
                curl.perform()
                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print ("Server returned HTTP status code {}".format(status_code))
            
                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +"\nRetrieve the session binding information of the specified UE. One and only one of the address parameters - upvAddr, ipv6Prefix, or macAddr48 - shall be present. When ipv4Addr is provided, snssai and/or ipDomain, if applicable (in case of IPv4 address overlapping) shall also be provided. Either supi or gpsi shall be provided and dnn may be provided. Direction: NF Service Consumer --> BSF")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('') 
                return None 


        def Deregister():

            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.15)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    try:
                        bindingId = input("Enter Binding Id "+Fore.LIGHTBLACK_EX +
                                            "(Ex -  01)"+Fore.RESET+"- ")
                        break

                    except ValueError:
                        print("Enter a Valid ID")
                        print('')
                        continue


                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +'/nbsf-management/v1/pcfBindings/'+str(bindingId))
                crl.setopt(pycurl.HTTP_VERSION,
                        pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(crl.CUSTOMREQUEST, "DELETE")
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                        "\nDeregisters request remove an existing session binding from the BSF. Direction: PCF --> BSF ")
                crl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None

