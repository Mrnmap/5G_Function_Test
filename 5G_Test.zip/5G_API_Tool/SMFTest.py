from operator import concat
import inquirer
from secrets import choice
from colorama import Fore
from regex import P, T
import SMF
import API_PenTesting_Tool

# def cont():
#     questions = [
#         inquirer.List('Choice',
#                       message="Do you want continue ?",
#                       choices=['YES', 'NO'],)]
#     answers = inquirer.prompt(questions)
#     if answers['Choice'] == 'NO':
#         return False

#     return True


# def fun():
#     questions = [
#         inquirer.List('Function',
#                       message="Select the function",
#                       choices=['AUSF', 'BSF', 'AMF', 'NSSF', 'AMF','SMF'],), ]
#     answers = inquirer.prompt(questions)
#     print(answers)
#     if answers != None:
#         if answers["Function"] == 'SMF':
#             smf()

def smf():
    questions = [
        inquirer.List('SMF',
                      message="Select the SMF",
                      choices=['PDU_Session','Event_Exposure'],), ]
    answers = inquirer.prompt(questions)
    if answers == None:
        API_PenTesting_Tool.fun()

    if answers["SMF"] == 'PDU_Session':
        PDU_Session()

    if answers["SMF"] == 'Event_Exposure':
        Event_Exposure()

def PDU_Session():
    questions = [
        inquirer.List('PDU_Session',
                      message="Select the PDU_Session",
                      choices=['SM_contexts_collection','Individual_SM_context','PDU_sessions_collection','Individual_PDU_session_H_SMF'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        smf()

    elif answers["PDU_Session"] == 'SM_contexts_collection':
        SM_contexts_collection()

    elif answers["PDU_Session"] == 'Individual_SM_context':
        Individual_SM_context()

    elif answers["PDU_Session"] == 'PDU_sessions_collection':
        PDU_sessions_collection()

    elif answers["PDU_Session"] == 'Individual_PDU_session_H_SMF':
        Individual_PDU_session_H_SMF()      

def SM_contexts_collection():
    questions = [
        inquirer.List('SM_contexts_collection',
                      message="Select the SM_contexts_collection",
                      choices=['Create_SM_Context'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        PDU_Session()

    elif answers["SM_contexts_collection"] == 'Create_SM_Context':
        SMF.PDU_Session.SM_contexts_collection.Create_SM_Context()

def Individual_SM_context():
    questions = [
        inquirer.List('Individual_SM_context',
                      message="Select the Individual_SM_context",
                      choices=['Retrieve_SM_Context','Update_SM_Context','Release_SM_Context'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        PDU_Session()

    elif answers["Individual_SM_context"] == 'Update_SM_Context':
        SMF.PDU_Session.Individual_SM_context.Update_SM_Context()

    elif answers["Individual_SM_context"] == 'Retrieve_SM_Context':
        SMF.PDU_Session.Individual_SM_context.Retrieve_SM_Context()

    elif answers["Individual_SM_context"] == 'Release_SM_Context':
        SMF.PDU_Session.Individual_SM_context.Release_SM_Context()

def PDU_sessions_collection():
    questions = [
        inquirer.List('PDU_sessions_collection',
                      message="Select the PDU_sessions_collection",
                      choices=['Create_PDU_Session'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        PDU_Session()

    elif answers["PDU_sessions_collection"] == 'Create_PDU_Session':
        SMF.PDU_Session.PDU_sessions_collection.Create_PDU_Session()

def Individual_PDU_session_H_SMF():
    questions = [
        inquirer.List('Individual_PDU_session_H_SMF',
                      message="Select the Individual_PDU_session_H_SMF",
                      choices=['Update_PDU_Session','Retrieve_PDU_Session_Context'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        PDU_Session()

    elif answers["Individual_PDU_session_H_SMF"] == 'Retrieve_PDU_Session_Context':
        SMF.PDU_Session.Individual_PDU_session_H_SMF.Retrieve_PDU_Session_Context()

    elif answers["Individual_PDU_session_H_SMF"] == 'Update_PDU_Session':
        SMF.PDU_Session.Individual_PDU_session_H_SMF.Update_PDU_Session()


def Event_Exposure():
    questions = [
        inquirer.List('Event_Exposure',
                      message="Select the Event_Exposure",
                      choices=['Subscriptions_Collection','IndividualSubscription_Document'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        smf()

    elif answers["Event_Exposure"] == 'Subscriptions_Collection':
        Subscriptions_Collection()

    elif answers["Event_Exposure"] == 'IndividualSubscription_Document':
        IndividualSubscription_Document()


def Subscriptions_Collection():
    questions = [
        inquirer.List('Subscriptions_Collection',
                      message="Select the Subscriptions_Collection",
                      choices=['Create_Subsciption'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Event_Exposure()

    elif answers["Subscriptions_Collection"] == 'Create_Subsciption':
        SMF.Event_Exposure.Subscriptions_Collection.Create_Subsciption()

def IndividualSubscription_Document():
    questions = [
        inquirer.List('IndividualSubscription_Document',
                      message="Select the IndividualSubscription_Document",
                      choices=['Retrieve_Subscription','Replace_Subscription','Unsubscribe_from_Event_Notifications'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Event_Exposure()

    elif answers["IndividualSubscription_Document"] == 'Replace_Subscription':
        SMF.Event_Exposure.IndividualSubscription_Document.Replace_Subscription()

    elif answers["IndividualSubscription_Document"] == 'Retrieve_Subscription':
        SMF.Event_Exposure.IndividualSubscription_Document.Retrieve_Subscription()

    elif answers["IndividualSubscription_Document"] == 'Unsubscribe_from_Event_Notifications':
        SMF.Event_Exposure.IndividualSubscription_Document.Unsubscribe_from_Event_Notifications()

# while True:
#     fun()

#     if not cont():
#         break


