from operator import concat
import inquirer
from secrets import choice
from colorama import Fore
from regex import P, T
import PCF
import API_PenTesting_Tool


# def cont():
#     questions = [
#         inquirer.List('Choice',
#                       message="Do you want continue ?",
#                       choices=['YES', 'NO'],)]
#     answers = inquirer.prompt(questions)
#     if answers['Choice'] == 'NO':
#         return False

#     return True


# def fun():
#     questions = [
#         inquirer.List('Function',
#                       message="Select the function",
#                       choices=['AUSF', 'BSF', 'PCF', 'NSSF', 'AMF','PCF'],), ]
#     answers = inquirer.prompt(questions)
#     print(answers)
#     if answers != None:
#         if answers["Function"] == 'PCF':
#             pcf()

def pcf():
    questions = [
        inquirer.List('PCF',
                      message="Select the PCF",
                      choices=['Policy_Authorization', 'Access_and_Mobility_Policy_Control','Session_Management_Policy_Control','Background_Data_Transfer_Policy_Control','Policy_Control_Event_Exposure','UE_Policy_Control'],), ]
    answers = inquirer.prompt(questions)
    if answers == None:
        API_PenTesting_Tool.fun()

    if answers["PCF"] == 'Policy_Authorization':
        Policy_Authorization()

    if answers["PCF"] == 'Access_and_Mobility_Policy_Control':
        Access_and_Mobility_Policy_Control()

    if answers["PCF"] == 'Session_Management_Policy_Control':
        Session_Management_Policy_Control()

    if answers["PCF"] == 'Background_Data_Transfer_Policy_Control':
        Background_Data_Transfer_Policy_Control()

    if answers["PCF"] == 'Policy_Control_Event_Exposure':
        Policy_Control_Event_Exposure()

    if answers["PCF"] == 'UE_Policy_Control':
        UE_Policy_Control()

def Policy_Authorization():
    questions = [
        inquirer.List('Policy_Authorization',
                      message="Select the Policy_Authorization",
                      choices=['Application_Sessions_Collection', 'Events_Subscription_Document'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        pcf()

    elif answers["Policy_Authorization"] == 'Application_Sessions_Collection':
        Application_Sessions_Collection()

    elif answers["Policy_Authorization"] == 'Events_Subscription_Document':
        Events_Subscription_Document()




def Application_Sessions_Collection():
    questions = [
        inquirer.List('Application_Sessions_Collection',
                      message="Select the Application_Sessions_Collection",
                      choices=['Create_Application_Session_Context', 'Retrieve_Application_Session_Context', 'Update_Application_Session_Context', 'Delete_Application_Session_Context'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Policy_Authorization()

    elif answers["Application_Sessions_Collection"] == 'Create_Application_Session_Context':
        PCF.Policy_Authorization.Application_Sessions_Collection.Create_Application_Session_Context()

    elif answers["Application_Sessions_Collection"] == 'Retrieve_Application_Session_Context':
        PCF.Policy_Authorization.Application_Sessions_Collection.Retrieve_Application_Session_Context()

    elif answers["Application_Sessions_Collection"] == 'Update_Application_Session_Context':
        PCF.Policy_Authorization.Application_Sessions_Collection.Update_Application_Session_Context()

    elif answers["Application_Sessions_Collection"] == 'Delete_Application_Session_Context':
        PCF.Policy_Authorization.Application_Sessions_Collection.Delete_Application_Session_Context()

def Events_Subscription_Document():
    questions = [
        inquirer.List('Events_Subscription_Document',
                      message="Select the Events_Subscription_Document",
                      choices=['Update_Event_Subscription', 'Delete_Event_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Policy_Authorization()

    elif answers["Events_Subscription_Document"] == 'Update_Event_Subscription':
        PCF.Policy_Authorization.Events_Subscription_Document.Update_Event_Subscription()

    elif answers["Events_Subscription_Document"] == 'Delete_Event_Subscription':
        PCF.Policy_Authorization.Events_Subscription_Document.Delete_Event_Subscription()


def Access_and_Mobility_Policy_Control():
    questions = [
        inquirer.List('Access_and_Mobility_Policy_Control',
                      message="Select the Access_and_Mobility_Policy_Control",
                      choices=['Default'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        pcf()

    elif answers["Access_and_Mobility_Policy_Control"] == 'Default':
        PCF.Access_and_Mobility_Policy_Control.Default()

def Default():
    questions = [
        inquirer.List('Default',
                      message="Select the Default",
                      choices=['Create_Policy_Association','Retrieve_Policy_Association','Update_Policy_Association','Delete_Policy_Association'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Access_and_Mobility_Policy_Control()

    elif answers["Default"] == 'Create_Policy_Association':
        PCF.Access_and_Mobility_Policy_Control.Default.Create_Policy_Association()

    elif answers["Default"] == 'Retrieve_Policy_Association':
        PCF.Access_and_Mobility_Policy_Control.Default.Retrieve_Policy_Association()

    elif answers["Default"] == 'Update_Policy_Association':
        PCF.Access_and_Mobility_Policy_Control.Default.Update_Policy_Association()

    elif answers["Default"] == 'Delete_Policy_Association':
        PCF.Access_and_Mobility_Policy_Control.Default.Delete_Policy_Association()

def Session_Management_Policy_Control():
    questions = [
        inquirer.List('Session_Management_Policy_Control',
                      message="Select the Session_Management_Policy_Control",
                      choices=['Default'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        pcf()

    elif answers["Session_Management_Policy_Control"] == 'Default':
        PCF.Session_Management_Policy_Control.Default2()


def Default():
    questions = [
        inquirer.List('Default',
                      message="Select the Default",
                      choices=['Create_SM_Policy','Update_SM_Policy','Retrieve_SM_Policy','Delete_SM_Policy'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Access_and_Mobility_Policy_Control()

    elif answers["Default"] == 'Create_SM_Policy':
        PCF.Session_Management_Policy_Control.Default2.Create_SM_Policy()

    elif answers["Default"] == 'Update_SM_Policy':
        PCF.Session_Management_Policy_Control.Default2.Update_SM_Policy()

    elif answers["Default"] == 'Retrieve_SM_Policy':
        PCF.Session_Management_Policy_Control.Default2.Retrieve_SM_Policy()

    elif answers["Default"] == 'Delete_SM_Policy':
        PCF.Session_Management_Policy_Control.Default2.Delete_SM_Policy()

def Background_Data_Transfer_Policy_Control():
    questions = [
        inquirer.List('Background_Data_Transfer_Policy_Control',
                      message="Select the Background_Data_Transfer_Policy_Control",
                      choices=['BDT_policies_Collection','Individual_BDT_policy_Document'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        pcf()

    elif answers["Background_Data_Transfer_Policy_Control"] == 'BDT_policies_Collection':
        PCF.Background_Data_Transfer_Policy_Control.BDT_policies_Collection()

    elif answers["Background_Data_Transfer_Policy_Control"] == 'Individual_BDT_policy_Document':
        PCF.Background_Data_Transfer_Policy_Control.Individual_BDT_policy_Document()

def BDT_policies_Collection():
    questions = [
        inquirer.List('BDT_policies_Collection',
                      message="Select the BDT_policies_Collection",
                      choices=['Create_BDT_Policy'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Background_Data_Transfer_Policy_Control()

    elif answers["BDT_policies_Collection"] == 'Create_BDT_Policy':
        PCF.Background_Data_Transfer_Policy_Control.BDT_policies_Collection.Create_BDT_Policy()

def Individual_BDT_policy_Document():
    questions = [
        inquirer.List('Individual_BDT_policy_Document',
                      message="Select the Individual_BDT_policy_Document",
                      choices=['Retrieve_BDT_Policy','Update_BDT_Policy'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Background_Data_Transfer_Policy_Control()

    elif answers["Individual_BDT_policy_Document"] == 'Retrieve_BDT_Policy':
        PCF.Background_Data_Transfer_Policy_Control.Individual_BDT_policy_Document.Retrieve_BDT_Policy()

    elif answers["Individual_BDT_policy_Document"] == 'Update_BDT_Policy':
        PCF.Background_Data_Transfer_Policy_Control.Individual_BDT_policy_Document.Update_BDT_Policy()

def Policy_Control_Event_Exposure():
    questions = [
        inquirer.List('Policy_Control_Event_Exposure',
                      message="Select the Policy_Control_Event_Exposure",
                      choices=['Policy_Control_Events_Subscription_Collection','Individual_Policy_Control_Events_Subscription_Document'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        pcf()

    elif answers["Policy_Control_Event_Exposure"] == 'Policy_Control_Events_Subscription_Collection':
        PCF.Policy_Control_Event_Exposure.Policy_Control_Events_Subscription_Collection()

    elif answers["Policy_Control_Event_Exposure"] == 'Individual_Policy_Control_Events_Subscription_Document':
        PCF.Policy_Control_Event_Exposure.Individual_Policy_Control_Events_Subscription_Document()

def Policy_Control_Events_Subscription_Collection():
    questions = [
        inquirer.List('Policy_Control_Events_Subscription_Collection',
                      message="Select the Policy_Control_Events_Subscription_Collection",
                      choices=['Create_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Policy_Control_Event_Exposure()

    elif answers["Policy_Control_Events_Subscription_Collection"] == 'Create_Subscription':
        PCF.Policy_Control_Event_Exposure.Policy_Control_Events_Subscription_Collection.Create_Subscription()

def Individual_Policy_Control_Events_Subscription_Document():
    questions = [
        inquirer.List('Individual_Policy_Control_Events_Subscription_Document',
                      message="Select the Individual_Policy_Control_Events_Subscription_Document",
                      choices=['Retrieve_Subscription','Modify_Subscription','Delete_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        Policy_Control_Event_Exposure()

    elif answers["Individual_Policy_Control_Events_Subscription_Document"] == 'Retrieve_Subscription':
        PCF.Policy_Control_Event_Exposure.Individual_Policy_Control_Events_Subscription_Document.Retrieve_Subscription()

    elif answers["Individual_Policy_Control_Events_Subscription_Document"] == 'Modify_Subscription':
        PCF.Policy_Control_Event_Exposure.Individual_Policy_Control_Events_Subscription_Document.Modify_Subscription()

    elif answers["Individual_Policy_Control_Events_Subscription_Document"] == 'Delete_Subscription':
        PCF.Policy_Control_Event_Exposure.Individual_Policy_Control_Events_Subscription_Document.Delete_Subscription()


def UE_Policy_Control():
    questions = [
        inquirer.List('UE_Policy_Control',
                      message="Select the UE_Policy_Control",
                      choices=['UE_Policy_Associations_Collection'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        pcf()

    elif answers["UE_Policy_Control"] == 'UE_Policy_Associations_Collection':
        PCF.UE_Policy_Control.UE_Policy_Associations_Collection()


def UE_Policy_Associations_Collection():
    questions = [
        inquirer.List('UE_Policy_Associations_Collection',
                      message="Select the UE_Policy_Associations_Collection",
                      choices=['Create_Subscription'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        UE_Policy_Control()

    elif answers["UE_Policy_Associations_Collection"] == 'Create_Subscription':
        PCF.UE_Policy_Control.UE_Policy_Associations_Collection.Create_Subscription()



# while True:
#     fun()

#     if not cont():
#         break


