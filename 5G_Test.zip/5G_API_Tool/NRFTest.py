from operator import concat
import inquirer
from secrets import choice
from colorama import Fore
from regex import P, T
import NRF
import API_PenTesting_Tool


# def cont():
#     questions = [
#         inquirer.List('Choice',
#                       message="Do you want continue ?",
#                       choices=['YES', 'NO'],)]
#     answers = inquirer.prompt(questions)
#     if answers['Choice'] == 'NO':
#         return False

#     return True


# def fun():
#     questions = [
#         inquirer.List('Function',
#                       message="Select the function",
#                       choices=['AUSF', 'BSF', 'NRF', 'NSSF', 'AMF'],), ]
#     answers = inquirer.prompt(questions)
#     print(answers)
#     if answers != None:
#         if answers["Function"] == 'NRF':
#             nrf()

def nrf():
    questions = [
        inquirer.List('NRF',
                      message="Select the NRF",
                      choices=['NF_Management', 'NF_Discovery'],), ]
    answers = inquirer.prompt(questions)
    
    if answers == None:
        API_PenTesting_Tool.fun()

    if answers["NRF"] == 'NF_Management':
        NF_Management()

    if answers["NRF"] == 'NF_Discovery':
        NF_Discovery()

    # if answers["NRF"] == 'Access_Token_OAuth2':
    #     Access_Token_OAuth2()


def NF_Management():
    questions = [
        inquirer.List('NF_Management',
                      message="Select the NF_Management",
                      choices=['NF_Instances_Store', 'NF_Instances_ID_Document', 'Subscriptions_Collection', 'Subscriptions_Document'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        nrf()

    elif answers["NF_Management"] == 'NF_Instances_Store':
        NF_Instances_Store()

    elif answers["NF_Management"] == 'NF_Instances_ID_Document':
        NF_Instances_ID_Document()

    elif answers["NF_Management"] == 'Subscriptions_Collection':
        Subscriptions_Collection()

    elif answers["NF_Management"] == 'Subscriptions_Document':
        Subscriptions_Document()


def NF_Instances_ID_Document():
    questions = [
        inquirer.List('NF_Instances_ID_Document',
                      message="Select the NF_Instances_ID_Document",
                      choices=['Retrieve_NF_Profile', 'NF_Register', 'NF_Update', 'NF_Deregister'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        NF_Management()

    elif answers["NF_Instances_ID_Document"] == 'Retrieve_NF_Profile':
        NRF.NF_Management.NF_Instance_ID_Document.Retrive_NF_Profile()

    elif answers["NF_Instances_ID_Document"] == 'NF_Register':
        NRF.NF_Management.NF_Instance_ID_Document.NF_Register()

    elif answers["NF_Instances_ID_Document"] == 'NF_Update':
        NRF.NF_Management.NF_Instance_ID_Document.NF_Update()

    elif answers["NF_Instances_ID_Document"] == 'NF_Deregister':
        NRF.NF_Management.NF_Instance_ID_Document.NF_Deregister()


def Subscriptions_Collection():
    questions = [
        inquirer.List('Subscriptions_Collection',
                      message="Select the Subscriptions_Collection",
                      choices=['NF_Status_Subsccribe'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        NF_Management()

    elif answers["Subscriptions_Collection"] == 'NF_Status_Subsccribe':
        NRF.NF_Management.Subcriptions_Collection.NF_Status_Subscribe()


def Subscriptions_Document():
    questions = [
        inquirer.List('Subscriptions_Document',
                      message="Select the Subscriptions_Document",
                      choices=['Update_Subscription', 'NF_Stats_Unsubscribe'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        NF_Management()

    elif answers["Subscriptions_Document"] == 'Update_Subscription':
        NRF.NF_Management.Subcription_ID_Document.Update_Subscription()

    elif answers["Subscriptions_Document"] == 'NF_Stats_Unsubscribe':
        NRF.NF_Management.Subcription_ID_Document.NF_Status_Unsubscribe()


def NF_Instances_Store():
    questions = [
        inquirer.List('NF_Instances_Store',
                      message="Select the NF_Instances_Store",
                      choices=['Retrieve_NF_List'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        NF_Management()

    elif answers["NF_Instances_Store"] == 'Retrieve_NF_List':
        NRF.NF_Management.NF_Instances_Store.Retrive_NF_List()

    # elif answers["NF_Instances_Store"] == 'Query_Options':
    #     NRF.NF_Management.NF_Instances_Store.Query_Options()


def Access_Token_OAuth2():
    questions = [
        inquirer.List('Access_Token_OAuth2',
                      message="Select the Access_Token_OAuth2",
                      choices=['Access_Token_Request'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        nrf()

    elif answers["Access_Token_OAuth2"] == 'Access_Token_Request':
        NRF.Access_Token_OAuth2.Access_Token_Request()
        print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)


def NF_Discovery():
    questions = [
        inquirer.List('NF_Discovery',
                      message="Select the NF_Discovery",
                      choices=['NF_Instances_Store'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        nrf()

    elif answers["NF_Discovery"] == 'NF_Instances_Store':
        NF_Instances_Discovery_Store()


def NF_Instances_Discovery_Store():
    questions = [
        inquirer.List('NF_Instances_Store',
                      message="Select the NF_Instances_Store",
                      choices=['NF_Discover'],), ]
    answers = inquirer.prompt(questions)

    if answers == None:
        NF_Discovery()

    elif answers["NF_Instances_Store"] == 'NF_Discover':
        NRF.NF_Discovery.NF_Instances_Store.NF_Descover()


# while True:
#     fun()

#     if not cont():
#         break


