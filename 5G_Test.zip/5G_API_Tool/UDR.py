import pycurl
import json
from io import StringIO
from colorama import Fore
import ipaddress
import re
from pyrsistent import v
import datetime

id_regex = re.compile(
    r'([A-Za-z0-9])+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+[-]+[A-Za-z0-9]+')
nf_regex = re. compile(r'[A-Za-z]+')
supiOrsuci_regex = re. compile(
    r'imsi-[0-9]{5,15}|nai-.+|gli-.+|gci-.+|suci-(0-[0-9]{3}-[0-9]{2,3}|[1-7]-.+)-[0-9]{1,4}-(0-0-.+|[a-fA-F1-9]-([1-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])-[a-fA-F0-9]+)|.+')
servingNetworkName_regex = re. compile(
    r'5G:mnc[0-9]{3}[.]mcc[0-9]{3}[.]3gppnetwork[.]org(:[A-F0-9]{11})?')
mcc_regex = re.compile(r'[0-9]{3}')
mnc_regex = re.compile(r'[0-9]{2,3}')
supi_regex = re.compile(r'[0-9]{15,16}')
amfId_regex = re.compile(r'[A-Fa-f0-9]{6}')
smsfDiameterAddress_regex = re.compile(
    r'([A-Za-z0-9]+([-A-Za-z0-9]+)\.)+[a-z]{2,}')
servingNetworkName_regex = re.compile(
    r'5G:mnc[0-9]{3}[.]mcc[0-9]{3}[.]3gppnetwork[.]org(:[A-F0-9]{11})')
rand_regex = re.compile(r'[A-Fa-f0-9]{32}')
auts_regex = re.compile(r'[A-Fa-f0-9]{28}')
plmn_regex = re.compile(r'[0-9]{5,6}')



class Subscription_Data():

    class Authentication_Data_Document():

        def Query_Authentication_Data():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/authentication-data/authentication-subscription')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's authentication subscription data. Direction: UDM --> UDR")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class Authentication_Subscription_Document():

        def Modify_Authentication_Data():


            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                while True:
                    try:
                        path = str(input("Enter path "+Fore.LIGHTBLACK_EX +
                                         "(Ex - )"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID path.")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/subscription-data/'+str(supi)+'/authentication-data/authentication-subscription')
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                               'Content-Type: application/json'])
                crl.setopt(crl.CUSTOMREQUEST, 'PATCH')

                body_as_dict = [
                                {
                                    "op": "add",
                                    "path": str(path)
                                }
                                ]
                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                crl.setopt(pycurl.READDATA, body_as_file_object)
                crl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PATCH request is used to modify a UE's authentication subscription data. Updates shall be limited to the sequenceNumber property. Attempts to patch any other attribute shall be rejected. Direction: UDM --> UDR")
                crl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


    class Authentication_Status_Document():

        def Create_Authentication_Status():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                while True:
                    servingNetworkName = input("Enter serving Network Name "+Fore.LIGHTBLACK_EX +
                                               "(Ex -  (5G:mnc[0-9]{3}[.]mcc[0-9]{3}[.]3gppnetwork[.]org(:[A-F0-9]{11}))"+Fore.RESET+"- ")
                    if re.fullmatch(servingNetworkName_regex, servingNetworkName):
                        break

                    else:
                        print("Enter a Valid serving Network Name ")
                        print('')
                        continue


                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/subscription-data/'+str(supi)+'/authentication-data/authentication-status')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {  "nfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                    "success": True,
                                    "timeStamp": str(datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")),
                                    "authType": "5G_AKA",
                                    "servingNetworkName": str(servingNetworkName)
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PUT request is used to store a UE's authentication status. Direction: UDM --> UDR")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None


    class AuthEvent_Document():

        def Query_Authentication_Status():
            
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/authentication-data/authentication-status')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's authentication status.")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None

    class Authentication_SoR_Document():

        def Store_Authentication_SoR():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue


                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/subscription-data/'+str(supi)+'/ue-update-confirmation-data/sor-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {    "provisioningTime": str(datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")),
                                    "ueUpdateStatus": "NOT_SENT"
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PUT request is used to store the Steering of Roaming (SoR) acknowledgement information received from a UE (SoR-XMAC-IUE). Direction: UDM --> UDR")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None


        def Query_Authentication_SoR():
            
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/ue-update-confirmation-data/sor-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the Steering of Roaming (SoR) acknowledgement information received from a UE. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('')  
                print('')
                return None

    class Authentication_UPU_Document():

        def Store_UE_Parameter_Update_Data():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue


                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/subscription-data/'+str(supi)+'/ue-update-confirmation-data/upu-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {    "provisioningTime": str(datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")),
                                    "ueUpdateStatus": "NOT_SENT"
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PUT request is used to store the Steering of Roaming (SoR) acknowledgement information received from a UE (SoR-XMAC-IUE). Direction: UDM --> UDR")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None


        def Query_UE_Parameter_Update_Data():
            
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/ue-update-confirmation-data/upu-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the UPU acknowledgement information received from a UE. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class Provisioned_Data_Document():

        def Query_Provisioned_Data():
            
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    plmn = input("Enter PLMN ID "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  12345)"+Fore.RESET+"- ")
                    if re.fullmatch(plmn_regex, plmn):
                        break

                    else:
                        print("Enter a Valid PLMN ID ")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/'+str(plmn)+'/provisioned-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve multiple sets of a UE's provisioned data. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None

    class Access_And_Mobility_Subscription_Data_Document():

        def Query_AM_Data():
            
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    plmn = input("Enter PLMN ID "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  12345)"+Fore.RESET+"- ")
                    if re.fullmatch(plmn_regex, plmn):
                        break

                    else:
                        print("Enter a Valid PLMN ID ")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/'+str(plmn)+'/provisioned-data/am-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's provisioned access and mobility subscription data. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


    class SMF_Selection_Subscription_Data_Document():

        def Query_Selection_Data():
            
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    plmn = input("Enter PLMN ID "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  12345)"+Fore.RESET+"- ")
                    if re.fullmatch(plmn_regex, plmn):
                        break

                    else:
                        print("Enter a Valid PLMN ID ")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/'+str(plmn)+'/provisioned-data/smf-selection-subscription-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's provisioned SMF selection subscription data. Direction: UDM --> UDR")
                curl.close()

            except KeyboardInterrupt:
                print('')  
                print('')
                return None


    class Session_Management_Subscription_Data():

        def Query_SM_Data():
            
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    plmn = input("Enter PLMN ID "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  12345)"+Fore.RESET+"- ")
                    if re.fullmatch(plmn_regex, plmn):
                        break

                    else:
                        print("Enter a Valid PLMN ID ")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/'+str(plmn)+'/provisioned-data/sm-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's provisioned Session Management subscription data. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


    class AMF_3GPP_Access_Registration_Document():

        def Query_AMF_Context_3GPP_Access():
            
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue


                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/context-data/amf-3gpp-access')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


        def Create_AMF_Context_3GPP_Access():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue


                while True:
                    mcc = input("Enter mcc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("Enter a Valid mcc ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter mnc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("Enter a Valid mnc ")
                        print('')
                        continue

                while True:
                    amfId = input("Enter amfId "+Fore.LIGHTBLACK_EX +
                                  "(Ex - 123456)"+Fore.RESET+"- ")
                    if re.fullmatch(amfId_regex, amfId):
                        break

                    else:
                        print("This is NOT a VALID amfId")
                        print('')
                        continue


                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/subscription-data/'+str(supi)+'/context-data/amf-3gpp-access')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {"amfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                "deregCallbackUri": "string",
                                "amfServiceNameDereg": "nnrf-nfm",
                                "amfServiceNamePcscfRest": "nnrf-nfm",
                                "initialRegistrationInd": True,
                                "guami": {
                                    "plmnId": {
                                    "mcc": str(mcc),
                                    "mnc": str(mnc)
                                    },
                                    "amfId": str(amfId)
                                },
                                "backupAmfInfo": [
                                    {
                                    "backupAmf": "string",
                                    "guamiList": [
                                        {
                                        "plmnId": {
                                    "mcc": str(mcc),
                                    "mnc": str(mnc)
                                    },
                                    "amfId": str(amfId)
                                        }
                                    ]
                                    }
                                ],
                                "ratType": "NR"
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PUT request is used to store the AMF registration of a UE using 3GPP access. Direction: UDM --> UDR")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None


        def Modify_AMF_Context_3GPP_Access():

            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                while True:
                    try:
                        path = str(input("Enter path "+Fore.LIGHTBLACK_EX +
                                         "(Ex - )"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID path.")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/subscription-data/'+str(supi)+'/context-data/amf-3gpp-access')
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                               'Content-Type: application/json'])
                crl.setopt(crl.CUSTOMREQUEST, 'PATCH')

                body_as_dict = [
                    {
                        "op": "add",
                        "path": str(path)
                    }
                ]

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                crl.setopt(pycurl.READDATA, body_as_file_object)
                crl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PATCH request is used to modify the AMF registration of a UE using 3GPP access. Direction: UDM --> UDR")
                crl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


    class AMF_Non_3GPP_Access_Registration_Document():

        def Retrieve_AMF_Context_Non_3GPP_Access():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue


                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/context-data/amf-non-3gpp-access')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None

        def Store_AMF_Context_Non_3GPP_Access():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue


                while True:
                    mcc = input("Enter mcc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("Enter a Valid mcc ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter mnc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("Enter a Valid mnc ")
                        print('')
                        continue

                while True:
                    amfId = input("Enter amfId "+Fore.LIGHTBLACK_EX +
                                  "(Ex - 123456)"+Fore.RESET+"- ")
                    if re.fullmatch(amfId_regex, amfId):
                        break

                    else:
                        print("This is NOT a VALID amfId")
                        print('')
                        continue


                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/subscription-data/'+str(supi)+'/context-data/amf-non-3gpp-access')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {  "amfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                    "imsVoPs": "HOMOGENEOUS_SUPPORT",
                                    "deregCallbackUri": "string",
                                    "guami": {
                                        "plmnId": {
                                    "mcc": str(mcc),
                                    "mnc": str(mnc)
                                    },
                                    "amfId": str(amfId)
                                    },
                                    "backupAmfInfo": [
                                        {
                                        "backupAmf": "string",
                                        "guamiList": [
                                            {
                                            "plmnId": {
                                    "mcc": str(mcc),
                                    "mnc": str(mnc)
                                    },
                                    "amfId": str(amfId)
                                            }
                                        ]
                                        }
                                    ],
                                    "ratType": "NR"
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PUT request is used to store the AMF registration of a UE using non-3GPP access. Direction: UDM --> UDR")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None


        def Modify_AMF_Context_Non_3GPP_Access():

            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                while True:
                    try:
                        path = str(input("Enter path "+Fore.LIGHTBLACK_EX +
                                         "(Ex - )"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID path.")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/subscription-data/'+str(supi)+'/context-data/amf-non-3gpp-access')
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                               'Content-Type: application/json'])
                crl.setopt(crl.CUSTOMREQUEST, 'PATCH')

                body_as_dict = [
                    {
                        "op": "add",
                        "path": str(path)
                    }
                ]

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                crl.setopt(pycurl.READDATA, body_as_file_object)
                crl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PATCH request is used to modify the AMF registration of a UE using 3GPP access. Direction: UDM --> UDR")
                crl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


    class SMF_Registrations_Collection():

        def Query_SMF_Registrations():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue


                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/context-data/smf-registrations')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None

    class SMF_Registration_Document():

        def Query_SMF_Registration():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    pduSessionId = input("Enter PDU Session Id "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  b9f2f940-c628-41ec-aa78-9163487d7302)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, pduSessionId):
                        break

                    else:
                        print("Enter a Valid ID")
                        print('')
                        continue
                    
                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/context-data/smf-registrations/'+str(pduSessionId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None

        def Store_SMF_Registration():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                while True:
                    try:
                        pduSessionId = int(input("Enter pduSessionId "+Fore.LIGHTBLACK_EX +
                                                 "(Ex - 255)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID pduSessionId.")
                        print('')
                        continue

                while True:
                    mcc = input("Enter mcc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("Enter a Valid mcc ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter mnc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("Enter a Valid mnc ")
                        print('')
                        continue


                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/subscription-data/'+str(supi)+'/context-data/smf-registrations/'+str(pduSessionId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {   "smfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                    "pduSessionId": 255,
                                    "singleNssai": {
                                        "sst": 255
                                    },
                                    "plmnId": {
                                        "mcc": str(mcc),
                                        "mnc": str(mnc)
                                    }
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PUT request is used to store an SMF registration for a PDU session. Direction: UDM --> UDF")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None


        def Delete_SMF_Registration():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    pduSessionId = input("Enter PDU Session Id "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  b9f2f940-c628-41ec-aa78-9163487d7302)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, pduSessionId):
                        break

                    else:
                        print("Enter a Valid ID")
                        print('')
                        continue
                    
                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/context-data/smf-registrations/'+str(pduSessionId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()  

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


    class Operator_Specific_Data_Container_Document():

        def Query_Operator_Specific_Data():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue


                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/operator-specific-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None

        def Modify_Operator_Specific_Data():

            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                while True:
                    try:
                        path = str(input("Enter path "+Fore.LIGHTBLACK_EX +
                                         "(Ex - )"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID path.")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/subscription-data/'+str(supi)+'/operator-specific-data')
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                               'Content-Type: application/json'])
                crl.setopt(crl.CUSTOMREQUEST, 'PATCH')

                body_as_dict = [
                    {
                        "op": "add",
                        "path": str(path)
                    }
                ]

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                crl.setopt(pycurl.READDATA, body_as_file_object)
                crl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PATCH request is used to modify the AMF registration of a UE using 3GPP access. Direction: UDM --> UDR")
                crl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


    class SMSF_3GPP_Registration_Document():

        def Store_SMSF_Registration_3GPP_Access():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                while True:
                    mcc = input("Enter mcc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("Enter a Valid mcc ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter mnc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("Enter a Valid mnc ")
                        print('')
                        continue


                while True:
                    name = input("Enter name "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  ([A-Za-z0-9]+([-A-Za-z0-9]+)\.)+[a-z]{2,})"+Fore.RESET+"- ")
                    if re.fullmatch(smsfDiameterAddress_regex, name):
                        break

                    else:
                        print("Enter a Valid name ")
                        print('')
                        continue

                while True:
                    realm = input("Enter realm "+Fore.LIGHTBLACK_EX +
                                  "(Ex -  ([A-Za-z0-9]+([-A-Za-z0-9]+)\.)+[a-z]{2,})"+Fore.RESET+"- ")
                    if re.fullmatch(smsfDiameterAddress_regex, realm):
                        break

                    else:
                        print("Enter a Valid realm ")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/subscription-data/'+str(supi)+'/context-data/smsf-3gpp-access')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {  "smsfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                    "plmnId": {
                                        "mcc": str(mcc),
                                        "mnc": str(mnc)
                                    },
                                    "smsfDiameterAddress": {
                                        "name": str(name),
                                        "realm": str(realm)
                                    }
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PUT request is used to store the SMSF registration for a UE using 3GPP access. Direction: UDM --> UDF")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None



        def Delete_SMSF_Registration_3GPP_Access():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue


                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/context-data/smsf-3gpp-access')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


        def Query_SMSF_Registration_3GPP_Access():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue


                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/context-data/smsf-3gpp-access')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None

    class SMSF_Non_3GPP_Registration_Document():

        def Store_SMSF_Registration_Non_3GPP_Access():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                while True:
                    mcc = input("Enter mcc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  123)"+Fore.RESET+"- ")
                    if re.fullmatch(mcc_regex, mcc):
                        break

                    else:
                        print("Enter a Valid mcc ")
                        print('')
                        continue

                while True:
                    mnc = input("Enter mnc "+Fore.LIGHTBLACK_EX +
                                "(Ex -  45)"+Fore.RESET+"- ")
                    if re.fullmatch(mnc_regex, mnc):
                        break

                    else:
                        print("Enter a Valid mnc ")
                        print('')
                        continue


                while True:
                    name = input("Enter name "+Fore.LIGHTBLACK_EX +
                                 "(Ex -  ([A-Za-z0-9]+([-A-Za-z0-9]+)\.)+[a-z]{2,})"+Fore.RESET+"- ")
                    if re.fullmatch(smsfDiameterAddress_regex, name):
                        break

                    else:
                        print("Enter a Valid name ")
                        print('')
                        continue

                while True:
                    realm = input("Enter realm "+Fore.LIGHTBLACK_EX +
                                  "(Ex -  ([A-Za-z0-9]+([-A-Za-z0-9]+)\.)+[a-z]{2,})"+Fore.RESET+"- ")
                    if re.fullmatch(smsfDiameterAddress_regex, realm):
                        break

                    else:
                        print("Enter a Valid realm ")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/subscription-data/'+str(supi)+'/context-data/smsf-non-3gpp-access')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.PUT, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {  "smsfInstanceId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                    "plmnId": {
                                        "mcc": str(mcc),
                                        "mnc": str(mnc)
                                    },
                                    "smsfDiameterAddress": {
                                        "name": str(name),
                                        "realm": str(realm)
                                    }
                                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PUT request is used to store the SMSF registration for a UE using 3GPP access. Direction: UDM --> UDF")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None



        def Delete_SMSF_Registration_Non_3GPP_Access():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue


                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/context-data/smsf-non-3gpp-access')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


        def Query_SMSF_Registration_Non_3GPP_Access():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue


                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/context-data/smsf-non-3gpp-access')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None

    class SMS_Management_Subscription_Data_Document():

        def Query_SMS_Management_Data():
            
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    plmn = input("Enter PLMN ID "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  12345)"+Fore.RESET+"- ")
                    if re.fullmatch(plmn_regex, plmn):
                        break

                    else:
                        print("Enter a Valid PLMN ID ")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/'+str(plmn)+'/provisioned-data/sms-mng-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's provisioned Session Management subscription data. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None



    class SMS_Subscription_Data_Document():

        def Query_SMS_Subscription():
            
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    plmn = input("Enter PLMN ID "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  12345)"+Fore.RESET+"- ")
                    if re.fullmatch(plmn_regex, plmn):
                        break

                    else:
                        print("Enter a Valid PLMN ID ")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/'+str(plmn)+'/provisioned-data/sms-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's provisioned Session Management subscription data. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None

    class Parameter_Provision_Document():

        def Query_PP_Data():
            
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue


                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/pp-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


    class ProvisionedParameterData_Document():

        def Modify_PP_Data():

            try:
                crl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.12)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter supi "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID supi ")
                        print('')
                        continue

                while True:
                    try:
                        path = str(input("Enter path "+Fore.LIGHTBLACK_EX +
                                         "(Ex - )"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID path.")
                        print('')
                        continue

                crl.setopt(crl.URL, 'http://'+str(ip)+':'+str(port) +
                           '/subscription-data/'+str(supi)+'/pp-data')
                crl.setopt(pycurl.HTTP_VERSION,
                           pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                crl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                               'Content-Type: application/json'])
                crl.setopt(crl.CUSTOMREQUEST, 'PATCH')

                body_as_dict = [
                    {
                        "op": "add",
                        "path": str(path)
                    }
                ]

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                crl.setopt(pycurl.READDATA, body_as_file_object)
                crl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                crl.perform()

                status_code = crl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis PATCH request is used to modify the AMF registration of a UE using 3GPP access. Direction: UDM --> UDR")
                crl.close()

            except KeyboardInterrupt:
                print('')  # Go to the next line so printing looks better.
                print('')
                return None


    class Event_Exposure_Subscriptions_Collection():

        def Query_EE_Subscription():
            
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue


                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/ee-subscriptions')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None



        def Create_EE_Subscription():

            try:
                curl = pycurl.Curl()
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                         "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter SUPI or SUCI  "+Fore.LIGHTBLACK_EX +
                                 "(Ex - 123456789012345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("This is NOT a VALID SUPI or SUCI  ")
                        print('')
                        continue

                curl.setopt(pycurl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudm-ee/v1/'+str(supi)+'/ee-subscriptions')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Accept: application/json',
                                                'Content-Type: application/json'])
                curl.setopt(pycurl.POST, 1)
                curl.setopt(pycurl.TIMEOUT_MS, 3000)

                body_as_dict = {
                    "callbackReference": "string",
                    "monitoringConfigurations": {}
                }

                body_as_json_string = json.dumps(body_as_dict)  # dict to json
                body_as_file_object = StringIO(body_as_json_string)
                curl.setopt(pycurl.READDATA, body_as_file_object)
                curl.setopt(pycurl.POSTFIELDSIZE, len(body_as_json_string))
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nVulnerability Description :"+Fore.RED +
                          "\nThis POST request is used to create an Event Exposure subscription. Direction: UDM --> UDF")
                curl.close()

            except KeyboardInterrupt:
                print('')
                print('')
                return None


    class Event_Exposure_Subscription_Document():

        def Update_EE_Subscription_Put():
            pass

        def Remove_EE_Subscription():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    subsId = input("Enter subsId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  b9f2f940-c628-41ec-aa78-9163487d7302)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, subsId):
                        break

                    else:
                        print("Enter a Valid subsId")
                        print('')
                        continue
                    
                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/context-data/ee-subscriptions/'+str(subsId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()      

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


        def Update_EE_Subscription_Patch():
            pass

        def Update_EE_Group_Subscription_Put():
            pass

        def Remove_EE_Group_Subscriptions():
            pass

        def Update_EE_Group_Subscription_Patch():
            pass

    class AMF_Subscription_Info_Document():

        def Store_AMF_EE_Subscription():
            pass

    class Event_AMF_Subscription_Info_Document():

        def Remove_AMF_EE_Subscription():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    subs_id = input("Enter Subscriptions Id "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  b9f2f940-c628-41ec-aa78-9163487d7302)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, subs_id):
                        break

                    else:
                        print("Enter a Valid Subscriptions ID")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/context-data/ee-subscriptions/'+str(subs_id)+'amf-subscriptions')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None

    class AmfSubscriptionInfo_Document():

        def Modify_AMF_Subscription():
            pass

    class Query_AMF_Subscription_Info_Document():

        def Query_AMF_Subscription_Info():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    subs_id = input("Enter Subscriptions Id "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  b9f2f940-c628-41ec-aa78-9163487d7302)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, subs_id):
                        break

                    else:
                        print("Enter a Valid Subscriptions ID")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/context-data/ee-subscriptions/'+str(subs_id)+'amf-subscriptions')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None

    class Event_Exposure_Group_Subscriptions_Collection():

        def Query_EE_Group_Subscriptions():
            pass

        def Create_EE_Group_Subscription():
            pass

    class Event_Exposure_Data_Document():

        def Query_EE_Profile():
            pass

    class SDM_Subscriptions_Collection():

        def Query_SDM_Subscription():
            pass

        def Create_SDM_Subscription():
            pass

    class SDM_Subscription_Document():

        def Update_SDM_Subscription():
            pass

        def Remove_SDM_Subscription():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    subsId = input("Enter subsId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  b9f2f940-c628-41ec-aa78-9163487d7302)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, subsId):
                        break

                    else:
                        print("Enter a Valid subsId")
                        print('')
                        continue
                    
                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/context-data/sdm-subscriptions/'+str(subsId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()      

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


        def Modify_SDM_Subscription():
            pass

    class Retrieval_of_shared_data():

        def Query_Shared_Data():
            pass

    class Subs_To_Nofify_Collection():

        def Subscribe_for_Subscription_Data_Notifications():
            pass

        def Query_Subscription_Data_Notification_Subscriptions():
            pass

    class Subs_To_Notify_Collection():

        def Delete_Subscription_Data_Notification_Subscriptions():
            pass

    class Subs_To_Notify_Document():

        def Delete_a_Subscription_Data_Notification_Subscription():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    subsId = input("Enter subsId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  b9f2f940-c628-41ec-aa78-9163487d7302)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, subsId):
                        break

                    else:
                        print("Enter a Valid subsId")
                        print('')
                        continue
                    
                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/subs-to-notify/'+str(subsId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()      

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


        def Modify_a_Subscription_Data_Notification_Subscription():
            pass

    class Trace_Data_Document():

        def Query_Trace_Data():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    plmn = input("Enter PLMN ID "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  12345)"+Fore.RESET+"- ")
                    if re.fullmatch(plmn_regex, plmn):
                        break

                    else:
                        print("Enter a Valid PLMN ID ")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/'+str(plmn)+'/provisioned-data/trace-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's provisioned Session Management subscription data. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None

    class Query_Identity_Data_by_SUPI_or_GPSI_Document():

        def Query_Identity_Data():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/identity-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's provisioned Session Management subscription data. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None

    class Query_ODB_Data_by_SUPI_or_GPSI_Document():

        def Query_ODB_Data():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/operator-determined-barring-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's provisioned Session Management subscription data. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


    class Context_Data_Document():

        def Query_Context_Data():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/context-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's provisioned Session Management subscription data. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


    class Group_Identifiers():

        def Query_Group_Identifiers():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/subscription-data/'+str(supi)+'/identity-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's provisioned Session Management subscription data. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None



class Policy_Data():

    class Access_And_Mobility_Policy_Data_Document():

        def Retrieve_Access_and_Mobility_Policy():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/policy-data/ues/'+str(supi)+'/am-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's provisioned Session Management subscription data. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


    class UE_Policy_Set_Document():

        def Retrieve_UE_Policy_Set():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/policy-data/ues/'+str(supi)+'/ue-policy-set')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's provisioned Session Management subscription data. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


        def Store_UE_Policy_Set_Data():
            pass

        def Modify_UE_Policy_Set_Data():
            pass

    class Session_Management_Policy_Data_Document():

        def Retrieve_Session_Management_Policy_Data():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    try:
                        sst = int(input("Enter sst "+Fore.LIGHTBLACK_EX +"(Ex - 1)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID sst.")
                        print('')
                        continue

                while True:
                    try:
                        sd = int(input("Enter SD "+Fore.LIGHTBLACK_EX +"(Ex - 000001)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID SD.")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/policy-data/ues/'+str(supi)+'/sm-data?snssai=%7B%0A%20%20%22sst%22%3A%20'+str(sst)+'%2C%0A%20%20%22sd%22%3A%20%22'+str(sd)+'%22%0A%7D')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's provisioned Session Management subscription data. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


    class Usage_Monitoring_Information_Document():

        def Retrieve_Usage_Monitoring_Data():
            pass

        def Store_Usage_Monitoring_Data():
            pass

        def Delete_Usage_Monitoring_Data():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    usageMonId = input("Enter usageMonId "+Fore.LIGHTBLACK_EX +
                                        "(Ex -  b9f2f940-c628-41ec-aa78-9163487d7302)"+Fore.RESET+"- ")
                    if re.fullmatch(id_regex, usageMonId):
                        break

                    else:
                        print("Enter a Valid usageMonId")
                        print('')
                        continue
                    
                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/policy-data/ues/'+str(supi)+'/sm-data/'+str(usageMonId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()      

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


    class Sponsor_Connectivity_Data_Document():

        def Retrieve_Sponsored_Connectivity_Data():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    sponsorId = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, sponsorId):
                        break

                    else:
                        print("Enter a Valid sponsorId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/policy-data/sponsor-connectivity-data/'+str(sponsorId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's provisioned Session Management subscription data. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None



    class BDT_Data_Store():

        def Retrieve_BDT_Data():
            pass

    class Individual_BDT_Data_Document():

        def Retrieve_BDT_Policy():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    bdtReferenceId = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, bdtReferenceId):
                        break

                    else:
                        print("Enter a Valid bdtReferenceId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/policy-data/bdt-data/'+str(bdtReferenceId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's provisioned Session Management subscription data. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None

        def Create_BDT_Data_Resource():
            pass

        def Delete_BDT_Data_Resource():
            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    bdtReferenceId = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, bdtReferenceId):
                        break

                    else:
                        print("Enter a Valid bdtReferenceId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/policy-data/bdt-data/'+str(bdtReferenceId))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's provisioned Session Management subscription data. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None

    class Policy_Data_Subscriptions_Collection():

        def Create_Policy_Data_Subscription():
            pass

    class Individual_Policy_Data_Subscription_Document():

        def Replace_Policy_Data_Subscription():
            pass

        def Delete_Policy_Data_Subscription():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter subsId"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid subsId")
                        print('')
                        continue
                    
                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/policy-data/subs-to-notify/'+str(supi))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()      

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


    class Operator_Specific_Data_Document():

        def Retrieve_Operator_Specific_Data():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/policy-data/ues/'+str(supi)+'/operator-specific-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve operator specific data for the specified UE. Direction: PCF --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


        def Modify_Operator_Specific_Policy_Data():
            pass

        def Store_Operator_Specific_Policy_Data():
            pass

    class PLMN_UE_Policy_Set_Document():

        def Retrieve_UE_Policy_Set():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    plmn = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  12345)"+Fore.RESET+"- ")
                    if re.fullmatch(plmn_regex, plmn):
                        break

                    else:
                        print("Enter a Valid plmn")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/policy-data/plmns/'+str(plmn)+'/ue-policy-set')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve operator specific data for the specified UE. Direction: PCF --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None

class Exposure_Data():

    class Access_And_Mobility_Data():

        def Store_Access_And_Mobility_Data():
            pass

        def Retrieve_Access_And_Mobility_Data():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/exposure-data/'+str(supi)+'/access-and-mobility-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve operator specific data for the specified UE. Direction: PCF --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


        def Delete_Access_And_Mobility_Data():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/exposure-data/'+str(supi)+'/access-and-mobility-data')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve operator specific data for the specified UE. Direction: PCF --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


    class PDU_Session_Management_Data():

        def Store_Session_Management_Data():
            pass

        def Retrieve_Session_Management_Data():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    pduSessionId = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  12345)"+Fore.RESET+"- ")
                    if re.fullmatch(plmn_regex, pduSessionId):
                        break

                    else:
                        print("Enter a Valid pduSessionId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/exposure-data/'+str(supi)+'/session-management-data/'+str(pduSessionId)+'?ipv4-addr=198.51.100.1&ipv6-prefix=2001%3Adb8%3Aabcd%3A12%3A%3A0%2F64')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve operator specific data for the specified UE. Direction: PCF --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


        def Delete_Session_Management_Data():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    pduSessionId = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  12345)"+Fore.RESET+"- ")
                    if re.fullmatch(plmn_regex, pduSessionId):
                        break

                    else:
                        print("Enter a Valid pduSessionId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/exposure-data/'+str(supi)+'/session-management-data/'+str(pduSessionId)+'?ipv4-addr=198.51.100.1&ipv6-prefix=2001%3Adb8%3Aabcd%3A12%3A%3A0%2F64')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve operator specific data for the specified UE. Direction: PCF --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


    class Exposure_Data_Subscriptions_Collection():

        def Create_Exposure_Data_Subscription():
            pass

    class Individual_Exposure_Data_Subscription_Document():

        def Modify_Exposure_Data_Subscription():
            pass

        def Delete_Exposure_Data_Subscription():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter subsId"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid subsId")
                        print('')
                        continue
                    
                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/exposure-data/subs-to-notify/'+str(supi))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()      

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None



class Application_Data():

    class PFD_Data_Store():

        def Retrieve_ALL_PFDs():
            pass

    class Individual_PFD_Data_Document():

        def Retrieve_a_PFD():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter appId"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid appId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/application-data/pfds/'+str(supi))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve operator specific data for the specified UE. Direction: PCF --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


        def Delete_PFD_Data():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter appId"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid appId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/application-data/pfds/'+str(supi))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve operator specific data for the specified UE. Direction: PCF --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


        def Store_PFD_Data():
            pass

    class Influence_Data_Store():

        def Retreive_Influence_Data():
            pass

    class Individual_Influence_Data_Document():

        def Store_Influence_Data():
            pass

        def Modify_Influence_Data():
            pass

        def Delete_Influence_Data():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter influenceId"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid influenceId")
                        print('')
                        continue
                    
                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/application-data/influenceData/'+str(supi))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()      

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve the AMF registration information of a UE using 3GPP access. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


    class Influence_Data_Subscriptions_Collection():

        def Create_Influence_Data_Subscription():
            pass

        def Retrieve_Influence_Data_Subscriptions():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter UE ID"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid supi")
                        print('')
                        continue

                while True:
                    try:
                        sst = int(input("Enter sst "+Fore.LIGHTBLACK_EX +"(Ex - 1)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID sst.")
                        print('')
                        continue

                while True:
                    try:
                        sd = int(input("Enter SD "+Fore.LIGHTBLACK_EX +"(Ex - 000001)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID SD.")
                        print('')
                        continue

                while True:
                    try:
                        dnn = str(input("Enter DNN "+Fore.LIGHTBLACK_EX +"(Ex - internet)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID DNN.")
                        print('')
                        continue

                curl = pycurl.Curl()  
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/application-data/influenceData/subs-to-notify?dnn='+str(dnn)+'&snssai=%7B%0A%20%20%22sst%22%3A%20'+str(sst)+'%2C%0A%20%20%22sd%22%3A%20%22'+str(sd)+'%22%0A%7D&supi='+str(supi)+'')
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve a UE's provisioned Session Management subscription data. Direction: UDM --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


    class Individual_Influence_Data_Subscription_Document():

        def Retrieve_Influence_Data_Subscription():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter subscriptionId"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid subscriptionId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/application-data/influenceData/subs-to-notify/'+str(supi))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(pycurl.HTTPHEADER, ['Aaccept: application/3gppHal+json'])
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve operator specific data for the specified UE. Direction: PCF --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None


        def Modify_Influence_Data_Subscription():
            pass

        def Delete_Influence_Data_Subscription():

            try:
                while True:
                    try:
                        ip = ipaddress.ip_address(
                            input("Enter IP "+Fore.LIGHTBLACK_EX+"(Ex -  127.0.0.20)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID IP Address.")
                        print('')
                        continue

                while True:
                    try:
                        port = int(input("Enter Port "+Fore.LIGHTBLACK_EX +
                                "(Ex - 7777)"+Fore.RESET+"- "))
                        break

                    except ValueError:
                        print("This is NOT a VALID port Number.")
                        print('')
                        continue

                while True:
                    supi = input("Enter subscriptionId"+Fore.LIGHTBLACK_EX +
                                        "(Ex -  imsi-123456789612345)"+Fore.RESET+"- ")
                    if re.fullmatch(supiOrsuci_regex, supi):
                        break

                    else:
                        print("Enter a Valid subscriptionId")
                        print('')
                        continue

                curl = pycurl.Curl()
                curl.setopt(curl.URL, 'http://'+str(ip)+':' +
                            str(port)+'/nudr-dr/v1/application-data/influenceData/subs-to-notify/'+str(supi))
                curl.setopt(pycurl.HTTP_VERSION,
                            pycurl.CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE)
                curl.setopt(curl.CUSTOMREQUEST, "DELETE")
                curl.perform()

                status_code = curl.getinfo(pycurl.RESPONSE_CODE)
                if status_code != 200:
                    print("Server returned HTTP status code {}".format(status_code))

                if status_code == 200:
                    print("\nStatus :"+Fore.RED+" Vulnerable"+Fore.RESET)
                    print("\nRetrieve operator specific data for the specified UE. Direction: PCF --> UDR ")
                curl.close()

            except KeyboardInterrupt:
                print('') 
                print('')
                return None

